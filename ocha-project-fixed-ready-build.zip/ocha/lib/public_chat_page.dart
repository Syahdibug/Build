// public_chat_page.dart - MINECRAFT THEME
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import 'package:record/record.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'theme_provider.dart';
import 'config.dart';

class PublicChatPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const PublicChatPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<PublicChatPage> createState() => _PublicChatPageState();
}

class _PublicChatPageState extends State<PublicChatPage> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  List<ChatMessage> _messages = [];
  bool _isLoading = true;
  bool _isSending = false;
  int _onlineCount = 0;
  Timer? _pollingTimer;
  String? _lastMessageId;
  String get _baseUrl => ApiConfig.baseUrl;

  bool _isRecording = false;
  AudioRecorder? _audioRecorder;
  String? _audioPath;
  Timer? _recordTimer;
  int _recordDuration = 0;

  final List<String> _stickers = [
    'assets/stickers/1.jpg',
    'assets/stickers/2.jpg',
    'assets/stickers/3.jpg',
    'assets/stickers/4.jpg',
    'assets/stickers/5.jpg',
    'assets/stickers/6.jpg',
    'assets/stickers/7.jpg',
    'assets/stickers/8.jpg',
    'assets/stickers/9.jpg',
    'assets/stickers/10.jpg',
  ];

  OverlayEntry? _stickerOverlay;
  OverlayEntry? _attachmentOverlay;

  // ===== COLOR PALETTE - MINECRAFT THEME =====
  static const Color bgMain = Color(0xFF1A1A1A);          // Obsidian
  static const Color bgSurface = Color(0xFF2D2D2D);       // Stone
  static const Color bgCard = Color(0xFF3D3D3D);          // Cobblestone
  static const Color textMain = Color(0xFFE8E8E8);        // White wool
  static const Color textSub = Color(0xFFAAAAAA);         // Gray
  static const Color accentWhite = Color(0xFF4CAF50);     // Grass green
  static const Color borderLight = Color(0xFF5D5D5D);     // Stone border
  static const Color mcGold = Color(0xFFFFD700);          // Gold
  static const Color mcDiamond = Color(0xFF4DD0E1);       // Diamond
  static const Color mcRedstone = Color(0xFFFF5252);      // Redstone
  static const Color mcEmerald = Color(0xFF00E676);       // Emerald

  @override
  void initState() {
    super.initState();
    _loadMessages();
    _startPolling();
    _fetchOnlineUsers();
    _startOnlinePolling();
    _checkPermissions();
    _audioRecorder = AudioRecorder();
  }

  @override
  void dispose() {
    _pollingTimer?.cancel();
    _onlineTimer?.cancel();
    _recordTimer?.cancel();
    _messageController.dispose();
    _scrollController.dispose();
    _audioRecorder?.dispose();
    _stickerOverlay?.remove();
    _attachmentOverlay?.remove();
    super.dispose();
  }

  Future<void> _checkPermissions() async {
    final status = await Permission.microphone.request();
    if (!status.isGranted) {
      _showSnackBar('Izin mikrofon diperlukan untuk voice note', isError: true);
    }
  }

  void _startPolling() {
    _pollingTimer = Timer.periodic(const Duration(seconds: 3), (_) {
      _checkNewMessages();
    });
  }

  Timer? _onlineTimer;

  void _startOnlinePolling() {
    _onlineTimer = Timer.periodic(const Duration(seconds: 10), (_) {
      _fetchOnlineUsers();
    });
  }

  Future<void> _checkNewMessages() async {
    if (_lastMessageId == null) return;

    try {
      final response = await http.get(
        Uri.parse(
            '$_baseUrl/getPublicChat?key=${widget.sessionKey}&lastId=$_lastMessageId'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          final newMessages = (data['messages'] as List)
              .map((item) => ChatMessage.fromJson(item))
              .toList();

          if (newMessages.isNotEmpty) {
            setState(() {
              _messages.insertAll(0, newMessages);
              _lastMessageId = _messages.first.id;
            });
          }
        }
      }
    } catch (e) {
      print('Error checking new messages: $e');
    }
  }

  Future<void> _loadMessages() async {
    setState(() => _isLoading = true);

    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/getPublicChat?key=${widget.sessionKey}'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _messages = (data['messages'] as List)
                .map((item) => ChatMessage.fromJson(item))
                .toList();
            if (_messages.isNotEmpty) {
              _lastMessageId = _messages.first.id;
            }
          });
        }
      }
    } catch (e) {
      print('Error loading messages: $e');
    } finally {
      setState(() => _isLoading = false);
      _scrollToBottom();
    }
  }

  Future<void> _fetchOnlineUsers() async {
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/getOnlineUsers?key=${widget.sessionKey}'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _onlineCount = data['count'] ?? 0;
          });
        }
      }
    } catch (e) {
      print('Error fetching online users: $e');
    }
  }

  Future<void> _sendMessage({String? type, String? content}) async {
    final message = _messageController.text.trim();
    if (message.isEmpty && type == null) return;

    setState(() => _isSending = true);

    try {
      final payload = {
        'key': widget.sessionKey,
        'message': type == 'text' ? message : '',
      };

      if (type != null) {
        payload['type'] = type;
        if (content != null) payload['content'] = content;
      }

      final response = await http.post(
        Uri.parse('$_baseUrl/sendPublicChat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(payload),
      );

      final data = jsonDecode(response.body);
      if (data['valid'] == true) {
        _messageController.clear();
        final newMessage = ChatMessage.fromJson(data['message']);
        setState(() {
          _messages.insert(0, newMessage);
          _lastMessageId = newMessage.id;
        });
        _scrollToBottom();
      } else {
        _showSnackBar(data['message'] ?? 'Gagal mengirim pesan', isError: true);
      }
    } catch (e) {
      print('Error sending message: $e');
      _showSnackBar('Gagal mengirim pesan', isError: true);
    } finally {
      setState(() => _isSending = false);
    }
  }

  Future<void> _sendImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);

    if (picked != null) {
      final bytes = await File(picked.path).readAsBytes();
      final base64Image = base64Encode(bytes);

      try {
        final response = await http.post(
          Uri.parse('$_baseUrl/sendPublicChat'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'key': widget.sessionKey,
            'type': 'image',
            'content': base64Image,
            'filename': picked.name,
          }),
        );

        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          final newMessage = ChatMessage.fromJson(data['message']);
          setState(() {
            _messages.insert(0, newMessage);
            _lastMessageId = newMessage.id;
          });
          _scrollToBottom();
        } else {
          _showSnackBar(data['message'] ?? 'Gagal mengirim gambar', isError: true);
        }
      } catch (e) {
        _showSnackBar('Gagal mengirim gambar', isError: true);
      }
    }
  }

  Future<void> _sendSticker(String stickerPath) async {
    try {
      final ByteData data = await rootBundle.load(stickerPath);
      final bytes = data.buffer.asUint8List();
      final base64Sticker = base64Encode(bytes);

      final response = await http.post(
        Uri.parse('$_baseUrl/sendPublicChat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'type': 'sticker',
          'content': base64Sticker,
          'filename': stickerPath.split('/').last,
        }),
      );

      final dataJson = jsonDecode(response.body);
      if (dataJson['valid'] == true) {
        final newMessage = ChatMessage.fromJson(dataJson['message']);
        setState(() {
          _messages.insert(0, newMessage);
          _lastMessageId = newMessage.id;
        });
        _scrollToBottom();
        _closeStickerOverlay();
      } else {
        _showSnackBar(dataJson['message'] ?? 'Gagal mengirim sticker', isError: true);
      }
    } catch (e) {
      print('Error sending sticker: $e');
      _showSnackBar('Gagal mengirim sticker', isError: true);
    }
  }

  Future<void> _startRecording() async {
    final status = await Permission.microphone.request();
    if (!status.isGranted) {
      _showSnackBar('Izin mikrofon diperlukan', isError: true);
      return;
    }

    try {
      final directory = await getApplicationDocumentsDirectory();
      final path = '${directory.path}/voice_${DateTime.now().millisecondsSinceEpoch}.m4a';

      await _audioRecorder!.start(
        const RecordConfig(),
        path: path,
      );

      setState(() {
        _isRecording = true;
        _recordDuration = 0;
        _audioPath = path;
      });

      _recordTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
        if (mounted) {
          setState(() {
            _recordDuration++;
          });
        }
      });
    } catch (e) {
      print('Recording error: $e');
      _showSnackBar('Gagal memulai rekaman', isError: true);
    }
  }

  Future<void> _stopRecording() async {
    _recordTimer?.cancel();

    if (_audioRecorder != null && _isRecording) {
      try {
        final path = await _audioRecorder!.stop();

        setState(() {
          _isRecording = false;
          _audioPath = path;
        });

        if (path != null && await File(path).exists()) {
          final bytes = await File(path).readAsBytes();
          final base64Audio = base64Encode(bytes);

          try {
            final response = await http.post(
              Uri.parse('$_baseUrl/sendPublicChat'),
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode({
                'key': widget.sessionKey,
                'type': 'voice',
                'content': base64Audio,
                'duration': _recordDuration,
                'filename': 'voice_${DateTime.now().millisecondsSinceEpoch}.m4a',
              }),
            );

            final data = jsonDecode(response.body);
            if (data['valid'] == true) {
              final newMessage = ChatMessage.fromJson(data['message']);
              setState(() {
                _messages.insert(0, newMessage);
                _lastMessageId = newMessage.id;
              });
              _scrollToBottom();
            } else {
              _showSnackBar(data['message'] ?? 'Gagal mengirim voice note', isError: true);
            }
          } catch (e) {
            print('Send voice error: $e');
            _showSnackBar('Gagal mengirim voice note', isError: true);
          }
        }

        setState(() => _audioPath = null);
      } catch (e) {
        print('Stop recording error: $e');
        _showSnackBar('Gagal menghentikan rekaman', isError: true);
      }
    }
  }

  Future<void> _deleteMessage(String messageId, String messageUsername) async {
    final canDelete = widget.role == 'owner' || widget.username == messageUsername;

    if (!canDelete) {
      _showSnackBar('Tidak bisa menghapus pesan orang lain', isError: true);
      return;
    }

    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: TweenAnimationBuilder(
          duration: const Duration(milliseconds: 300),
          tween: Tween<double>(begin: 0, end: 1),
          builder: (context, double scale, child) {
            return Transform.scale(scale: scale, child: child);
          },
          child: Container(
            margin: const EdgeInsets.all(20),
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: bgCard,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: mcRedstone, width: 3),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.8),
                  blurRadius: 0,
                  offset: const Offset(8, 8),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: bgSurface,
                    border: Border.all(color: mcRedstone, width: 3),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.6),
                        blurRadius: 0,
                        offset: const Offset(4, 4),
                      )
                    ],
                  ),
                  child: const Icon(Icons.warning_amber_rounded,
                      color: mcRedstone, size: 32),
                ),
                const SizedBox(height: 20),
                const Text(
                  "HAPUS PESAN",
                  style: TextStyle(
                    color: textMain,
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    letterSpacing: 1.2,
                    shadows: [
                      Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  "Yakin ingin menghapus pesan ini?",
                  style: TextStyle(color: textSub, fontSize: 12),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () => Navigator.pop(context, false),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            color: bgSurface,
                            border: Border.all(color: borderLight, width: 2),
                          ),
                          child: const Center(
                            child: Text(
                              "BATAL",
                              style: TextStyle(
                                color: textMain,
                                fontWeight: FontWeight.bold,
                                fontSize: 11,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: GestureDetector(
                        onTap: () => Navigator.pop(context, true),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            color: mcRedstone,
                            border: Border.all(color: Colors.black, width: 2),
                          ),
                          child: const Center(
                            child: Text(
                              "HAPUS",
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 11,
                                shadows: [
                                  Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );

    if (confirm != true) return;

    try {
      final response = await http.delete(
        Uri.parse('$_baseUrl/deletePublicChat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'messageId': messageId,
        }),
      );

      final data = jsonDecode(response.body);
      if (data['valid'] == true) {
        setState(() {
          _messages.removeWhere((m) => m.id == messageId);
        });
        _showSnackBar('Pesan berhasil dihapus', isError: false);
      } else {
        _showSnackBar(data['message'] ?? 'Gagal menghapus pesan', isError: true);
      }
    } catch (e) {
      print('Error deleting message: $e');
      _showSnackBar('Gagal menghapus pesan', isError: true);
    }
  }

  void _showSnackBar(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isError ? Icons.error_outline : Icons.check_circle_outline,
              color: Colors.white,
              size: 20,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                msg,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: isError ? mcRedstone : accentWhite,
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.zero,
          side: BorderSide(color: Colors.black, width: 2),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          0,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Color _getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case 'owner':
        return mcGold;
      case 'admin':
        return mcRedstone;
      case 'moderator':
        return mcDiamond;
      case 'partner':
        return mcDiamond;
      case 'seller':
      case 'reseller':
        return accentWhite;
      default:
        return textSub;
    }
  }

  // ===== OVERLAY - STICKERS - MINECRAFT STYLE =====
  void _showStickerOverlay() {
    _closeAttachmentOverlay();
    if (_stickerOverlay != null) {
      _closeStickerOverlay();
      return;
    }

    final overlay = Overlay.of(context);

    _stickerOverlay = OverlayEntry(
      builder: (context) => Positioned(
        bottom: 80,
        left: 0,
        right: 0,
        child: Material(
          color: Colors.transparent,
          child: Container(
            height: 300,
            margin: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: bgCard,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: accentWhite, width: 3),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.8),
                  blurRadius: 0,
                  offset: const Offset(6, 6),
                ),
              ],
            ),
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: const BoxDecoration(
                    border: Border(
                      bottom: BorderSide(color: accentWhite, width: 2),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 6,
                            height: 18,
                            decoration: BoxDecoration(
                              color: accentWhite,
                              border: Border.all(color: Colors.black, width: 1),
                            ),
                          ),
                          const SizedBox(width: 8),
                          const Text(
                            "STICKERS",
                            style: TextStyle(
                              color: textMain,
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.2,
                              shadows: [
                                Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                              ],
                            ),
                          ),
                        ],
                      ),
                      IconButton(
                        icon: const Icon(Icons.close_rounded, color: textSub),
                        onPressed: _closeStickerOverlay,
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: GridView.builder(
                    padding: const EdgeInsets.all(12),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 4,
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 8,
                    ),
                    itemCount: _stickers.length,
                    itemBuilder: (context, index) {
                      return GestureDetector(
                        onTap: () => _sendSticker(_stickers[index]),
                        child: Container(
                          decoration: BoxDecoration(
                            color: bgSurface,
                            border: Border.all(color: borderLight, width: 2),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.5),
                                blurRadius: 0,
                                offset: const Offset(2, 2),
                              )
                            ],
                          ),
                          child: Image.asset(
                            _stickers[index],
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => const Center(
                              child: Icon(Icons.sticky_note_2_rounded, color: textSub, size: 32),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );

    overlay.insert(_stickerOverlay!);
  }

  void _closeStickerOverlay() {
    _stickerOverlay?.remove();
    _stickerOverlay = null;
  }

  // ===== OVERLAY - ATTACHMENT - MINECRAFT STYLE =====
  void _showAttachmentOverlay() {
    _closeStickerOverlay();
    if (_attachmentOverlay != null) {
      _closeAttachmentOverlay();
      return;
    }

    final overlay = Overlay.of(context);

    _attachmentOverlay = OverlayEntry(
      builder: (context) => Positioned(
        bottom: 80,
        left: 0,
        right: 0,
        child: Material(
          color: Colors.transparent,
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 12),
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
            decoration: BoxDecoration(
              color: bgCard,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: accentWhite, width: 3),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.8),
                  blurRadius: 0,
                  offset: const Offset(6, 6),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildAttachmentButton(
                      icon: Icons.photo_rounded,
                      label: "Gambar",
                      color: accentWhite,
                      onTap: () {
                        _closeAttachmentOverlay();
                        _sendImage();
                      },
                    ),
                    _buildAttachmentButton(
                      icon: Icons.mic_rounded,
                      label: _isRecording ? "Stop" : "Voice",
                      color: _isRecording ? mcRedstone : mcGold,
                      onTap: () {
                        if (_isRecording) {
                          _stopRecording();
                        } else {
                          _startRecording();
                        }
                        _closeAttachmentOverlay();
                      },
                    ),
                    _buildAttachmentButton(
                      icon: Icons.sticky_note_2_rounded,
                      label: "Sticker",
                      color: mcDiamond,
                      onTap: () {
                        _closeAttachmentOverlay();
                        _showStickerOverlay();
                      },
                    ),
                  ],
                ),
                if (_isRecording) ...[
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: mcRedstone.withOpacity(0.15),
                      border: Border.all(color: mcRedstone, width: 2),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.5),
                          blurRadius: 0,
                          offset: const Offset(3, 3),
                        )
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 10,
                          height: 10,
                          decoration: const BoxDecoration(
                            color: mcRedstone,
                            boxShadow: [
                              BoxShadow(color: mcRedstone, blurRadius: 6, spreadRadius: 1),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'Merekam... ${_formatDuration(_recordDuration)}',
                          style: const TextStyle(
                            color: mcRedstone,
                            fontWeight: FontWeight.bold,
                            fontSize: 11,
                            shadows: [
                              Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );

    overlay.insert(_attachmentOverlay!);
  }

  void _closeAttachmentOverlay() {
    _attachmentOverlay?.remove();
    _attachmentOverlay = null;
  }

  Widget _buildAttachmentButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: bgSurface,
              border: Border.all(color: color, width: 3),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.6),
                  blurRadius: 0,
                  offset: const Offset(3, 3),
                )
              ],
            ),
            child: Icon(icon, color: color, size: 26),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            style: const TextStyle(
              color: textMain,
              fontSize: 10,
              fontWeight: FontWeight.bold,
              shadows: [
                Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _formatDuration(int seconds) {
    final minutes = seconds ~/ 60;
    final secs = seconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Provider.of<ThemeProvider>(context);

    return Scaffold(
      backgroundColor: bgMain,
      appBar: AppBar(
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: bgCard,
            border: Border.all(color: accentWhite, width: 2),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.6),
                blurRadius: 0,
                offset: const Offset(3, 3),
              ),
            ],
          ),
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.public_rounded, color: accentWhite, size: 18),
              SizedBox(width: 8),
              Text(
                "PUBLIC CHAT",
                style: TextStyle(
                  color: textMain,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                  shadows: [
                    Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                  ],
                ),
              ),
            ],
          ),
        ),
        backgroundColor: bgMain,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: bgCard,
              border: Border.all(color: accentWhite, width: 2),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.6),
                  blurRadius: 0,
                  offset: const Offset(2, 2),
                )
              ],
            ),
            child: const Icon(Icons.arrow_back_ios_new, color: textMain, size: 16),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 12),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.5),
              border: Border.all(color: mcEmerald, width: 2),
              boxShadow: [
                BoxShadow(
                  color: mcEmerald.withOpacity(0.4),
                  blurRadius: 0,
                  offset: const Offset(2, 2),
                )
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: const BoxDecoration(
                    color: mcEmerald,
                    boxShadow: [BoxShadow(color: mcEmerald, blurRadius: 5, spreadRadius: 1)],
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  '$_onlineCount Online',
                  style: const TextStyle(
                    color: mcEmerald,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    shadows: [
                      Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(3),
          child: Container(
            height: 3,
            color: accentWhite,
          ),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgMain, bgSurface, bgMain],
          ),
        ),
        child: Column(
          children: [
            Expanded(
              child: _isLoading
                  ? const Center(
                      child: CircularProgressIndicator(color: accentWhite),
                    )
                  : _messages.isEmpty
                      ? Center(
                          child: TweenAnimationBuilder(
                            duration: const Duration(milliseconds: 600),
                            tween: Tween<double>(begin: 0, end: 1),
                            builder: (context, double value, child) {
                              return Opacity(
                                opacity: value,
                                child: Transform.translate(
                                  offset: Offset(0, 20 * (1 - value)),
                                  child: child,
                                ),
                              );
                            },
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(32),
                                  decoration: BoxDecoration(
                                    color: bgCard,
                                    border: Border.all(color: accentWhite, width: 3),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withOpacity(0.6),
                                        blurRadius: 0,
                                        offset: const Offset(5, 5),
                                      )
                                    ],
                                  ),
                                  child: const Icon(Icons.chat_bubble_outline,
                                      size: 64, color: accentWhite),
                                ),
                                const SizedBox(height: 20),
                                const Text(
                                  'Belum ada pesan',
                                  style: TextStyle(
                                    color: textMain,
                                    fontSize: 13,
                                    fontWeight: FontWeight.bold,
                                    shadows: [
                                      Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                                    ],
                                  ),
                                ),
                                const SizedBox(height: 8),
                                const Text(
                                  'Jadilah yang pertama mengirim pesan',
                                  style: TextStyle(color: textSub, fontSize: 11),
                                ),
                              ],
                            ),
                          ),
                        )
                      : ListView.builder(
                          controller: _scrollController,
                          reverse: true,
                          padding: const EdgeInsets.all(12),
                          itemCount: _messages.length,
                          itemBuilder: (context, index) {
                            final msg = _messages[index];
                            final isMe = msg.username == widget.username;
                            return GestureDetector(
                              onLongPress: () => _deleteMessage(msg.id, msg.username),
                              child: TweenAnimationBuilder(
                                duration: Duration(milliseconds: 200 + (index * 20)),
                                tween: Tween<double>(begin: 0, end: 1),
                                builder: (context, double value, child) {
                                  return Opacity(
                                    opacity: value,
                                    child: Transform.translate(
                                      offset: Offset(0, 20 * (1 - value)),
                                      child: child,
                                    ),
                                  );
                                },
                                child: _buildMessageBubble(msg, isMe),
                              ),
                            );
                          },
                        ),
            ),

            // Input bar - MINECRAFT STYLE
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: bgCard,
                border: const Border(
                  top: BorderSide(color: accentWhite, width: 3),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.7),
                    blurRadius: 0,
                    offset: const Offset(0, -4),
                  )
                ],
              ),
              child: Row(
                children: [
                  // Attachment button
                  GestureDetector(
                    onTap: _showAttachmentOverlay,
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: bgSurface,
                        border: Border.all(color: accentWhite, width: 2),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.5),
                            blurRadius: 0,
                            offset: const Offset(2, 2),
                          )
                        ],
                      ),
                      child: const Icon(Icons.attach_file_rounded,
                          color: accentWhite, size: 22),
                    ),
                  ),
                  const SizedBox(width: 8),

                  // Text input
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: bgSurface,
                        border: Border.all(color: accentWhite, width: 2),
                      ),
                      child: TextField(
                        controller: _messageController,
                        style: const TextStyle(color: textMain, fontSize: 13),
                        cursorColor: accentWhite,
                        cursorWidth: 3,
                        maxLines: null,
                        decoration: InputDecoration(
                          hintText: 'Tulis pesan...',
                          hintStyle: TextStyle(color: Colors.white.withOpacity(0.25), fontSize: 12),
                          border: InputBorder.none,
                          contentPadding:
                              const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                        ),
                        onSubmitted: (_) => _sendMessage(type: 'text'),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),

                  // Send button
                  GestureDetector(
                    onTap: _isSending ? null : () => _sendMessage(type: 'text'),
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: accentWhite,
                        border: Border.all(color: Colors.black, width: 2),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.6),
                            blurRadius: 0,
                            offset: const Offset(3, 3),
                          )
                        ],
                      ),
                      child: _isSending
                          ? const SizedBox(
                              width: 22,
                              height: 22,
                              child: CircularProgressIndicator(
                                strokeWidth: 3,
                                color: Colors.white,
                              ),
                            )
                          : const Icon(Icons.send_rounded,
                              color: Colors.white, size: 20),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ===== MESSAGE BUBBLE - MINECRAFT STYLE =====
  Widget _buildMessageBubble(ChatMessage msg, bool isMe) {
    final isImage = msg.type == 'image';
    final isSticker = msg.type == 'sticker';
    final isVoice = msg.type == 'voice';

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: Row(
        mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!isMe) ...[
            Container(
              width: 42,
              height: 42,
              margin: const EdgeInsets.only(right: 10),
              decoration: BoxDecoration(
                color: bgCard,
                border: Border.all(color: _getRoleColor(msg.role), width: 2),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.6),
                    blurRadius: 0,
                    offset: const Offset(2, 2),
                  )
                ],
              ),
              child: Center(
                child: Text(
                  msg.username.isNotEmpty ? msg.username[0].toUpperCase() : '?',
                  style: const TextStyle(
                    color: textMain,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    shadows: [
                      Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                    ],
                  ),
                ),
              ),
            ),
          ],
          Flexible(
            child: Container(
              constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width * 0.75,
              ),
              padding: isSticker ? EdgeInsets.zero : const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: isSticker
                  ? null
                  : BoxDecoration(
                      color: isMe ? accentWhite : bgCard,
                      border: Border.all(
                        color: isMe ? Colors.black : borderLight,
                        width: 2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.6),
                          blurRadius: 0,
                          offset: const Offset(3, 3),
                        ),
                      ],
                    ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (!isMe && !isSticker)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: Row(
                        children: [
                          Text(
                            msg.username,
                            style: TextStyle(
                              color: _getRoleColor(msg.role),
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              shadows: const [
                                Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                              ],
                            ),
                          ),
                          if (msg.role == 'owner') ...[
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: mcGold.withOpacity(0.2),
                                border: Border.all(color: mcGold, width: 1),
                              ),
                              child: const Text(
                                "OWNER",
                                style: TextStyle(
                                  color: mcGold,
                                  fontSize: 8,
                                  fontWeight: FontWeight.bold,
                                  shadows: [
                                    Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),

                  // Content based on type
                  if (isImage)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(2),
                      child: Image.memory(
                        base64Decode(msg.content!),
                        fit: BoxFit.cover,
                        width: 200,
                        height: 200,
                      ),
                    )
                  else if (isSticker)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(2),
                      child: Image.memory(
                        base64Decode(msg.content!),
                        fit: BoxFit.contain,
                        width: 120,
                        height: 120,
                      ),
                    )
                  else if (isVoice)
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.mic_rounded,
                          color: isMe ? Colors.white : accentWhite,
                          size: 20,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'Voice Note (${_formatDuration(msg.duration ?? 0)})',
                          style: TextStyle(
                            color: isMe ? Colors.white : textMain,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    )
                  else
                    Text(
                      msg.message,
                      style: TextStyle(
                        color: isMe ? Colors.white : textMain,
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                        shadows: isMe
                            ? const [
                                Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                              ]
                            : null,
                      ),
                      softWrap: true,
                    ),

                  if (!isSticker) ...[
                    const SizedBox(height: 4),
                    Text(
                      msg.formattedTime,
                      style: TextStyle(
                        color: isMe ? Colors.white.withOpacity(0.8) : textSub,
                        fontSize: 9,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// Model ChatMessage
class ChatMessage {
  final String id;
  final String username;
  final String role;
  final String message;
  final String timestamp;
  final String formattedTime;
  final String? type;
  final String? content;
  final int? duration;

  ChatMessage({
    required this.id,
    required this.username,
    required this.role,
    required this.message,
    required this.timestamp,
    required this.formattedTime,
    this.type,
    this.content,
    this.duration,
  });

  factory ChatMessage.fromJson(Map<String, dynamic> json) {
    return ChatMessage(
      id: json['id'] ?? '',
      username: json['username'] ?? '',
      role: json['role'] ?? 'member',
      message: json['message'] ?? '',
      timestamp: json['timestamp'] ?? DateTime.now().toIso8601String(),
      formattedTime: json['formattedTime'] ?? '',
      type: json['type'],
      content: json['content'],
      duration: json['duration'],
    );
  }
}