import 'dart:convert';
import 'package:http/http.dart' as http;
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:glaze_nav_bar/glaze_nav_bar.dart';

import 'nik_check.dart';
import 'admin_page.dart';
import 'partner_page.dart';
import 'moderator_page.dart';
import 'public_chat_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'control_panel.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;
  final String? uid;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
    this.uid,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;
  late String? uid;

  String androidId = "unknown";
  File? _profileImage;
  VideoPlayerController? _menuVideoController;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const Placeholder();
  final GlobalKey<GlazeNavBarState> _navBarKey = GlobalKey();

  int onlineUsers = 0;
  int activeConnections = 0;

  // ===== QUICK ACTIONS =====
  int _quickActionsPage = 0;
  late PageController _quickActionsController;

  // ===== WEATHER =====
  String _weatherTemp = '--';
  String _weatherCity = 'Memuat...';
  String _weatherDesc = '';
  String _weatherHumidity = '--';
  String _weatherWind = '--';
  bool _weatherLoading = true;
  IconData _weatherIcon = Icons.wb_sunny_rounded;

  // ===== COLOR PALETTE - MINECRAFT THEME =====
  static const Color bgMain = Color(0xFF1A1A1A);
  static const Color bgSurface = Color(0xFF2D2D2D);
  static const Color bgCard = Color(0xFF3D3D3D);
  static const Color textMain = Color(0xFFE8E8E8);
  static const Color textSub = Color(0xFFAAAAAA);
  static const Color accentWhite = Color(0xFF4CAF50);
  static const Color borderLight = Color(0xFF5D5D5D);
  static const Color mcGold = Color(0xFFFFD700);
  static const Color mcDiamond = Color(0xFF4DD0E1);
  static const Color mcRedstone = Color(0xFFFF5252);
  static const Color mcEmerald = Color(0xFF00E676);

  // ===== HELPER TEXT STYLE =====
  TextStyle _mcText({
    double fontSize = 13,
    FontWeight fontWeight = FontWeight.normal,
    Color color = textMain,
    double letterSpacing = 0.3,
    List<Shadow>? shadows,
    double? height,
  }) {
    return TextStyle(
      fontSize: fontSize,
      fontWeight: fontWeight,
      color: color,
      letterSpacing: letterSpacing,
      shadows: shadows,
      height: height,
    );
  }

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;
    uid = widget.uid;

    _quickActionsController = PageController(viewportFraction: 0.88);

    _controller = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _selectedPage = _buildNewsPage();
    _initAndroidIdAndConnect();
    _loadProfileImage();
    _initMenuVideo();
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _menuVideoController?.dispose();
    _quickActionsController.dispose();
    super.dispose();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() => _profileImage = File(imagePath));
    }
  }

  void _initMenuVideo() {
    _menuVideoController =
        VideoPlayerController.asset('assets/videos/bug.mp4')
          ..initialize().then((_) {
            setState(() {});
            _menuVideoController?.setLooping(true);
            _menuVideoController?.play();
          });
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(
        Uri.parse('wss://pterodactyl.cloud:4813'));
    channel.sink.add(jsonEncode({"type": "stats"}));
    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'stats') {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConnections = data['activeConnections'] ?? 0;
        });
      }
    }, onError: (e) => debugPrint("WS error: $e"));
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _onBottomNavTapped(int index) {
    setState(() {
      _bottomNavIndex = index;
      switch (index) {
        case 0:
          _selectedPage = _buildNewsPage();
          break;
        case 1:
          _selectedPage = HomePage(
            username: username,
            password: password,
            listBug: listBug,
            role: role,
            expiredDate: expiredDate,
            sessionKey: sessionKey,
          );
          break;
        case 2:
          _selectedPage = InfoPage(sessionKey: sessionKey);
          break;
        case 3:
          _selectedPage = ToolsPage(
              sessionKey: sessionKey, userRole: role, listDoos: listDoos);
          break;
      }
    });
  }

  void _onSidebarTabSelected(int index) {
    setState(() {
      if (index == 1) _selectedPage = SellerPage(keyToken: sessionKey);
      else if (index == 2) _selectedPage = AdminPage(sessionKey: sessionKey);
      else if (index == 3) _selectedPage = PartnerPage(sessionKey: sessionKey, username: username);
      else if (index == 4) _selectedPage = ModeratorPage(sessionKey: sessionKey, username: username);
      else if (index == 5) _selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
    });
    Navigator.pop(context);
  }

  Widget _buildNewsPage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // HEADER CARD - MINECRAFT STYLE
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: bgCard,
                borderRadius: BorderRadius.circular(4),
                border: Border.all(color: borderLight, width: 3),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.7),
                    blurRadius: 0,
                    offset: const Offset(6, 6),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(
                          shape: BoxShape.rectangle,
                          color: bgSurface,
                          border: Border.all(color: accentWhite, width: 3),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.6),
                              blurRadius: 0,
                              offset: const Offset(3, 3),
                            )
                          ],
                        ),
                        child: _profileImage != null
                            ? Image.file(_profileImage!, fit: BoxFit.cover)
                            : const Icon(Icons.person_rounded, color: accentWhite, size: 28),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "$username",
                              style: _mcText(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.5,
                                shadows: const [
                                  Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                                ],
                              ),
                            ),
                            const SizedBox(height: 5),
                            Row(
                              children: [
                                _roleBadge(role.toUpperCase()),
                                const SizedBox(width: 8),
                                Flexible(
                                  child: Text(
                                    "· Exp: $expiredDate",
                                    style: _mcText(fontSize: 11, color: textSub),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      _buildStatChip(Icons.group_rounded, "$onlineUsers", "Online"),
                      const SizedBox(width: 24),
                      _buildStatChip(Icons.wifi_rounded, "$activeConnections", "Koneksi"),
                      const Spacer(),
                      _onlineBadge(),
                    ],
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 12),

          // BERITA TERBARU
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 6,
                          height: 18,
                          decoration: BoxDecoration(
                            color: accentWhite,
                            border: Border.all(color: Colors.black, width: 1),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          "Berita Terbaru",
                          style: _mcText(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            shadows: const [
                              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                            ],
                          ),
                        ),
                      ],
                    ),
                    Text(
                      "${newsList.length} artikel",
                      style: _mcText(fontSize: 11, color: textSub),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                if (newsList.isNotEmpty)
                  SizedBox(
                    height: 200,
                    child: PageView.builder(
                      controller: PageController(viewportFraction: 0.88),
                      itemCount: newsList.length,
                      itemBuilder: (ctx, i) {
                        final item = newsList[i];
                        return Container(
                          margin: const EdgeInsets.symmetric(horizontal: 6),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4),
                            color: bgCard,
                            border: Border.all(color: accentWhite, width: 3),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.7),
                                blurRadius: 0,
                                offset: const Offset(5, 5),
                              )
                            ],
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(1),
                            child: Stack(
                              fit: StackFit.expand,
                              children: [
                                if (item['image'] != null && item['image'].toString().isNotEmpty)
                                  NewsMedia(url: item['image']),
                                Container(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [
                                        Colors.black.withOpacity(0.85),
                                        Colors.transparent,
                                      ],
                                      begin: Alignment.bottomCenter,
                                      end: Alignment.topCenter,
                                    ),
                                  ),
                                ),
                                Positioned(
                                  top: 12,
                                  left: 12,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: accentWhite,
                                      borderRadius: BorderRadius.circular(2),
                                      border: Border.all(color: Colors.black, width: 2),
                                      boxShadow: const [
                                        BoxShadow(
                                          color: Colors.black,
                                          blurRadius: 0,
                                          offset: Offset(2, 2),
                                        )
                                      ],
                                    ),
                                    child: Text(
                                      "NEWS",
                                      style: _mcText(
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black,
                                        letterSpacing: 1,
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  bottom: 14,
                                  left: 14,
                                  right: 14,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        item['title'] ?? '',
                                        style: _mcText(
                                          fontSize: 13,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white,
                                          shadows: const [
                                            Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                                            Shadow(color: Colors.black, offset: Offset(-1, -1), blurRadius: 0),
                                          ],
                                        ),
                                      ),
                                      const SizedBox(height: 3),
                                      Text(
                                        item['desc'] ?? '',
                                        style: _mcText(fontSize: 11, color: Colors.white70),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // JOIN CHANNEL
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                Expanded(
                  child: _actionBannerCard(
                    icon: FontAwesomeIcons.telegram,
                    label: "Join Channel",
                    sub: "OCHA PROJECT",
                    color: Colors.blue,
                    onTap: () => _openUrl("https://t.me/makariizox"),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 18),

          // QUICK ACTIONS CAROUSEL
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _sectionHeader(Icons.bolt_rounded, "Quick Actions"),
                    Text(
                      "New Features",
                      style: _mcText(fontSize: 11, color: textSub),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                height: 120,
                child: PageView(
                  controller: _quickActionsController,
                  physics: const BouncingScrollPhysics(),
                  clipBehavior: Clip.none,
                  onPageChanged: (page) {
                    setState(() {
                      _quickActionsPage = page;
                    });
                  },
                  children: [
                    _quickActionCard(
                      icon: Icons.public_rounded,
                      label: "Global Chat",
                      sub: "Chat With All User",
                      gradient: [const Color(0xFF1A237E), const Color(0xFF3B5BDB)],
                      iconBg: const Color(0xFF3B5BDB),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => PublicChatPage(
                            username: username, sessionKey: sessionKey, role: role
                          ),
                        ),
                      ),
                    ),
                    _quickActionCard(
                      icon: Icons.settings_remote_rounded,
                      label: "RAT Control Panel",
                      sub: "Remote Access Tools",
                      gradient: [const Color(0xFF6200EA), const Color(0xFFB388FF)],
                      iconBg: const Color(0xFF6200EA),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const ControlPanelPage(),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
            ],
          ),

          // DOT INDICATOR
          Center(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: List.generate(2, (index) {
                final isActive = index == _quickActionsPage;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  curve: Curves.easeInOut,
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: isActive ? 20 : 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: isActive ? accentWhite : accentWhite.withOpacity(0.3),
                    border: Border.all(color: Colors.black, width: 1.5),
                  ),
                );
              }),
            ),
          ),

          const SizedBox(height: 16),

          // INFO & PENGUMUMAN
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: GestureDetector(
              onTap: _showInfoDialog,
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: bgCard,
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: mcGold, width: 3),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.7),
                      blurRadius: 0,
                      offset: const Offset(5, 5),
                    )
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: mcGold.withOpacity(0.2),
                        border: Border.all(color: mcGold, width: 2),
                      ),
                      child: const Icon(Icons.info_outline, color: mcGold, size: 22),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Info & Pengumuman",
                            style: _mcText(
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              shadows: const [
                                Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                              ],
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            "Klik untuk melihat info terbaru",
                            style: _mcText(fontSize: 11, color: textSub),
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.arrow_forward_ios, color: mcGold, size: 15),
                  ],
                ),
              ),
            ),
          ),

          const SizedBox(height: 20),

          // DIVIDER
          Center(
            child: Container(
              width: 60,
              height: 3,
              color: textSub.withOpacity(0.5),
            ),
          ),

          const SizedBox(height: 20),

          // HUBUNGI KAMI
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _sectionHeader(Icons.headset_mic_outlined, "HUBUNGI KAMI"),
                const SizedBox(height: 14),
                _buildContactCard(
                  icon: FontAwesomeIcons.telegram,
                  label: "Telegram Utama",
                  subtitle: "Developer 1",
                  color: const Color(0xFF25D366),
                  url: "https://t.me/Lexcaaboss",
                ),
                const SizedBox(height: 10),
                _buildContactCard(
                  icon: FontAwesomeIcons.telegram,
                  label: "Telegram Kedua",
                  subtitle: "Developer 2",
                  color: const Color(0xFF0088cc),
                  url: "https://t.me/iniochamy",
                ),
                const SizedBox(height: 10),
                _buildContactCard(
                  icon: Icons.telegram,
                  label: "Channel Information",
                  subtitle: "Update terbaru & pengumuman",
                  color: const Color(0xFF00BCD4),
                  url: "https://t.me/makariizox",
                ),
                const SizedBox(height: 10),
                _buildContactCard(
                  icon: FontAwesomeIcons.tiktok,
                  label: "TikTok Developer",
                  subtitle: "content about the application",
                  color: textSub,
                  url: "https://www.tiktok.com/@lexcaabos",
                ),
              ],
            ),
          ),

          const SizedBox(height: 32),
        ],
      ),
    );
  }

  // ===== HELPER WIDGETS =====
  Widget _sectionHeader(IconData icon, String title) => Row(
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: accentWhite.withOpacity(0.15),
              border: Border.all(color: accentWhite, width: 2),
            ),
            child: Icon(icon, color: accentWhite, size: 16),
          ),
          const SizedBox(width: 8),
          Text(
            title,
            style: _mcText(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.3,
              shadows: const [
                Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
              ],
            ),
          ),
        ],
      );

  Widget _roleBadge(String text) {
    final lowerRole = text.toLowerCase();
    Color badgeColor;
    if (lowerRole == 'owner') {
      badgeColor = mcGold;
    } else if (lowerRole == 'moderator') {
      badgeColor = mcDiamond;
    } else if (lowerRole == 'partner') {
      badgeColor = mcEmerald;
    } else if (lowerRole == 'admin') {
      badgeColor = mcRedstone;
    } else if (lowerRole == 'reseller' || lowerRole == 'seller') {
      badgeColor = accentWhite;
    } else {
      badgeColor = textSub;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: badgeColor.withOpacity(0.15),
        border: Border.all(color: badgeColor, width: 2),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(color: badgeColor),
          ),
          const SizedBox(width: 4),
          Text(
            text,
            style: _mcText(
              fontSize: 10,
              fontWeight: FontWeight.bold,
              color: badgeColor,
              letterSpacing: 0.8,
              shadows: const [
                Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _onlineBadge() => Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.5),
          border: Border.all(color: mcEmerald, width: 2),
          boxShadow: [
            BoxShadow(
              color: mcEmerald.withOpacity(0.4),
              blurRadius: 0,
              offset: const Offset(3, 3),
            )
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 8,
              height: 8,
              decoration: const BoxDecoration(
                color: mcEmerald,
                boxShadow: [
                  BoxShadow(color: mcEmerald, blurRadius: 6, spreadRadius: 1),
                ],
              ),
            ),
            const SizedBox(width: 6),
            Text(
              "ONLINE",
              style: _mcText(
                fontSize: 11,
                fontWeight: FontWeight.bold,
                color: mcEmerald,
                letterSpacing: 1.5,
                shadows: const [
                  Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                ],
              ),
            ),
          ],
        ),
      );

  Widget _buildStatChip(IconData icon, String value, String label) => Row(
        children: [
          Icon(icon, color: accentWhite, size: 17),
          const SizedBox(width: 5),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                value,
                style: _mcText(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  shadows: const [
                    Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                  ],
                ),
              ),
              Text(
                label,
                style: _mcText(fontSize: 10, color: textSub),
              ),
            ],
          ),
        ],
      );

  Widget _actionBannerCard({
    required IconData icon,
    required String label,
    required String sub,
    required Color color,
    required VoidCallback onTap,
  }) =>
      GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(
            color: bgCard,
            border: Border.all(color: color, width: 3),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.6),
                blurRadius: 0,
                offset: const Offset(4, 4),
              )
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.2),
                  border: Border.all(color: color, width: 2),
                ),
                child: Icon(icon, color: color, size: 16),
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      label,
                      style: _mcText(
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        color: color,
                        shadows: const [
                          Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                        ],
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      sub,
                      style: _mcText(fontSize: 11, color: textSub),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              Icon(Icons.arrow_forward_ios, color: color, size: 12),
            ],
          ),
        ),
      );

  Widget _quickActionCard({
    required IconData icon,
    required String label,
    required String sub,
    required List<Color> gradient,
    required Color iconBg,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: gradient,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          border: Border.all(color: Colors.black, width: 3),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.7),
              blurRadius: 0,
              offset: const Offset(5, 5),
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned.fill(
              child: CustomPaint(painter: _PixelGridPainter()),
            ),
            Positioned(
              right: -18,
              bottom: -18,
              child: Icon(
                icon,
                size: 90,
                color: Colors.white.withOpacity(0.08),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.3),
                      border: Border.all(color: Colors.white.withOpacity(0.4), width: 2),
                    ),
                    child: Icon(icon, color: Colors.white, size: 26),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          label,
                          style: _mcText(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                            shadows: const [
                              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                            ],
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          sub,
                          style: _mcText(fontSize: 11, color: Colors.white70),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.3),
                      border: Border.all(color: Colors.white.withOpacity(0.4), width: 2),
                    ),
                    child: const Icon(
                      Icons.arrow_forward_rounded,
                      color: Colors.white,
                      size: 18,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContactCard({
    required IconData icon,
    required String label,
    required String subtitle,
    required Color color,
    required String url,
  }) =>
      GestureDetector(
        onTap: () => _openUrl(url),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
          decoration: BoxDecoration(
            color: bgCard,
            border: Border.all(color: borderLight, width: 2),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.6),
                blurRadius: 0,
                offset: const Offset(4, 4),
              )
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.2),
                  border: Border.all(color: color, width: 2),
                ),
                child: Icon(icon, color: color, size: 18),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      label,
                      style: _mcText(fontSize: 13, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: _mcText(fontSize: 11, color: textSub),
                    ),
                  ],
                ),
              ),
              Icon(Icons.arrow_forward_ios, color: textSub, size: 13),
            ],
          ),
        ),
      );

  void _showInfoDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: bgCard,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(4),
          side: const BorderSide(color: accentWhite, width: 3),
        ),
        title: Row(
          children: [
            const Icon(Icons.info_outline, color: accentWhite),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                "Info & Pengumuman",
                style: _mcText(fontSize: 14, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        content: Text(
          " Update Terbaru\n\n"
          "• Penambahan Tools Banyak Sekaligus\n"
          "• Memperbagus Dashboard\n"
          "• Dan Lain Lain!\n\n"
          "Terima kasih telah menggunakan Ocha Project!",
          style: _mcText(fontSize: 12, color: textSub, height: 1.8),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              backgroundColor: accentWhite,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(2),
                side: const BorderSide(color: Colors.black, width: 2),
              ),
            ),
            child: Text(
              "Tutup",
              style: _mcText(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.black),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCustomDrawer() {
    return Drawer(
      backgroundColor: bgSurface,
      child: SafeArea(
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: bgCard,
                border: const Border(
                  bottom: BorderSide(color: accentWhite, width: 3),
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      color: bgSurface,
                      border: Border.all(color: accentWhite, width: 3),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.6),
                          blurRadius: 0,
                          offset: const Offset(3, 3),
                        )
                      ],
                    ),
                    child: _profileImage != null
                        ? Image.file(_profileImage!, fit: BoxFit.cover)
                        : const Icon(Icons.person_rounded, color: accentWhite, size: 30),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          username,
                          style: _mcText(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            shadows: const [
                              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                            ],
                          ),
                        ),
                        const SizedBox(height: 4),
                        _roleBadge(role.toUpperCase()),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                children: [
                  if (role == 'seller' || role == 'reseller')
                    _buildDrawerMenuItem(
                      icon: Icons.storefront_rounded,
                      label: "Seller Page",
                      onTap: () => _onSidebarTabSelected(1),
                    ),
                  if (role == 'admin')
                    _buildDrawerMenuItem(
                      icon: Icons.admin_panel_settings_rounded,
                      label: "Admin Page",
                      onTap: () => _onSidebarTabSelected(2),
                    ),
                  if (role == 'partner')
                    _buildDrawerMenuItem(
                      icon: FontAwesomeIcons.handshake,
                      label: "Partner Page",
                      onTap: () => _onSidebarTabSelected(3),
                    ),
                  if (role == 'moderator')
                    _buildDrawerMenuItem(
                      icon: FontAwesomeIcons.userShield,
                      label: "Moderator Page",
                      onTap: () => _onSidebarTabSelected(4),
                    ),
                  if (role == 'owner')
                    _buildDrawerMenuItem(
                      icon: Icons.workspace_premium_rounded,
                      label: "Owner Page",
                      onTap: () => _onSidebarTabSelected(5),
                    ),
                  _buildDrawerMenuItem(
                    icon: Icons.history_rounded,
                    label: "Riwayat Aktivitas",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => RiwayatPage(
                            sessionKey: sessionKey,
                            role: role,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDrawerMenuItem(
                    icon: Icons.lock_outline_rounded,
                    label: "Ganti Password",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ChangePasswordPage(
                            username: username,
                            sessionKey: sessionKey,
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 8),
                  _buildDrawerMenuItem(
                    icon: Icons.logout_rounded,
                    label: "Log Out",
                    isLogout: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(builder: (_) => const LoginPage()),
                        (route) => false,
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDrawerMenuItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    final color = isLogout ? mcRedstone : textMain;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      decoration: BoxDecoration(
        color: isLogout ? mcRedstone.withOpacity(0.1) : bgCard,
        border: Border.all(
          color: isLogout ? mcRedstone : borderLight,
          width: 2,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 0,
            offset: const Offset(3, 3),
          )
        ],
      ),
      child: ListTile(
        leading: Icon(icon, color: color, size: 20),
        title: Text(
          label,
          style: _mcText(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: isLogout ? mcRedstone : textMain,
          ),
        ),
        trailing: Icon(Icons.arrow_forward_ios, color: textSub, size: 12),
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        dense: true,
        onTap: onTap,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgMain,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text(
          "Hai, $username",
          style: _mcText(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            shadows: const [
              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
            ],
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: textMain),
        actions: [
          IconButton(
            icon: Icon(Icons.headset_mic_outlined, color: textSub),
            tooltip: 'Customer Service',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const ContactPage()),
            ),
          ),
          IconButton(
            icon: const Icon(FontAwesomeIcons.userCircle, color: Colors.white70),
            tooltip: 'My Profile',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ProfilePage(
                  username: username,
                  password: password,
                  role: role,
                  expiredDate: expiredDate,
                  sessionKey: sessionKey,
                  uid: uid,
                ),
              ),
            ),
          ),
        ],
      ),
      drawer: _buildCustomDrawer(),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgMain, bgSurface, bgMain],
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _animation,
            child: _selectedPage,
          ),
        ),
      ),
      extendBody: true,
      bottomNavigationBar: Container(
        padding: EdgeInsets.zero,
        decoration: BoxDecoration(
          color: bgCard,
          border: const Border(
            top: BorderSide(color: accentWhite, width: 3),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.7),
              blurRadius: 0,
              offset: const Offset(0, -4),
            )
          ],
        ),
        child: GlazeNavBar(
          key: _navBarKey,
          index: _bottomNavIndex,
          backgroundColor: Colors.transparent,
          items: [
            GlazeNavBarItem(
              child: Icon(
                Icons.home_rounded,
                color: _bottomNavIndex == 0 ? accentWhite : textSub,
                size: 26,
              ),
              label: 'Home',
              labelStyle: TextStyle(
                color: _bottomNavIndex == 0 ? accentWhite : textSub,
                fontSize: 11,
              ),
            ),
            GlazeNavBarItem(
              child: Icon(
                FontAwesomeIcons.whatsapp,
                color: _bottomNavIndex == 1 ? accentWhite : textSub,
                size: 26,
              ),
              label: 'WhatsApp',
              labelStyle: TextStyle(
                color: _bottomNavIndex == 1 ? accentWhite : textSub,
                fontSize: 11,
              ),
            ),
            GlazeNavBarItem(
              child: Icon(
                Icons.notifications_rounded,
                color: _bottomNavIndex == 2 ? accentWhite : textSub,
                size: 26,
              ),
              label: 'Info',
              labelStyle: TextStyle(
                color: _bottomNavIndex == 2 ? accentWhite : textSub,
                fontSize: 11,
              ),
            ),
            GlazeNavBarItem(
              child: Icon(
                Icons.build_rounded,
                color: _bottomNavIndex == 3 ? accentWhite : textSub,
                size: 26,
              ),
              label: 'Tools',
              labelStyle: TextStyle(
                color: _bottomNavIndex == 3 ? accentWhite : textSub,
                fontSize: 11,
              ),
            ),
          ],
          onTap: (index) {
            _onBottomNavTapped(index);
          },
        ),
      ),
    );
  }
}

// ===== MINECRAFT PIXEL GRID PAINTER =====
class _PixelGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.04)
      ..strokeWidth = 1;
    const step = 8.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// NEWS MEDIA WIDGET
class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(0.0);
          _controller?.play();
        });
    }
  }

  bool _isVideo(String url) =>
      url.endsWith('.mp4') ||
      url.endsWith('.webm') ||
      url.endsWith('.mov') ||
      url.endsWith('.mkv');

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(
          aspectRatio: _controller!.value.aspectRatio,
          child: VideoPlayer(_controller!),
        );
      }
      return const Center(
        child: CircularProgressIndicator(color: Color(0xFF4CAF50)),
      );
    }
    return Image.network(
      widget.url,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(
        color: const Color(0xFF2D2D2D),
        child: const Icon(Icons.error, color: Colors.grey),
      ),
    );
  }
}