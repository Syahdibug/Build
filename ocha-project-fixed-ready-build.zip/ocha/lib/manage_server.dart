import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ManageServerPage extends StatefulWidget {
  final String keyToken;
  const ManageServerPage({super.key, required this.keyToken});

  @override
  State<ManageServerPage> createState() => _ManageServerPageState();
}

class _ManageServerPageState extends State<ManageServerPage> {
  List<Map<String, dynamic>> vpsList = [];
  bool isLoading = false;

  final _hostController = TextEditingController();
  final _userController = TextEditingController();
  final _passController = TextEditingController();

  // ===== COLOR PALETTE - MINECRAFT THEME =====
  static const Color bgMain = Color(0xFF1A1A1A);          // Obsidian
  static const Color bgSurface = Color(0xFF2D2D2D);       // Stone
  static const Color bgCard = Color(0xFF3D3D3D);          // Cobblestone
  static const Color textMain = Color(0xFFE8E8E8);        // White wool
  static const Color textSub = Color(0xFFAAAAAA);         // Gray
  static const Color accentWhite = Color(0xFF4CAF50);     // Grass green
  static const Color borderLight = Color(0xFF5D5D5D);     // Stone border
  static const Color mcGold = Color(0xFFFFD700);          // Gold
  static const Color mcDiamond = Color(0xFF4DD0E1);       // Diamond
  static const Color mcRedstone = Color(0xFFFF5252);      // Redstone
  static const Color mcEmerald = Color(0xFF00E676);       // Emerald

  @override
  void initState() {
    super.initState();
    _fetchVpsList();
  }

  Future<void> _fetchVpsList() async {
    setState(() => isLoading = true);
    final uri = Uri.parse('http://dwixclouds.cloudnesia.my.id:3013/myServer?key=${widget.keyToken}');
    try {
      final res = await http.get(uri);
      final data = jsonDecode(res.body);
      setState(() {
        vpsList = List<Map<String, dynamic>>.from(data);
      });
    } catch (_) {
      _showError("Gagal mengambil data VPS.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _addVps() async {
    final host = _hostController.text.trim();
    final user = _userController.text.trim();
    final pass = _passController.text.trim();

    if (host.isEmpty || user.isEmpty || pass.isEmpty) {
      _showError("Isi semua field terlebih dahulu.");
      return;
    }

    final uri = Uri.parse('http://dwixclouds.cloudnesia.my.id:3013/addServer');
    try {
      final res = await http.post(uri, body: {
        'key': widget.keyToken,
        'host': host,
        'username': user,
        'password': pass,
      });
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        _hostController.clear();
        _userController.clear();
        _passController.clear();
        _fetchVpsList();
      } else {
        _showError(data['error'] ?? 'Gagal menambah VPS');
      }
    } catch (_) {
      _showError("Gagal terhubung ke server.");
    }
  }

  Future<void> _deleteVps(String host) async {
    final uri = Uri.parse('http://dwixclouds.cloudnesia.my.id:3013/delServer');
    try {
      final res = await http.post(uri, body: {
        'key': widget.keyToken,
        'host': host,
      });
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        _fetchVpsList();
      } else {
        _showError("Gagal menghapus VPS.");
      }
    } catch (_) {
      _showError("Gagal menghubungi server.");
    }
  }

  // ===== ERROR DIALOG - MINECRAFT STYLE =====
  void _showError(String msg) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.75),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: bgCard,
            borderRadius: BorderRadius.circular(4),
            border: Border.all(color: mcRedstone, width: 3),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.8),
                blurRadius: 0,
                offset: const Offset(8, 8),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: bgSurface,
                  border: Border.all(color: mcRedstone, width: 3),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.6),
                      blurRadius: 0,
                      offset: const Offset(4, 4),
                    )
                  ],
                ),
                child: const Icon(Icons.error_outline, color: mcRedstone, size: 32),
              ),
              const SizedBox(height: 16),
              const Text(
                "ERROR",
                style: TextStyle(
                  color: textMain,
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.5,
                  shadows: [
                    Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Text(
                msg,
                style: const TextStyle(color: textSub, fontSize: 12),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: mcRedstone,
                    foregroundColor: Colors.white,
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero,
                      side: BorderSide(color: Colors.black, width: 2),
                    ),
                    elevation: 0,
                  ),
                  child: const Text(
                    "OK",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                      letterSpacing: 1.5,
                      shadows: [
                        Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ===== ADD VPS DIALOG - MINECRAFT STYLE =====
  void _showAddDialog() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.75),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: bgCard,
            borderRadius: BorderRadius.circular(4),
            border: Border.all(color: accentWhite, width: 3),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.8),
                blurRadius: 0,
                offset: const Offset(8, 8),
              ),
            ],
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: bgSurface,
                    border: Border.all(color: accentWhite, width: 3),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.6),
                        blurRadius: 0,
                        offset: const Offset(4, 4),
                      )
                    ],
                  ),
                  child: const Icon(Icons.dns_rounded, color: accentWhite, size: 32),
                ),
                const SizedBox(height: 16),
                const Text(
                  "TAMBAH VPS",
                  style: TextStyle(
                    color: textMain,
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.5,
                    shadows: [
                      Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                    ],
                  ),
                ),
                const SizedBox(height: 24),

                _buildInput("IP VPS", _hostController),
                _buildInput("Username", _userController),
                _buildInput("Password", _passController),

                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 50,
                        child: TextButton(
                          onPressed: () => Navigator.pop(context),
                          style: TextButton.styleFrom(
                            backgroundColor: bgSurface,
                            shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero,
                              side: BorderSide(color: borderLight, width: 2),
                            ),
                          ),
                          child: const Text(
                            "BATAL",
                            style: TextStyle(
                              color: textMain,
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: SizedBox(
                        height: 50,
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.pop(context);
                            _addVps();
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: accentWhite,
                            foregroundColor: Colors.white,
                            shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero,
                              side: BorderSide(color: Colors.black, width: 2),
                            ),
                            elevation: 0,
                          ),
                          child: const Text(
                            "TAMBAH",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                              letterSpacing: 1,
                              shadows: [
                                Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ===== INPUT FIELD - MINECRAFT STYLE =====
  Widget _buildInput(String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextField(
        controller: controller,
        style: const TextStyle(
          color: textMain,
          fontSize: 13,
          fontWeight: FontWeight.bold,
        ),
        cursorColor: accentWhite,
        cursorWidth: 3,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(
            color: accentWhite,
            fontSize: 12,
            fontWeight: FontWeight.bold,
          ),
          floatingLabelStyle: const TextStyle(
            color: accentWhite,
            fontSize: 12,
            fontWeight: FontWeight.bold,
          ),
          filled: true,
          fillColor: bgSurface,
          enabledBorder: const OutlineInputBorder(
            borderSide: BorderSide(color: accentWhite, width: 3),
            borderRadius: BorderRadius.zero,
          ),
          focusedBorder: const OutlineInputBorder(
            borderSide: BorderSide(color: mcGold, width: 3),
            borderRadius: BorderRadius.zero,
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgMain,
      appBar: AppBar(
        backgroundColor: bgMain,
        elevation: 0,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: bgCard,
              border: Border.all(color: accentWhite, width: 2),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.6),
                  blurRadius: 0,
                  offset: const Offset(2, 2),
                )
              ],
            ),
            child: const Icon(Icons.arrow_back_ios_new, color: textMain, size: 16),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          "MANAGE SERVER",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 14,
            letterSpacing: 1.5,
            color: textMain,
            shadows: [
              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
            ],
          ),
        ),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(3),
          child: Container(
            height: 3,
            color: accentWhite,
          ),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgMain, bgSurface, bgMain],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // HEADER - MINECRAFT STYLE
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: bgCard,
                            border: Border.all(color: accentWhite, width: 2),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.5),
                                blurRadius: 0,
                                offset: const Offset(2, 2),
                              )
                            ],
                          ),
                          child: const Icon(Icons.dns_rounded, color: accentWhite, size: 20),
                        ),
                        const SizedBox(width: 12),
                        const Text(
                          "MY VPS LIST",
                          style: TextStyle(
                            fontSize: 14,
                            color: textMain,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.5,
                            shadows: [
                              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                            ],
                          ),
                        ),
                      ],
                    ),
                    Container(
                      decoration: BoxDecoration(
                        color: bgCard,
                        border: Border.all(color: accentWhite, width: 2),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.5),
                            blurRadius: 0,
                            offset: const Offset(2, 2),
                          )
                        ],
                      ),
                      child: IconButton(
                        icon: const Icon(Icons.add, color: accentWhite, size: 22),
                        onPressed: _showAddDialog,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Container(height: 3, color: accentWhite),
                const SizedBox(height: 16),

                // LIST VPS
                Expanded(
                  child: isLoading
                      ? const Center(
                          child: CircularProgressIndicator(
                            color: accentWhite,
                            strokeWidth: 3,
                          ),
                        )
                      : vpsList.isEmpty
                          ? Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(30),
                                    decoration: BoxDecoration(
                                      color: bgCard,
                                      border: Border.all(color: borderLight, width: 3),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.black.withOpacity(0.6),
                                          blurRadius: 0,
                                          offset: const Offset(5, 5),
                                        )
                                      ],
                                    ),
                                    child: const Icon(Icons.dns_outlined, color: textSub, size: 48),
                                  ),
                                  const SizedBox(height: 20),
                                  const Text(
                                    "Belum ada VPS tersimpan",
                                    style: TextStyle(
                                      color: textMain,
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      shadows: [
                                        Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : ListView.builder(
                              itemCount: vpsList.length,
                              itemBuilder: (context, index) {
                                final vps = vpsList[index];
                                return Container(
                                  margin: const EdgeInsets.only(bottom: 12),
                                  padding: const EdgeInsets.all(14),
                                  decoration: BoxDecoration(
                                    color: bgCard,
                                    border: Border.all(color: borderLight, width: 2),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withOpacity(0.6),
                                        blurRadius: 0,
                                        offset: const Offset(3, 3),
                                      ),
                                    ],
                                  ),
                                  child: Row(
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                          color: bgSurface,
                                          border: Border.all(color: accentWhite, width: 2),
                                        ),
                                        child: const Icon(Icons.dns, color: accentWhite, size: 20),
                                      ),
                                      const SizedBox(width: 14),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              "${vps['host']}",
                                              style: const TextStyle(
                                                color: textMain,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 13,
                                                shadows: [
                                                  Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                                                ],
                                              ),
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                            const SizedBox(height: 4),
                                            Text(
                                              "User: ${vps['username']}",
                                              style: const TextStyle(
                                                color: textSub,
                                                fontSize: 11,
                                              ),
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ],
                                        ),
                                      ),
                                      GestureDetector(
                                        onTap: () => _deleteVps(vps['host']),
                                        child: Container(
                                          padding: const EdgeInsets.all(8),
                                          decoration: BoxDecoration(
                                            color: bgSurface,
                                            border: Border.all(color: mcRedstone, width: 2),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Colors.black.withOpacity(0.5),
                                                blurRadius: 0,
                                                offset: const Offset(2, 2),
                                              )
                                            ],
                                          ),
                                          child: const Icon(Icons.delete, color: mcRedstone, size: 18),
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}