import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';

class DomainOsintPage extends StatefulWidget {
  const DomainOsintPage({super.key});

  @override
  State<DomainOsintPage> createState() => _DomainOsintPageState();
}

class _DomainOsintPageState extends State<DomainOsintPage> {
  final TextEditingController _domainController = TextEditingController();
  bool _isLoading = false;
  Map<String, dynamic>? _dnsData;
  List<dynamic>? _subdomainsData;
  String? _errorMessage;

  // ===== COLOR PALETTE - MINECRAFT THEME =====
  static const Color bgMain = Color(0xFF1A1A1A);
  static const Color bgSurface = Color(0xFF2D2D2D);
  static const Color bgCard = Color(0xFF3D3D3D);
  static const Color textMain = Color(0xFFE8E8E8);
  static const Color textSub = Color(0xFFAAAAAA);
  static const Color accentWhite = Color(0xFF4CAF50);
  static const Color borderLight = Color(0xFF5D5D5D);
  static const Color mcGold = Color(0xFFFFD700);
  static const Color mcDiamond = Color(0xFF4DD0E1);
  static const Color mcRedstone = Color(0xFFFF5252);
  static const Color mcEmerald = Color(0xFF00E676);

  Future<void> _checkDomain() async {
    final domain = _domainController.text.trim();
    if (domain.isEmpty) {
      setState(() {
        _errorMessage = "Domain tidak boleh kosong.";
        _dnsData = null;
        _subdomainsData = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _dnsData = null;
      _subdomainsData = null;
    });

    try {
      final dnsResult = await _fetchDnsInfo(domain);
      final subdoResult = await _fetchSubdomains(domain);

      if (dnsResult != null && subdoResult != null) {
        setState(() {
          _dnsData = dnsResult;
          _subdomainsData = subdoResult;
        });
      } else {
        setState(() {
          _errorMessage = "Gagal mengambil data domain.";
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = "Terjadi kesalahan: $e";
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<Map<String, dynamic>?> _fetchDnsInfo(String domain) async {
    final url = Uri.parse("https://api.siputzx.my.id/api/tools/dns?domain=$domain");
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final json = jsonDecode(response.body);
      return json['status'] == true ? json['data'] : null;
    }
    return null;
  }

  Future<List<dynamic>?> _fetchSubdomains(String domain) async {
    final url = Uri.parse("https://api.siputzx.my.id/api/tools/subdomains?domain=$domain");
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final json = jsonDecode(response.body);
      return json['status'] == true ? json['data'] : null;
    }
    return null;
  }

  void _copyToClipboard(String text, String label) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          '$label disalin!',
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 12,
          ),
        ),
        backgroundColor: accentWhite,
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.zero,
          side: BorderSide(color: Colors.black, width: 2),
        ),
      ),
    );
  }

  // ===== CATEGORY CARD - MINECRAFT =====
  Widget _buildCategoryCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: bgCard,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: accentWhite, width: 3),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.7),
            blurRadius: 0,
            offset: const Offset(5, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Category Header - MINECRAFT
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(
              color: bgSurface,
              border: Border(
                bottom: BorderSide(color: accentWhite, width: 3),
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: bgCard,
                    border: Border.all(color: accentWhite, width: 2),
                  ),
                  child: Icon(icon, color: accentWhite, size: 18),
                ),
                const SizedBox(width: 12),
                Text(
                  title,
                  style: const TextStyle(
                    color: textMain,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.5,
                    shadows: [
                      Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: children,
            ),
          ),
        ],
      ),
    );
  }

  // ===== INFO ROW - MINECRAFT =====
  Widget _buildInfoRow({
    required String label,
    required String? value,
    bool showCopyButton = false,
  }) {
    if (value == null || value.isEmpty) return const SizedBox.shrink();

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: bgSurface,
        border: Border.all(color: borderLight, width: 2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 0,
            offset: const Offset(3, 3),
          )
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label.toUpperCase(),
                  style: const TextStyle(
                    color: textSub,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: const TextStyle(
                    color: textMain,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    shadows: [
                      Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (showCopyButton)
            GestureDetector(
              onTap: () => _copyToClipboard(value, label),
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: bgCard,
                  border: Border.all(color: accentWhite, width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.5),
                      blurRadius: 0,
                      offset: const Offset(2, 2),
                    )
                  ],
                ),
                child: const Icon(Icons.copy, color: accentWhite, size: 16),
              ),
            ),
        ],
      ),
    );
  }

  List<Widget> _buildDnsRecords() {
    if (_dnsData == null || _dnsData!['records'] == null) return [];

    final records = _dnsData!['records'] as Map<String, dynamic>;
    final widgets = <Widget>[];

    // NS Records
    if (records['ns']?['response']?['answer'] != null) {
      final nsRecords = records['ns']!['response']!['answer'] as List;
      if (nsRecords.isNotEmpty) {
        widgets.addAll([
          const Text(
            'NAME SERVERS',
            style: TextStyle(
              color: textMain,
              fontSize: 12,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.2,
              shadows: [
                Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
              ],
            ),
          ),
          const SizedBox(height: 8),
          ...nsRecords.map((record) => _buildInfoRow(
            label: 'NS Record',
            value: record['record']?['target']?.toString(),
            showCopyButton: true,
          )),
          const SizedBox(height: 16),
        ]);
      }
    }

    // SOA Record
    if (records['soa']?['response']?['answer'] != null) {
      final soaRecords = records['soa']!['response']!['answer'] as List;
      if (soaRecords.isNotEmpty) {
        final soa = soaRecords.first['record'];
        widgets.addAll([
          const Text(
            'SOA RECORD',
            style: TextStyle(
              color: textMain,
              fontSize: 12,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.2,
              shadows: [
                Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
              ],
            ),
          ),
          const SizedBox(height: 8),
          _buildInfoRow(
            label: 'Primary NS',
            value: soa?['host']?.toString(),
            showCopyButton: true,
          ),
          _buildInfoRow(
            label: 'Admin Email',
            value: soa?['admin']?.toString(),
            showCopyButton: true,
          ),
          _buildInfoRow(
            label: 'Serial',
            value: soa?['serial']?.toString(),
          ),
          _buildInfoRow(
            label: 'Refresh',
            value: soa?['refresh']?.toString(),
          ),
          _buildInfoRow(
            label: 'Retry',
            value: soa?['retry']?.toString(),
          ),
          _buildInfoRow(
            label: 'Expire',
            value: soa?['expire']?.toString(),
          ),
          _buildInfoRow(
            label: 'Minimum TTL',
            value: soa?['minimum']?.toString(),
          ),
          const SizedBox(height: 16),
        ]);
      }
    }

    // A Records
    if (records['a']?['response']?['answer'] != null) {
      final aRecords = records['a']!['response']!['answer'] as List;
      if (aRecords.isNotEmpty) {
        widgets.addAll([
          const Text(
            'A RECORDS',
            style: TextStyle(
              color: textMain,
              fontSize: 12,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.2,
              shadows: [
                Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
              ],
            ),
          ),
          const SizedBox(height: 8),
          ...aRecords.map((record) => _buildInfoRow(
            label: 'A Record',
            value: record['record']?['data']?.toString(),
            showCopyButton: true,
          )),
        ]);
      }
    }

    return widgets;
  }

  List<Widget> _buildSubdomainsList() {
    if (_subdomainsData == null) return [];

    final cleanSubdomains = _subdomainsData!
        .map((item) => item.toString().split('\n').last.trim())
        .where((subdomain) => subdomain.isNotEmpty && !subdomain.startsWith('*'))
        .toSet()
        .toList()
      ..sort();

    return [
      Text(
        'Ditemukan ${cleanSubdomains.length} subdomain',
        style: const TextStyle(
          color: textSub,
          fontSize: 11,
          fontWeight: FontWeight.bold,
        ),
      ),
      const SizedBox(height: 12),
      ...cleanSubdomains.map((subdomain) => Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: bgSurface,
              border: Border.all(color: borderLight, width: 2),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.5),
                  blurRadius: 0,
                  offset: const Offset(2, 2),
                )
              ],
            ),
            child: Row(
              children: [
                const Icon(Icons.link, color: accentWhite, size: 16),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    subdomain,
                    style: const TextStyle(
                      color: textMain,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () => _copyToClipboard(subdomain, 'Subdomain'),
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: bgCard,
                      border: Border.all(color: accentWhite, width: 2),
                    ),
                    child: const Icon(Icons.copy, color: accentWhite, size: 14),
                  ),
                ),
              ],
            ),
          )).toList(),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgMain,
      appBar: AppBar(
        title: const Text(
          'DOMAIN OSINT',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 14,
            letterSpacing: 1.5,
            color: textMain,
            shadows: [
              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
            ],
          ),
        ),
        backgroundColor: bgMain,
        centerTitle: true,
        iconTheme: const IconThemeData(color: textMain),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(3),
          child: Container(height: 3, color: accentWhite),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgMain, bgSurface, bgMain],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                // ===== INPUT SECTION - MINECRAFT =====
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: bgCard,
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: accentWhite, width: 3),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.7),
                        blurRadius: 0,
                        offset: const Offset(5, 5),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      TextField(
                        controller: _domainController,
                        style: const TextStyle(
                          color: textMain,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                        cursorColor: accentWhite,
                        cursorWidth: 3,
                        decoration: InputDecoration(
                          labelText: 'Masukkan Domain',
                          labelStyle: const TextStyle(
                            color: accentWhite,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                          floatingLabelStyle: const TextStyle(
                            color: accentWhite,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                          hintText: 'Contoh: nullxteam.fun',
                          hintStyle: TextStyle(
                            color: Colors.white.withOpacity(0.25),
                            fontSize: 12,
                          ),
                          enabledBorder: const OutlineInputBorder(
                            borderSide: BorderSide(color: accentWhite, width: 3),
                            borderRadius: BorderRadius.zero,
                          ),
                          focusedBorder: const OutlineInputBorder(
                            borderSide: BorderSide(color: mcGold, width: 3),
                            borderRadius: BorderRadius.zero,
                          ),
                          filled: true,
                          fillColor: bgSurface,
                          suffixIcon: _isLoading
                              ? const Padding(
                                  padding: EdgeInsets.all(12.0),
                                  child: SizedBox(
                                    width: 18,
                                    height: 18,
                                    child: CircularProgressIndicator(
                                      color: accentWhite,
                                      strokeWidth: 3,
                                    ),
                                  ),
                                )
                              : null,
                        ),
                        onSubmitted: (_) => _checkDomain(),
                      ),
                      const SizedBox(height: 16),
                      SizedBox(
                        width: double.infinity,
                        height: 54,
                        child: ElevatedButton(
                          onPressed: _isLoading ? null : _checkDomain,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: accentWhite,
                            foregroundColor: Colors.white,
                            shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero,
                              side: BorderSide(color: Colors.black, width: 3),
                            ),
                            elevation: 0,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                _isLoading ? Icons.hourglass_top : Icons.search,
                                size: 20,
                                color: Colors.white,
                              ),
                              const SizedBox(width: 8),
                              Text(
                                _isLoading ? 'MEMPROSES...' : 'CEK DOMAIN',
                                style: const TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1.5,
                                  color: Colors.white,
                                  shadows: [
                                    Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // ===== ERROR MESSAGE - MINECRAFT =====
                if (_errorMessage != null)
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: bgCard,
                      border: Border.all(color: mcRedstone, width: 3),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.7),
                          blurRadius: 0,
                          offset: const Offset(4, 4),
                        )
                      ],
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.error_outline, color: mcRedstone, size: 24),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            _errorMessage!,
                            style: const TextStyle(
                              color: textMain,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                const SizedBox(height: 20),

                // ===== RESULTS SECTION =====
                if (_dnsData != null || _subdomainsData != null)
                  Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          // Domain Information
                          if (_dnsData != null)
                            _buildCategoryCard(
                              title: "INFORMASI DOMAIN",
                              icon: Icons.domain,
                              children: [
                                _buildInfoRow(
                                  label: "Domain",
                                  value: _dnsData!['unicodeDomain']?.toString(),
                                  showCopyButton: true,
                                ),
                                _buildInfoRow(
                                  label: "Punycode",
                                  value: _dnsData!['punycodeDomain']?.toString(),
                                  showCopyButton: true,
                                ),
                                ..._buildDnsRecords(),
                              ],
                            ),

                          const SizedBox(height: 16),

                          // Subdomains
                          if (_subdomainsData != null)
                            _buildCategoryCard(
                              title: "SUBDOMAINS",
                              icon: Icons.list,
                              children: _buildSubdomainsList(),
                            ),

                          const SizedBox(height: 16),

                          // Server Information
                          if (_dnsData != null && _dnsData!['records'] != null)
                            _buildCategoryCard(
                              title: "INFORMASI SERVER",
                              icon: Icons.dns,
                              children: [
                                if (_dnsData!['records']['a']?['query']?['server'] != null)
                                  _buildInfoRow(
                                    label: "DNS Server",
                                    value: _dnsData!['records']['a']!['query']!['server']!['ip']?.toString(),
                                    showCopyButton: true,
                                  ),
                                if (_dnsData!['records']['a']?['query']?['server']?['location'] != null)
                                  _buildInfoRow(
                                    label: "Lokasi Server",
                                    value: "Lat: ${_dnsData!['records']['a']!['query']!['server']!['location']!['lat']}, Lon: ${_dnsData!['records']['a']!['query']!['server']!['location']!['lon']}",
                                  ),
                              ],
                            ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}