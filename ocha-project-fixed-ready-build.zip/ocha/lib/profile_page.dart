import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter/services.dart';
import 'change_password_page.dart';

class ProfilePage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final String? uid;

  const ProfilePage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    this.uid,
  });

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> with TickerProviderStateMixin {
  File? _profileImage;
  final ImagePicker _picker = ImagePicker();

  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  // ===== COLOR PALETTE - MINECRAFT THEME =====
  static const Color bgMain = Color(0xFF1A1A1A);          // Obsidian
  static const Color bgSurface = Color(0xFF2D2D2D);       // Stone
  static const Color bgCard = Color(0xFF3D3D3D);          // Cobblestone
  static const Color textMain = Color(0xFFE8E8E8);        // White wool
  static const Color textSub = Color(0xFFAAAAAA);         // Gray
  static const Color accentWhite = Color(0xFF4CAF50);     // Grass green
  static const Color borderLight = Color(0xFF5D5D5D);     // Stone border
  static const Color mcGold = Color(0xFFFFD700);          // Gold
  static const Color mcDiamond = Color(0xFF4DD0E1);       // Diamond
  static const Color mcRedstone = Color(0xFFFF5252);      // Redstone
  static const Color mcEmerald = Color(0xFF00E676);       // Emerald

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.15, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
    _loadProfileImage();
  }

  @override
  void dispose() {
    _glowController.dispose();
    super.dispose();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_${widget.username}');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  String _censorText(String text, {bool isPassword = false}) {
    if (text.isEmpty) return "N/A";
    if (isPassword) return "••••••••";
    if (text.length <= 2) return "${text.substring(0, 1)}••";
    return "${text.substring(0, 2)}${'•' * (text.length - 2)}";
  }

  Future<void> _showImageSourceDialog() {
    return showModalBottomSheet(
      context: context,
      backgroundColor: bgCard,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.zero,
      ),
      builder: (context) => Container(
        decoration: const BoxDecoration(
          border: Border(
            top: BorderSide(color: accentWhite, width: 3),
          ),
        ),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 12),
              Container(
                width: 40,
                height: 4,
                color: borderLight,
              ),
              const SizedBox(height: 16),
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: bgSurface,
                    border: Border.all(color: accentWhite, width: 2),
                  ),
                  child: const Icon(Icons.camera_alt, color: accentWhite, size: 18),
                ),
                title: const Text(
                  "Kamera",
                  style: TextStyle(
                    color: textMain,
                    fontSize: 13,
                    letterSpacing: 1,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.camera);
                },
              ),
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: bgSurface,
                    border: Border.all(color: mcGold, width: 2),
                  ),
                  child: const Icon(Icons.photo_library, color: mcGold, size: 18),
                ),
                title: const Text(
                  "Galeri",
                  style: TextStyle(
                    color: textMain,
                    fontSize: 13,
                    letterSpacing: 1,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.gallery);
                },
              ),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
        source: source,
        imageQuality: 70,
      );
      if (pickedFile != null) {
        final File imageFile = File(pickedFile.path);
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('profile_image_${widget.username}', imageFile.path);
        setState(() {
          _profileImage = imageFile;
        });
      }
    } catch (e) {
      debugPrint("Error picking image: $e");
    }
  }

  Widget _buildRoleBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        color: bgCard,
        border: Border.all(color: accentWhite, width: 2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            blurRadius: 0,
            offset: const Offset(3, 3),
          )
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: accentWhite,
              boxShadow: [
                BoxShadow(
                  color: accentWhite.withOpacity(0.5),
                  blurRadius: 6,
                  spreadRadius: 1,
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            widget.role.toUpperCase(),
            style: const TextStyle(
              color: textMain,
              fontSize: 11,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
              shadows: [
                Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoCard({
    required IconData icon,
    required String label,
    required String value,
    bool fullWidth = false,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: fullWidth ? 18 : 14,
        vertical: 16,
      ),
      decoration: BoxDecoration(
        color: bgCard,
        border: Border.all(color: borderLight, width: 2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 0,
            offset: const Offset(3, 3),
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: bgSurface,
                  border: Border.all(color: accentWhite, width: 2),
                ),
                child: Icon(icon, color: accentWhite, size: 15),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  label,
                  style: const TextStyle(
                    color: textSub,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.5,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            value,
            style: const TextStyle(
              color: textMain,
              fontSize: 13,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.5,
              shadows: [
                Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
              ],
            ),
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
          ),
        ],
      ),
    );
  }

  Widget _buildChangePasswordButton() {
    return AnimatedBuilder(
      animation: _glowAnimation,
      builder: (context, _) {
        return Container(
          width: double.infinity,
          height: 58,
          decoration: BoxDecoration(
            color: bgCard,
            border: Border.all(
              color: accentWhite.withOpacity(0.5 + _glowAnimation.value * 0.5),
              width: 3,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.7),
                blurRadius: 0,
                offset: const Offset(5, 5),
              ),
              BoxShadow(
                color: accentWhite.withOpacity(_glowAnimation.value * 0.3),
                blurRadius: 15,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ChangePasswordPage(
                      username: widget.username,
                      sessionKey: widget.sessionKey,
                    ),
                  ),
                );
              },
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.lock_reset_rounded, color: accentWhite, size: 20),
                  SizedBox(width: 12),
                  Text(
                    "CHANGE PASSWORD",
                    style: TextStyle(
                      color: textMain,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                      shadows: [
                        Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildUidCard() {
    final String uid = widget.uid ?? 'Tidak ada UID';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      decoration: BoxDecoration(
        color: bgCard,
        border: Border.all(color: mcGold, width: 2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 0,
            offset: const Offset(3, 3),
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: bgSurface,
                  border: Border.all(color: mcGold, width: 2),
                ),
                child: const Icon(Icons.badge_rounded, color: mcGold, size: 15),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Text(
                  "UID / ID",
                  style: TextStyle(
                    color: textSub,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.5,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              // TOMBOL SALIN - MINECRAFT STYLE
              GestureDetector(
                onTap: () {
                  Clipboard.setData(ClipboardData(text: uid));
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: const Text(
                        'UID berhasil disalin!',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        ),
                      ),
                      backgroundColor: accentWhite,
                      behavior: SnackBarBehavior.floating,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero,
                        side: BorderSide(color: Colors.black, width: 2),
                      ),
                      duration: const Duration(seconds: 2),
                    ),
                  );
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: bgSurface,
                    border: Border.all(color: mcGold, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.5),
                        blurRadius: 0,
                        offset: const Offset(2, 2),
                      )
                    ],
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.copy_rounded, color: mcGold, size: 14),
                      SizedBox(width: 4),
                      Text(
                        "SALIN",
                        style: TextStyle(
                          color: mcGold,
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            uid,
            style: const TextStyle(
              color: mcGold,
              fontSize: 12,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.5,
              shadows: [
                Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
              ],
            ),
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgMain,
      appBar: AppBar(
        backgroundColor: bgMain,
        elevation: 0,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: bgCard,
              border: Border.all(color: accentWhite, width: 2),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.6),
                  blurRadius: 0,
                  offset: const Offset(2, 2),
                )
              ],
            ),
            child: const Icon(Icons.arrow_back_ios_new, color: textMain, size: 16),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          "MY PROFILE",
          style: TextStyle(
            color: textMain,
            fontWeight: FontWeight.bold,
            fontSize: 14,
            letterSpacing: 2,
            shadows: [
              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
            ],
          ),
        ),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(3),
          child: Container(
            height: 3,
            color: accentWhite,
          ),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgMain, bgSurface, bgMain],
          ),
        ),
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Column(
            children: [
              const SizedBox(height: 12),

              // --- AVATAR - MINECRAFT STYLE ---
              Center(
                child: GestureDetector(
                  onTap: _showImageSourceDialog,
                  child: Stack(
                    children: [
                      AnimatedBuilder(
                        animation: _glowAnimation,
                        builder: (context, _) {
                          return Container(
                            width: 110,
                            height: 110,
                            decoration: BoxDecoration(
                              color: bgCard,
                              border: Border.all(
                                color: accentWhite.withOpacity(0.5 + _glowAnimation.value * 0.5),
                                width: 3,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.7),
                                  blurRadius: 0,
                                  offset: const Offset(5, 5),
                                ),
                                BoxShadow(
                                  color: accentWhite.withOpacity(_glowAnimation.value * 0.3),
                                  blurRadius: 20,
                                  spreadRadius: 2,
                                ),
                              ],
                            ),
                            child: _profileImage != null
                                ? Image.file(
                                    _profileImage!,
                                    fit: BoxFit.cover,
                                  )
                                : Center(
                                    child: Icon(
                                      FontAwesomeIcons.userAstronaut,
                                      size: 40,
                                      color: textSub.withOpacity(0.5),
                                    ),
                                  ),
                          );
                        },
                      ),
                      Positioned(
                        bottom: 2,
                        right: 2,
                        child: Container(
                          padding: const EdgeInsets.all(7),
                          decoration: BoxDecoration(
                            color: bgCard,
                            border: Border.all(color: Colors.black, width: 3),
                            boxShadow: [
                              BoxShadow(
                                color: accentWhite.withOpacity(0.4),
                                blurRadius: 8,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                          child: const Icon(Icons.camera_alt, size: 14, color: accentWhite),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // --- USERNAME ---
              Text(
                widget.username,
                style: const TextStyle(
                  color: textMain,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                  shadows: [
                    Shadow(color: Colors.black, offset: Offset(3, 3), blurRadius: 0),
                  ],
                ),
              ),

              const SizedBox(height: 10),

              // --- ROLE BADGE ---
              _buildRoleBadge(),

              const SizedBox(height: 32),

              // --- SECTION TITLE ---
              _buildSectionTitle("ACCOUNT DATA"),

              const SizedBox(height: 14),

              // ROW 1
              Row(
                children: [
                  Expanded(child: _buildInfoCard(icon: Icons.person_outline, label: "USERNAME", value: _censorText(widget.username))),
                  const SizedBox(width: 12),
                  Expanded(child: _buildInfoCard(icon: Icons.lock_outline, label: "PASSWORD", value: _censorText(widget.password, isPassword: true))),
                ],
              ),

              const SizedBox(height: 12),

              // ROW 2
              Row(
                children: [
                  Expanded(child: _buildInfoCard(icon: Icons.verified_user_outlined, label: "ROLE", value: widget.role.toUpperCase())),
                  const SizedBox(width: 12),
                  Expanded(child: _buildInfoCard(icon: Icons.calendar_today_outlined, label: "EXPIRED", value: widget.expiredDate)),
                ],
              ),

              const SizedBox(height: 12),

              // ROW 3: SESSION KEY
              _buildInfoCard(
                icon: Icons.vpn_key_rounded,
                label: "SESSION KEY",
                value: "${widget.sessionKey.substring(0, 8)}...",
                fullWidth: true,
              ),

              const SizedBox(height: 12),

              // UID CARD
              _buildUidCard(),

              const SizedBox(height: 40),

              // --- CHANGE PASSWORD ---
              _buildChangePasswordButton(),

              const SizedBox(height: 32),

              // --- FOOTER ---
              _buildFooter(),

              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Row(
      children: [
        Container(
          width: 6,
          height: 16,
          decoration: BoxDecoration(
            color: accentWhite,
            border: Border.all(color: Colors.black, width: 1),
          ),
        ),
        const SizedBox(width: 10),
        Text(
          title,
          style: const TextStyle(
            color: textSub,
            fontSize: 10,
            fontWeight: FontWeight.bold,
            letterSpacing: 3,
            shadows: [
              Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildFooter() {
    return Column(
      children: [
        Container(
          height: 3,
          width: double.infinity,
          color: textSub.withOpacity(0.3),
        ),
        const SizedBox(height: 20),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 25,
              height: 2,
              color: borderLight,
            ),
            const SizedBox(width: 8),
            Container(
              width: 6,
              height: 6,
              color: borderLight,
            ),
            const SizedBox(width: 8),
            Container(
              width: 25,
              height: 2,
              color: borderLight,
            ),
          ],
        ),
        const SizedBox(height: 10),
        const Text(
          "OCHA PROJECT PROFILE",
          style: TextStyle(
            color: textSub,
            fontSize: 9,
            fontWeight: FontWeight.bold,
            letterSpacing: 3,
            shadows: [
              Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
            ],
          ),
        ),
      ],
    );
  }
}