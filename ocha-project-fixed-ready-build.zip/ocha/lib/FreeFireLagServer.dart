import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class FreeFireLagServerPage extends StatefulWidget {
  const FreeFireLagServerPage({super.key});

  @override
  State<FreeFireLagServerPage> createState() => _FreeFireLagServerPageState();
}

class _FreeFireLagServerPageState extends State<FreeFireLagServerPage> {
  bool _isAttacking = false;
  int _packetCount = 0;
  int _packetPerSecond = 0;
  Timer? _attackTimer;
  Timer? _statsTimer;
  Timer? _logTimer;
  final List<String> _attackLogs = [];
  final ScrollController _scrollController = ScrollController();

  // ===== COLOR PALETTE - MINECRAFT THEME =====
  static const Color bgMain = Color(0xFF1A1A1A);
  static const Color bgSurface = Color(0xFF2D2D2D);
  static const Color bgCard = Color(0xFF3D3D3D);
  static const Color textMain = Color(0xFFE8E8E8);
  static const Color textSub = Color(0xFFAAAAAA);
  static const Color accentWhite = Color(0xFF4CAF50);
  static const Color borderLight = Color(0xFF5D5D5D);
  static const Color mcGold = Color(0xFFFFD700);
  static const Color mcDiamond = Color(0xFF4DD0E1);
  static const Color mcRedstone = Color(0xFFFF5252);
  static const Color mcEmerald = Color(0xFF00E676);
  static const Color mcOrange = Color(0xFFFF9800);

  final List<Map<String, dynamic>> _servers = [
    {'name': 'SG Server 1', 'ip': '203.116.115.10'},
    {'name': 'SG Server 2', 'ip': '203.116.115.11'},
    {'name': 'ID Server 1', 'ip': '47.246.0.10'},
    {'name': 'ID Server 2', 'ip': '47.246.0.11'},
    {'name': 'MY Server 1', 'ip': '103.219.76.10'},
    {'name': 'MY Server 2', 'ip': '103.219.76.11'},
  ];

  void _startAttack() {
    if (_isAttacking) return;

    setState(() {
      _isAttacking = true;
      _packetCount = 0;
      _packetPerSecond = 0;
      _attackLogs.clear();
    });

    HapticFeedback.heavyImpact();

    _attackTimer = Timer.periodic(const Duration(milliseconds: 50), (timer) {
      if (!_isAttacking) { timer.cancel(); return; }
      setState(() {
        _packetCount += Random().nextInt(150) + 50;
        _packetPerSecond += Random().nextInt(100) + 30;
      });
    });

    _statsTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!_isAttacking) { timer.cancel(); return; }
      setState(() {
        _packetPerSecond = 0;
      });
    });

    _logTimer = Timer.periodic(const Duration(milliseconds: 700), (timer) {
      if (!_isAttacking) { timer.cancel(); return; }
      final server = _servers[Random().nextInt(_servers.length)];
      _attackLogs.insert(0, '${DateTime.now().toLocal().toString().substring(11, 19)} → ${server['name']} (${server['ip']})');
      if (_attackLogs.length > 25) _attackLogs.removeLast();
      if (_scrollController.hasClients) {
        _scrollController.animateTo(0, duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
      }
    });
  }

  void _stopAttack() {
    if (!_isAttacking) return;
    setState(() => _isAttacking = false);
    HapticFeedback.lightImpact();
    _attackTimer?.cancel();
    _statsTimer?.cancel();
    _logTimer?.cancel();
    _attackTimer = null;
    _statsTimer = null;
    _logTimer = null;
  }

  @override
  void dispose() {
    _attackTimer?.cancel();
    _statsTimer?.cancel();
    _logTimer?.cancel();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgMain,
      appBar: AppBar(
        title: const Text(
          'FF LAG SERVER',
          style: TextStyle(
            color: textMain,
            fontWeight: FontWeight.bold,
            fontSize: 14,
            letterSpacing: 1.5,
            shadows: [
              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
            ],
          ),
        ),
        backgroundColor: bgMain,
        centerTitle: true,
        elevation: 0,
        iconTheme: const IconThemeData(color: textMain),
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: bgCard,
              border: Border.all(color: accentWhite, width: 2),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.6),
                  blurRadius: 0,
                  offset: const Offset(2, 2),
                )
              ],
            ),
            child: const Icon(Icons.arrow_back_ios_new, color: textMain, size: 16),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 12),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: bgCard,
              border: Border.all(
                color: _isAttacking ? mcRedstone : mcEmerald,
                width: 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.6),
                  blurRadius: 0,
                  offset: const Offset(2, 2),
                )
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(
                    color: _isAttacking ? mcRedstone : mcEmerald,
                    boxShadow: [
                      BoxShadow(
                        color: (_isAttacking ? mcRedstone : mcEmerald).withOpacity(0.5),
                        blurRadius: 8,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  _isAttacking ? 'ON' : 'OFF',
                  style: TextStyle(
                    color: _isAttacking ? mcRedstone : mcEmerald,
                    fontWeight: FontWeight.bold,
                    fontSize: 11,
                    letterSpacing: 1,
                    shadows: const [
                      Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(3),
          child: Container(height: 3, color: accentWhite),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgMain, bgSurface, bgMain],
          ),
        ),
        child: Column(
          children: [
            // ===== HEADER SECTION - MINECRAFT =====
            Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: bgCard,
                border: Border.all(
                  color: _isAttacking ? mcRedstone : accentWhite,
                  width: 3,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.7),
                    blurRadius: 0,
                    offset: const Offset(5, 5),
                  ),
                  if (_isAttacking)
                    BoxShadow(
                      color: mcRedstone.withOpacity(0.4),
                      blurRadius: 20,
                      spreadRadius: 2,
                    ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: bgSurface,
                      border: Border.all(
                        color: _isAttacking ? mcRedstone : accentWhite,
                        width: 3,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.5),
                          blurRadius: 0,
                          offset: const Offset(3, 3),
                        )
                      ],
                    ),
                    child: Icon(
                      _isAttacking ? Icons.whatshot : Icons.flash_off,
                      size: 28,
                      color: _isAttacking ? mcRedstone : accentWhite,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _isAttacking ? 'ATTACKING...' : 'READY',
                          style: TextStyle(
                            color: _isAttacking ? mcRedstone : textMain,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.5,
                            shadows: const [
                              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                            ],
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _isAttacking
                              ? '${_servers.length} server targets'
                              : 'Tekan START untuk memulai',
                          style: const TextStyle(
                            color: textSub,
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            // ===== STATS BAR - MINECRAFT =====
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              padding: const EdgeInsets.symmetric(vertical: 16),
              decoration: BoxDecoration(
                color: bgCard,
                border: Border.all(color: accentWhite, width: 3),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.7),
                    blurRadius: 0,
                    offset: const Offset(4, 4),
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildStat('PACKETS', '$_packetCount', mcDiamond),
                  _buildStat('PPS', '$_packetPerSecond', mcEmerald),
                  _buildStat('TARGET', '${_servers.length}', mcGold),
                ],
              ),
            ),

            // ===== PROGRESS BAR - MINECRAFT =====
            if (_isAttacking)
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                height: 8,
                decoration: BoxDecoration(
                  color: bgSurface,
                  border: Border.all(color: borderLight, width: 2),
                ),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  width: MediaQuery.of(context).size.width * ((_packetCount % 10000) / 10000),
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [mcRedstone, mcOrange, mcGold],
                    ),
                  ),
                ),
              ),

            // ===== LIVE LOGS - MINECRAFT =====
            Expanded(
              child: Container(
                margin: const EdgeInsets.all(16),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: bgCard,
                  border: Border.all(color: accentWhite, width: 3),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.7),
                      blurRadius: 0,
                      offset: const Offset(5, 5),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 6,
                              height: 16,
                              decoration: BoxDecoration(
                                color: accentWhite,
                                border: Border.all(color: Colors.black, width: 1),
                              ),
                            ),
                            const SizedBox(width: 8),
                            const Text(
                              'LIVE LOGS',
                              style: TextStyle(
                                color: textMain,
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1.5,
                                shadows: [
                                  Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                                ],
                              ),
                            ),
                          ],
                        ),
                        Text(
                          '${_attackLogs.length} entries',
                          style: const TextStyle(
                            color: textSub,
                            fontSize: 10,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Container(height: 2, color: borderLight),
                    const SizedBox(height: 10),
                    Expanded(
                      child: _attackLogs.isEmpty
                          ? Center(
                              child: Container(
                                padding: const EdgeInsets.all(20),
                                decoration: BoxDecoration(
                                  color: bgSurface,
                                  border: Border.all(color: borderLight, width: 2),
                                ),
                                child: Text(
                                  _isAttacking ? 'Menunggu packet...' : 'Belum ada aktivitas',
                                  style: const TextStyle(
                                    color: textSub,
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            )
                          : ListView.builder(
                              controller: _scrollController,
                              reverse: true,
                              itemCount: _attackLogs.length,
                              itemBuilder: (context, index) {
                                final log = _attackLogs[index];
                                final isNew = index == 0;
                                return Container(
                                  margin: const EdgeInsets.symmetric(vertical: 2),
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                  decoration: BoxDecoration(
                                    color: isNew ? bgSurface : Colors.transparent,
                                    border: isNew
                                        ? Border.all(color: mcRedstone, width: 2)
                                        : null,
                                    boxShadow: isNew
                                        ? [
                                            BoxShadow(
                                              color: Colors.black.withOpacity(0.5),
                                              blurRadius: 0,
                                              offset: const Offset(2, 2),
                                            )
                                          ]
                                        : null,
                                  ),
                                  child: Row(
                                    children: [
                                      if (isNew)
                                        Container(
                                          width: 8,
                                          height: 8,
                                          margin: const EdgeInsets.only(right: 8),
                                          decoration: BoxDecoration(
                                            color: mcRedstone,
                                            boxShadow: [
                                              BoxShadow(
                                                color: mcRedstone.withOpacity(0.6),
                                                blurRadius: 6,
                                                spreadRadius: 1,
                                              ),
                                            ],
                                          ),
                                        ),
                                      Expanded(
                                        child: Text(
                                          log,
                                          style: TextStyle(
                                            color: isNew ? mcOrange : textSub,
                                            fontSize: 10,
                                            fontWeight: isNew ? FontWeight.bold : FontWeight.normal,
                                            shadows: isNew
                                                ? const [
                                                    Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                                                  ]
                                                : null,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                    ),
                  ],
                ),
              ),
            ),

            // ===== CONTROL BUTTONS - MINECRAFT =====
            Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: bgCard,
                border: Border.all(color: accentWhite, width: 3),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.7),
                    blurRadius: 0,
                    offset: const Offset(5, 5),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Expanded(
                    child: SizedBox(
                      height: 54,
                      child: ElevatedButton.icon(
                        onPressed: _isAttacking ? null : _startAttack,
                        icon: const Icon(Icons.play_arrow, size: 24, color: Colors.white),
                        label: const Text(
                          'START',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.5,
                            color: Colors.white,
                            shadows: [
                              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                            ],
                          ),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: mcEmerald,
                          foregroundColor: Colors.white,
                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero,
                            side: BorderSide(color: Colors.black, width: 3),
                          ),
                          elevation: 0,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: SizedBox(
                      height: 54,
                      child: ElevatedButton.icon(
                        onPressed: _isAttacking ? _stopAttack : null,
                        icon: Icon(
                          Icons.stop,
                          size: 24,
                          color: _isAttacking ? Colors.white : textSub,
                        ),
                        label: Text(
                          'STOP',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.5,
                            color: _isAttacking ? Colors.white : textSub,
                            shadows: _isAttacking
                                ? const [
                                    Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                                  ]
                                : null,
                          ),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _isAttacking ? mcRedstone : bgSurface,
                          foregroundColor: _isAttacking ? Colors.white : textSub,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero,
                            side: BorderSide(
                              color: _isAttacking ? Colors.black : borderLight,
                              width: 3,
                            ),
                          ),
                          elevation: 0,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStat(String label, String value, Color color) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: bgSurface,
            border: Border.all(color: color, width: 2),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.5),
                blurRadius: 0,
                offset: const Offset(2, 2),
              )
            ],
          ),
          child: Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              shadows: const [
                Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
              ],
            ),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          label,
          style: const TextStyle(
            color: textSub,
            fontSize: 9,
            fontWeight: FontWeight.bold,
            letterSpacing: 1,
          ),
        ),
      ],
    );
  }
}