import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shimmer/shimmer.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

// ===== COLOR PALETTE - MINECRAFT THEME =====
const Color bgMain = Color(0xFF1A1A1A);
const Color bgSurface = Color(0xFF2D2D2D);
const Color bgCard = Color(0xFF3D3D3D);
const Color textMain = Color(0xFFE8E8E8);
const Color textSub = Color(0xFFAAAAAA);
const Color accentWhite = Color(0xFF4CAF50);
const Color borderLight = Color(0xFF5D5D5D);
const Color mcGold = Color(0xFFFFD700);
const Color mcDiamond = Color(0xFF4DD0E1);
const Color mcRedstone = Color(0xFFFF5252);
const Color mcEmerald = Color(0xFF00E676);

// ==================== MODELS ====================
class AnimeModel {
  final String title;
  final String image;
  final String link;
  final String? upload;
  final String? duration;
  final List<String>? genres;

  AnimeModel({
    required this.title,
    required this.image,
    required this.link,
    this.upload,
    this.duration,
    this.genres,
  });

  factory AnimeModel.fromLatest(Map<String, dynamic> json) {
    return AnimeModel(
      title: json['title'] ?? '',
      image: json['image'] ?? '',
      link: json['link'] ?? '',
      upload: json['upload'],
    );
  }

  factory AnimeModel.fromRelease(Map<String, dynamic> json) {
    return AnimeModel(
      title: json['title'] ?? '',
      image: json['img'] ?? '',
      link: json['url'] ?? '',
      duration: json['duration'],
      genres: (json['genre'] as List<dynamic>?)
          ?.map((e) => e.toString())
          .where((e) => e.isNotEmpty)
          .toList(),
    );
  }

  factory AnimeModel.fromSearch(Map<String, dynamic> json) {
    return AnimeModel(
      title: json['title'] ?? '',
      image: json['img'] ?? '',
      link: json['url'] ?? '',
      duration: json['duration'],
      genres: (json['genre'] as List<dynamic>?)
          ?.map((e) => e.toString())
          .where((e) => e.isNotEmpty)
          .toList(),
    );
  }
}

class AnimeDetailModel {
  final String title;
  final String info;
  final String image;
  final String synopsis;
  final String genre;
  final String anime;
  final String producers;
  final String duration;
  final String size;
  final String stream;
  final List<DownloadOption> downloads;

  AnimeDetailModel({
    required this.title,
    required this.info,
    required this.image,
    required this.synopsis,
    required this.genre,
    required this.anime,
    required this.producers,
    required this.duration,
    required this.size,
    required this.stream,
    required this.downloads,
  });

  factory AnimeDetailModel.fromJson(Map<String, dynamic> json) {
    return AnimeDetailModel(
      title: json['title'] ?? '',
      info: json['info'] ?? '',
      image: json['img'] ?? '',
      synopsis: json['sinopsis'] ?? '',
      genre: json['genre'] ?? '',
      anime: json['anime'] ?? '',
      producers: json['producers'] ?? '',
      duration: json['duration'] ?? '',
      size: json['size'] ?? '',
      stream: json['stream'] ?? '',
      downloads: (json['download'] as List<dynamic>?)
          ?.map((e) => DownloadOption.fromJson(e))
          .toList() ?? [],
    );
  }
}

class DownloadOption {
  final String type;
  final String title;
  final List<DownloadLink> links;

  DownloadOption({
    required this.type,
    required this.title,
    required this.links,
  });

  factory DownloadOption.fromJson(Map<String, dynamic> json) {
    return DownloadOption(
      type: json['type'] ?? '',
      title: json['title'] ?? '',
      links: (json['links'] as List<dynamic>?)
          ?.map((e) => DownloadLink.fromJson(e))
          .toList() ?? [],
    );
  }
}

class DownloadLink {
  final String name;
  final String url;

  DownloadLink({
    required this.name,
    required this.url,
  });

  factory DownloadLink.fromJson(Map<String, dynamic> json) {
    return DownloadLink(
      name: json['name'] ?? '',
      url: json['link'] ?? '',
    );
  }
}

// ==================== SERVICES ====================
class ApiService {
  static const String baseUrl = 'https://www.sankavollerei.com/anime/neko';

  static Future<List<AnimeModel>> getLatestAnime() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/latest'));

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final results = jsonData['results'] as List<dynamic>;
        return results.map((e) => AnimeModel.fromLatest(e)).toList();
      }
      throw Exception('Failed to load latest anime');
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  static Future<List<AnimeModel>> getReleaseAnime(int page) async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/release/$page'));

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final data = jsonData['data'] as List<dynamic>;
        return data.map((e) => AnimeModel.fromRelease(e)).toList();
      }
      throw Exception('Failed to load release anime');
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  static Future<List<AnimeModel>> searchAnime(String query) async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/search/$query'));

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final data = jsonData['data'] as List<dynamic>;
        return data.map((e) => AnimeModel.fromSearch(e)).toList();
      }
      throw Exception('Failed to search anime');
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  static Future<AnimeDetailModel> getAnimeDetail(String url) async {
    try {
      final encodedUrl = Uri.encodeComponent(url);
      final response = await http.get(Uri.parse('$baseUrl/get?url=$encodedUrl'));

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        return AnimeDetailModel.fromJson(jsonData['data']);
      }
      throw Exception('Failed to load anime detail');
    } catch (e) {
      throw Exception('Error: $e');
    }
  }
}

class UrlLauncher {
  static Future<void> launchUrl(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(url);
    } else {
      throw Exception('Could not launch $url');
    }
  }
}

// ==================== VIDEO CARD - MINECRAFT ====================
class VideoCard extends StatelessWidget {
  final AnimeModel anime;
  final bool isLatest;

  const VideoCard({
    super.key,
    required this.anime,
    this.isLatest = true,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => DetailScreen(url: anime.link),
          ),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: bgCard,
          border: Border.all(color: accentWhite, width: 3),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.7),
              blurRadius: 0,
              offset: const Offset(4, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 3,
              child: Stack(
                children: [
                  Positioned.fill(
                    child: Image.network(
                      anime.image,
                      width: double.infinity,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        color: bgSurface,
                        child: const Center(
                          child: Icon(
                            Icons.image_not_supported,
                            color: textSub,
                          ),
                        ),
                      ),
                    ),
                  ),
                  if (anime.duration != null && anime.duration!.isNotEmpty)
                    Positioned(
                      bottom: 8,
                      right: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: bgSurface,
                          border: Border.all(color: accentWhite, width: 2),
                        ),
                        child: Text(
                          anime.duration!,
                          style: const TextStyle(
                            color: textMain,
                            fontSize: 9,
                            fontWeight: FontWeight.bold,
                            shadows: [
                              Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                            ],
                          ),
                        ),
                      ),
                    ),
                  Positioned.fill(
                    child: Center(
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: bgSurface,
                          border: Border.all(color: accentWhite, width: 2),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.5),
                              blurRadius: 0,
                              offset: const Offset(2, 2),
                            )
                          ],
                        ),
                        child: const Icon(
                          Icons.play_arrow,
                          color: accentWhite,
                          size: 26,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              flex: 2,
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: const BoxDecoration(
                  color: bgSurface,
                  border: Border(
                    top: BorderSide(color: accentWhite, width: 2),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      anime.title,
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        color: textMain,
                        shadows: [
                          Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                        ],
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    if (isLatest && anime.upload != null)
                      Text(
                        anime.upload!,
                        style: const TextStyle(
                          color: textSub,
                          fontSize: 9,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    if (!isLatest && anime.genres != null && anime.genres!.isNotEmpty)
                      Expanded(
                        child: Wrap(
                          spacing: 4,
                          runSpacing: 2,
                          children: anime.genres!.take(2).map((genre) {
                            return Container(
                              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                              decoration: BoxDecoration(
                                color: bgCard,
                                border: Border.all(color: accentWhite, width: 1),
                              ),
                              child: Text(
                                genre,
                                style: const TextStyle(
                                  color: textMain,
                                  fontSize: 8,
                                  fontWeight: FontWeight.bold,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class LoadingShimmer extends StatelessWidget {
  final int itemCount;
  final double childAspectRatio;

  const LoadingShimmer({
    super.key,
    this.itemCount = 6,
    this.childAspectRatio = 0.7,
  });

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.all(12),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: childAspectRatio,
      ),
      itemCount: itemCount,
      itemBuilder: (_, __) => Shimmer.fromColors(
        baseColor: bgCard,
        highlightColor: bgSurface,
        child: Container(
          decoration: BoxDecoration(
            color: bgCard,
            border: Border.all(color: borderLight, width: 3),
          ),
        ),
      ),
    );
  }
}

// ==================== SCREENS ====================
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<AnimeModel> latestAnimeList = [];
  List<AnimeModel> releaseAnimeList = [];
  List<AnimeModel> searchResults = [];
  bool isLoadingLatest = true;
  bool isLoadingRelease = true;
  bool isSearching = false;
  bool isSearchLoading = false;
  bool isLoadingMore = false;
  bool hasMore = true;
  int currentPage = 1;
  final ScrollController _scrollController = ScrollController();
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();

  Future<void> fetchLatestAnime() async {
    try {
      final data = await ApiService.getLatestAnime();
      setState(() {
        latestAnimeList = data;
        isLoadingLatest = false;
      });
    } catch (e) {
      debugPrint('Error: $e');
      setState(() => isLoadingLatest = false);
    }
  }

  Future<void> fetchReleaseAnime({bool isRefresh = false}) async {
    if (isLoadingMore) return;

    if (isRefresh) {
      setState(() {
        currentPage = 1;
        hasMore = true;
        releaseAnimeList.clear();
        isLoadingRelease = true;
      });
    } else {
      setState(() {
        isLoadingMore = true;
      });
    }

    try {
      final data = await ApiService.getReleaseAnime(currentPage);

      if (data.isEmpty) {
        setState(() {
          hasMore = false;
          isLoadingMore = false;
          isLoadingRelease = false;
        });
        return;
      }

      setState(() {
        if (isRefresh) {
          releaseAnimeList = data;
        } else {
          releaseAnimeList.addAll(data);
        }
        currentPage++;
        isLoadingMore = false;
        isLoadingRelease = false;
      });
    } catch (e) {
      debugPrint('Error: $e');
      setState(() {
        isLoadingMore = false;
        isLoadingRelease = false;
      });
    }
  }

  Future<void> searchAnime(String query) async {
    if (query.isEmpty) {
      setState(() {
        isSearching = false;
        searchResults.clear();
      });
      return;
    }

    setState(() {
      isSearching = true;
      isSearchLoading = true;
    });

    try {
      final data = await ApiService.searchAnime(query);
      setState(() {
        searchResults = data;
        isSearchLoading = false;
      });
    } catch (e) {
      debugPrint('Search Error: $e');
      setState(() {
        searchResults = [];
        isSearchLoading = false;
      });
    }
  }

  void _clearSearch() {
    _searchController.clear();
    setState(() {
      isSearching = false;
      searchResults.clear();
    });
    _searchFocusNode.unfocus();
  }

  void _setupScrollController() {
    _scrollController.addListener(() {
      if (_scrollController.position.pixels >=
          _scrollController.position.maxScrollExtent - 200) {
        if (!isLoadingMore && hasMore && !isSearching) {
          fetchReleaseAnime();
        }
      }
    });
  }

  @override
  void initState() {
    super.initState();
    fetchLatestAnime();
    fetchReleaseAnime();
    _setupScrollController();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _searchFocusNode.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgMain,
      appBar: AppBar(
        backgroundColor: bgMain,
        title: const Text(
          "NEKOPOI",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 14,
            letterSpacing: 2,
            color: textMain,
            shadows: [
              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
            ],
          ),
        ),
        centerTitle: true,
        elevation: 0,
        iconTheme: const IconThemeData(color: textMain),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(3),
          child: Container(height: 3, color: accentWhite),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgMain, bgSurface, bgMain],
          ),
        ),
        child: Column(
          children: [
            // SEARCH BAR - MINECRAFT
            Container(
              padding: const EdgeInsets.all(16),
              decoration: const BoxDecoration(
                color: bgCard,
                border: Border(
                  bottom: BorderSide(color: accentWhite, width: 3),
                ),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: bgSurface,
                        border: Border.all(color: accentWhite, width: 3),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.5),
                            blurRadius: 0,
                            offset: const Offset(2, 2),
                          )
                        ],
                      ),
                      child: TextField(
                        controller: _searchController,
                        focusNode: _searchFocusNode,
                        style: const TextStyle(
                          color: textMain,
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                        ),
                        cursorColor: accentWhite,
                        cursorWidth: 3,
                        decoration: InputDecoration(
                          hintText: "Cari anime...",
                          hintStyle: TextStyle(
                            color: Colors.white.withOpacity(0.25),
                            fontSize: 12,
                          ),
                          border: InputBorder.none,
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 14,
                          ),
                          prefixIcon: const Icon(
                            Icons.search,
                            color: accentWhite,
                          ),
                          suffixIcon: _searchController.text.isNotEmpty
                              ? IconButton(
                                  icon: const Icon(
                                    Icons.clear,
                                    color: textSub,
                                  ),
                                  onPressed: _clearSearch,
                                )
                              : null,
                        ),
                        onChanged: (value) {
                          if (value.isNotEmpty) {
                            searchAnime(value);
                          } else {
                            setState(() {
                              isSearching = false;
                              searchResults.clear();
                            });
                          }
                        },
                        onSubmitted: (value) {
                          if (value.isNotEmpty) {
                            searchAnime(value);
                          }
                        },
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  if (isSearchLoading)
                    const SizedBox(
                      width: 40,
                      height: 40,
                      child: CircularProgressIndicator(
                        strokeWidth: 3,
                        color: accentWhite,
                      ),
                    ),
                ],
              ),
            ),

            Expanded(
              child: isSearching
                  ? _buildSearchResults()
                  : _buildHomeContent(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHomeContent() {
    return RefreshIndicator(
      onRefresh: () async {
        await fetchLatestAnime();
        await fetchReleaseAnime(isRefresh: true);
      },
      color: accentWhite,
      backgroundColor: bgCard,
      child: CustomScrollView(
        controller: _scrollController,
        slivers: [
          SliverToBoxAdapter(
            child: Column(
              children: [
                // LATEST HEADER - MINECRAFT
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: const BoxDecoration(
                    color: bgCard,
                    border: Border(
                      bottom: BorderSide(color: accentWhite, width: 3),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "LATEST RELEASES",
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: textMain,
                          letterSpacing: 1.5,
                          shadows: [
                            Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                          ],
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        "Total ${latestAnimeList.length} video terbaru",
                        style: const TextStyle(
                          color: textSub,
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),

                if (isLoadingLatest)
                  SizedBox(
                    height: 180,
                    child: ListView.builder(
                      padding: const EdgeInsets.all(12),
                      scrollDirection: Axis.horizontal,
                      itemCount: 5,
                      itemBuilder: (_, __) => Container(
                        width: 120,
                        margin: const EdgeInsets.only(right: 12),
                        child: Shimmer.fromColors(
                          baseColor: bgCard,
                          highlightColor: bgSurface,
                          child: Container(
                            decoration: BoxDecoration(
                              color: bgCard,
                              border: Border.all(color: borderLight, width: 3),
                            ),
                          ),
                        ),
                      ),
                    ),
                  )
                else if (latestAnimeList.isNotEmpty)
                  SizedBox(
                    height: 180,
                    child: ListView.builder(
                      padding: const EdgeInsets.all(12),
                      scrollDirection: Axis.horizontal,
                      itemCount: latestAnimeList.length,
                      itemBuilder: (context, index) {
                        return Container(
                          width: 120,
                          margin: const EdgeInsets.only(right: 12),
                          child: VideoCard(anime: latestAnimeList[index], isLatest: true),
                        );
                      },
                    ),
                  ),

                const SizedBox(height: 16),

                // RELEASE HEADER - MINECRAFT
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: const BoxDecoration(
                    color: bgCard,
                    border: Border(
                      top: BorderSide(color: accentWhite, width: 3),
                      bottom: BorderSide(color: accentWhite, width: 3),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "ALL RELEASES",
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: textMain,
                          letterSpacing: 1.5,
                          shadows: [
                            Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                          ],
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        "Halaman $currentPage",
                        style: const TextStyle(
                          color: textSub,
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          if (isLoadingRelease)
            const SliverToBoxAdapter(
              child: LoadingShimmer(),
            )
          else if (releaseAnimeList.isNotEmpty)
            SliverPadding(
              padding: const EdgeInsets.all(12),
              sliver: SliverGrid(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 0.7,
                ),
                delegate: SliverChildBuilderDelegate(
                  (context, index) {
                    return VideoCard(anime: releaseAnimeList[index], isLatest: false);
                  },
                  childCount: releaseAnimeList.length,
                ),
              ),
            ),

          if (isLoadingMore)
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Center(
                  child: CircularProgressIndicator(color: accentWhite, strokeWidth: 3),
                ),
              ),
            ),

          if (!hasMore && releaseAnimeList.isNotEmpty)
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Center(
                  child: Text(
                    "Tidak ada lagi data",
                    style: TextStyle(color: textSub, fontSize: 11),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildSearchResults() {
    if (isSearchLoading) {
      return const LoadingShimmer();
    }

    if (searchResults.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(30),
              decoration: BoxDecoration(
                color: bgCard,
                border: Border.all(color: borderLight, width: 3),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.6),
                    blurRadius: 0,
                    offset: const Offset(5, 5),
                  )
                ],
              ),
              child: const Icon(Icons.search_off, color: textSub, size: 60),
            ),
            const SizedBox(height: 20),
            const Text(
              "Tidak ada hasil pencarian",
              style: TextStyle(
                color: textMain,
                fontSize: 13,
                fontWeight: FontWeight.bold,
                shadows: [
                  Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                ],
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              "Coba dengan kata kunci lain",
              style: TextStyle(color: textSub, fontSize: 11),
            ),
          ],
        ),
      );
    }

    return Column(
      children: [
        // SEARCH HEADER - MINECRAFT
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: const BoxDecoration(
            color: bgCard,
            border: Border(
              bottom: BorderSide(color: accentWhite, width: 3),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "SEARCH RESULTS",
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: textMain,
                  letterSpacing: 1.5,
                  shadows: [
                    Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Text(
                "Menampilkan ${searchResults.length} hasil untuk '${_searchController.text}'",
                style: const TextStyle(
                  color: textSub,
                  fontSize: 11,
                ),
              ),
            ],
          ),
        ),

        Expanded(
          child: GridView.builder(
            padding: const EdgeInsets.all(12),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 0.7,
            ),
            itemCount: searchResults.length,
            itemBuilder: (context, index) {
              return VideoCard(anime: searchResults[index], isLatest: false);
            },
          ),
        ),
      ],
    );
  }
}

// ==================== DETAIL SCREEN ====================
class DetailScreen extends StatefulWidget {
  final String url;

  const DetailScreen({super.key, required this.url});

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> with WidgetsBindingObserver {
  AnimeDetailModel? animeDetail;
  bool isLoading = true;
  bool isError = false;
  bool isPlaying = false;
  bool isFullScreen = false;
  late WebViewController _webViewController;
  bool _isWebViewLoading = true;
  String? _streamUrl;

  Future<void> fetchAnimeDetail() async {
    try {
      final data = await ApiService.getAnimeDetail(widget.url);
      setState(() {
        animeDetail = data;
        _streamUrl = data.stream;
        isLoading = false;
      });
    } catch (e) {
      debugPrint('Error: $e');
      setState(() {
        isLoading = false;
        isError = true;
      });
    }
  }

  void _initializeWebView() {
    if (_streamUrl == null) return;

    _webViewController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..addJavaScriptChannel(
        'FullScreen',
        onMessageReceived: (JavaScriptMessage message) {
          if (message.message == 'enter') {
            _enterFullScreen();
          } else if (message.message == 'exit') {
            _exitFullScreen();
          }
        },
      )
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            if (progress == 100) {
              setState(() {
                _isWebViewLoading = false;
              });
              _injectJavaScript();
            }
          },
          onPageStarted: (String url) {
            setState(() {
              _isWebViewLoading = true;
            });
          },
          onPageFinished: (String url) {
            setState(() {
              _isWebViewLoading = false;
            });
            _injectJavaScript();
          },
          onWebResourceError: (WebResourceError error) {
            setState(() {
              _isWebViewLoading = false;
            });
          },
          onNavigationRequest: (NavigationRequest request) {
            if (request.url != _streamUrl) {
              debugPrint('Blocked navigation to: ${request.url}');
              return NavigationDecision.prevent;
            }
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(Uri.parse(_streamUrl!));
  }

  void _injectJavaScript() {
    _webViewController.runJavaScript('''
      document.addEventListener('click', function(e) {
        const target = e.target.closest('a');
        if (target) {
          e.preventDefault();
          e.stopPropagation();
          return false;
        }
      }, true);
      
      document.addEventListener('submit', function(e) {
        e.preventDefault();
        e.stopPropagation();
        return false;
      }, true);
      
      window.location.replace = function() { return; };
      window.location.assign = function() { return; };
      window.location.href = function() { return; };
      
      function handleFullScreenChange() {
        if (document.fullscreenElement || document.webkitFullscreenElement || 
            document.mozFullScreenElement || document.msFullscreenElement) {
          FullScreen.postMessage('enter');
        } else {
          FullScreen.postMessage('exit');
        }
      }
      
      document.addEventListener('fullscreenchange', handleFullScreenChange);
      document.addEventListener('webkitfullscreenchange', handleFullScreenChange);
      document.addEventListener('mozfullscreenchange', handleFullScreenChange);
      document.addEventListener('MSFullscreenChange', handleFullScreenChange);
      
      document.addEventListener('click', function(e) {
        if (e.target.tagName === 'VIDEO' || e.target.closest('video')) {
          setTimeout(handleFullScreenChange, 100);
        }
      });
      
      document.addEventListener('touchend', function(e) {
        if (e.target.tagName === 'VIDEO' || e.target.closest('video')) {
          setTimeout(handleFullScreenChange, 100);
        }
      });
      
      document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
          setTimeout(handleFullScreenChange, 100);
        }
      });
    ''');
  }

  void _enterFullScreen() {
    if (!isFullScreen) {
      setState(() {
        isFullScreen = true;
      });

      SystemChrome.setPreferredOrientations([
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ]);
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    }
  }

  void _exitFullScreen() {
    if (isFullScreen) {
      setState(() {
        isFullScreen = false;
      });

      SystemChrome.setPreferredOrientations([
        DeviceOrientation.portraitUp,
        DeviceOrientation.portraitDown,
      ]);
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    }
  }

  void _showDownloadOptions() {
    if (animeDetail == null || animeDetail!.downloads.isEmpty) return;

    showModalBottomSheet(
      context: context,
      backgroundColor: bgCard,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.zero,
        side: BorderSide(color: accentWhite, width: 3),
      ),
      builder: (context) {
        return SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: bgSurface,
                    border: Border.all(color: accentWhite, width: 2),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.download, color: accentWhite, size: 16),
                      SizedBox(width: 8),
                      Text(
                        "DOWNLOAD OPTIONS",
                        style: TextStyle(
                          color: textMain,
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.2,
                          shadows: [
                            Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                ...animeDetail!.downloads.map((option) {
                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    decoration: BoxDecoration(
                      color: bgCard,
                      border: Border.all(color: borderLight, width: 2),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.5),
                          blurRadius: 0,
                          offset: const Offset(2, 2),
                        )
                      ],
                    ),
                    child: ExpansionTile(
                      iconColor: accentWhite,
                      collapsedIconColor: textSub,
                      leading: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: bgSurface,
                          border: Border.all(color: accentWhite, width: 2),
                        ),
                        child: Text(
                          option.type.toUpperCase(),
                          style: const TextStyle(
                            color: textMain,
                            fontSize: 9,
                            fontWeight: FontWeight.bold,
                            shadows: [
                              Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                            ],
                          ),
                        ),
                      ),
                      title: Text(
                        option.title,
                        style: const TextStyle(
                          color: textMain,
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      children: option.links.map((link) {
                        return ListTile(
                          leading: _getProviderIcon(link.name),
                          title: Text(
                            link.name,
                            style: const TextStyle(
                              color: textMain,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          trailing: const Icon(
                            Icons.download,
                            color: accentWhite,
                            size: 20,
                          ),
                          onTap: () async {
                            try {
                              await UrlLauncher.launchUrl(link.url);
                            } catch (e) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: const Text(
                                    'Tidak dapat membuka URL',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12,
                                    ),
                                  ),
                                  backgroundColor: mcRedstone,
                                  behavior: SnackBarBehavior.floating,
                                  shape: const RoundedRectangleBorder(
                                    borderRadius: BorderRadius.zero,
                                    side: BorderSide(color: Colors.black, width: 2),
                                  ),
                                ),
                              );
                            }
                          },
                        );
                      }).toList(),
                    ),
                  );
                }).toList(),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _getProviderIcon(String provider) {
    switch (provider.toLowerCase()) {
      case 'mp4upload':
        return const Icon(Icons.video_file, color: mcDiamond, size: 20);
      case 'pixeldrain':
        return const Icon(Icons.cloud_download, color: accentWhite, size: 20);
      case 'krakenfiles':
        return const Icon(Icons.folder, color: mcGold, size: 20);
      case 'mirror':
        return const Icon(Icons.copy_all, color: mcDiamond, size: 20);
      default:
        return const Icon(Icons.download, color: accentWhite, size: 20);
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    fetchAnimeDetail();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  void didChangeMetrics() {
    final physicalSize = WidgetsBinding.instance.window.physicalSize;
    final pixelRatio = WidgetsBinding.instance.window.devicePixelRatio;
    final logicalSize = physicalSize / pixelRatio;

    final isNowFullScreen = logicalSize.width > logicalSize.height;

    if (isNowFullScreen != isFullScreen) {
      setState(() {
        isFullScreen = isNowFullScreen;
      });

      if (isFullScreen) {
        SystemChrome.setPreferredOrientations([
          DeviceOrientation.landscapeLeft,
          DeviceOrientation.landscapeRight,
        ]);
        SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
      } else {
        SystemChrome.setPreferredOrientations([
          DeviceOrientation.portraitUp,
          DeviceOrientation.portraitDown,
        ]);
        SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgMain,
      appBar: isFullScreen ? null : AppBar(
        backgroundColor: bgMain,
        title: Text(
          animeDetail?.title ?? "DETAIL ANIME",
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 13,
            letterSpacing: 1.2,
            color: textMain,
            shadows: [
              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
            ],
          ),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        centerTitle: true,
        elevation: 0,
        iconTheme: const IconThemeData(color: textMain),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(3),
          child: Container(height: 3, color: accentWhite),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgMain, bgSurface, bgMain],
          ),
        ),
        child: isLoading
            ? _buildLoadingShimmer()
            : isError || animeDetail == null
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(30),
                          decoration: BoxDecoration(
                            color: bgCard,
                            border: Border.all(color: mcRedstone, width: 3),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.6),
                                blurRadius: 0,
                                offset: const Offset(5, 5),
                              )
                            ],
                          ),
                          child: const Icon(Icons.error_outline, color: mcRedstone, size: 60),
                        ),
                        const SizedBox(height: 20),
                        const Text(
                          "Gagal memuat detail anime",
                          style: TextStyle(
                            color: textMain,
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            shadows: [
                              Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),
                        SizedBox(
                          height: 50,
                          child: ElevatedButton(
                            onPressed: fetchAnimeDetail,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: accentWhite,
                              foregroundColor: Colors.white,
                              shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero,
                                side: BorderSide(color: Colors.black, width: 3),
                              ),
                              elevation: 0,
                            ),
                            child: const Text(
                              "COBA LAGI",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                                letterSpacing: 1.5,
                                shadows: [
                                  Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                : isPlaying
                    ? _buildVideoPlayer()
                    : _buildAnimeDetail(),
      ),
    );
  }

  Widget _buildVideoPlayer() {
    return Container(
      width: double.infinity,
      height: isFullScreen ? MediaQuery.of(context).size.height : null,
      color: Colors.black,
      child: Stack(
        children: [
          _isWebViewLoading
              ? Container(
                  color: Colors.black,
                  child: const Center(
                    child: CircularProgressIndicator(color: accentWhite, strokeWidth: 3),
                  ),
                )
              : WebViewWidget(controller: _webViewController),

          if (isFullScreen)
            Positioned(
              top: 40,
              right: 20,
              child: IconButton(
                icon: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: bgCard,
                    border: Border.all(color: accentWhite, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.5),
                        blurRadius: 0,
                        offset: const Offset(2, 2),
                      )
                    ],
                  ),
                  child: const Icon(Icons.fullscreen_exit, color: textMain, size: 30),
                ),
                onPressed: _exitFullScreen,
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildAnimeDetail() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // THUMBNAIL + PLAY BUTTON - MINECRAFT
          Container(
            height: 220,
            width: double.infinity,
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: bgCard,
              border: Border.all(color: accentWhite, width: 3),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.7),
                  blurRadius: 0,
                  offset: const Offset(6, 6),
                ),
              ],
            ),
            child: Stack(
              children: [
                Positioned.fill(
                  child: Image.network(
                    animeDetail!.image,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      color: bgSurface,
                      alignment: Alignment.center,
                      child: const Icon(Icons.image_not_supported, color: textSub, size: 40),
                    ),
                  ),
                ),
                Positioned.fill(
                  child: Center(
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          isPlaying = true;
                        });
                        _initializeWebView();
                      },
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: bgSurface,
                          border: Border.all(color: accentWhite, width: 3),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.7),
                              blurRadius: 0,
                              offset: const Offset(4, 4),
                            )
                          ],
                        ),
                        child: const Icon(
                          Icons.play_arrow,
                          color: accentWhite,
                          size: 40,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  animeDetail!.title,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    color: textMain,
                    letterSpacing: 0.5,
                    shadows: [
                      Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                    ],
                  ),
                ),

                const SizedBox(height: 12),

                Text(
                  animeDetail!.info,
                  style: const TextStyle(
                    color: textSub,
                    fontSize: 11,
                  ),
                ),

                const SizedBox(height: 16),

                _buildInfoItem("Anime", animeDetail!.anime),
                _buildInfoItem("Producers", animeDetail!.producers),
                _buildInfoItem("Duration", animeDetail!.duration),
                _buildInfoItem("Size", animeDetail!.size),

                const SizedBox(height: 16),

                const Text(
                  "GENRE",
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: textMain,
                    letterSpacing: 1.2,
                    shadows: [
                      Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: animeDetail!.genre.split(',').map((g) {
                    return Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: bgCard,
                        border: Border.all(color: accentWhite, width: 2),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.5),
                            blurRadius: 0,
                            offset: const Offset(2, 2),
                          )
                        ],
                      ),
                      child: Text(
                        g.trim(),
                        style: const TextStyle(
                          color: textMain,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          shadows: [
                            Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                ),

                const SizedBox(height: 20),

                const Text(
                  "SYNOPSIS",
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: textMain,
                    letterSpacing: 1.2,
                    shadows: [
                      Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: bgCard,
                    border: Border.all(color: borderLight, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.5),
                        blurRadius: 0,
                        offset: const Offset(2, 2),
                      )
                    ],
                  ),
                  child: Text(
                    animeDetail!.synopsis,
                    style: const TextStyle(
                      color: textMain,
                      fontSize: 11,
                      height: 1.6,
                    ),
                    textAlign: TextAlign.justify,
                  ),
                ),

                const SizedBox(height: 24),

                // ACTION BUTTONS - MINECRAFT
                Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 54,
                        child: ElevatedButton.icon(
                          onPressed: isPlaying ? null : () {
                            setState(() {
                              isPlaying = true;
                            });
                            _initializeWebView();
                          },
                          icon: const Icon(Icons.play_arrow, color: Colors.white, size: 20),
                          label: const Text(
                            "PLAY",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                              letterSpacing: 1.5,
                              color: Colors.white,
                              shadows: [
                                Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                              ],
                            ),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: accentWhite,
                            foregroundColor: Colors.white,
                            shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero,
                              side: BorderSide(color: Colors.black, width: 3),
                            ),
                            elevation: 0,
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(width: 12),

                    Expanded(
                      child: SizedBox(
                        height: 54,
                        child: ElevatedButton.icon(
                          onPressed: _showDownloadOptions,
                          icon: const Icon(Icons.download, color: Colors.white, size: 20),
                          label: const Text(
                            "DOWNLOAD",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                              letterSpacing: 1.5,
                              color: Colors.white,
                              shadows: [
                                Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                              ],
                            ),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: mcGold,
                            foregroundColor: Colors.black,
                            shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero,
                              side: BorderSide(color: Colors.black, width: 3),
                            ),
                            elevation: 0,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 24),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoItem(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 90,
            child: Text(
              "$label:",
              style: const TextStyle(
                color: textSub,
                fontSize: 11,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                color: textMain,
                fontSize: 11,
                fontWeight: FontWeight.bold,
                shadows: [
                  Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingShimmer() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Shimmer.fromColors(
              baseColor: bgCard,
              highlightColor: bgSurface,
              child: Container(
                height: 220,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: bgCard,
                  border: Border.all(color: borderLight, width: 3),
                ),
              ),
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Shimmer.fromColors(
                  baseColor: bgCard,
                  highlightColor: bgSurface,
                  child: Container(
                    height: 20,
                    width: double.infinity,
                    color: bgCard,
                  ),
                ),
                const SizedBox(height: 12),
                Shimmer.fromColors(
                  baseColor: bgCard,
                  highlightColor: bgSurface,
                  child: Container(
                    height: 14,
                    width: double.infinity,
                    color: bgCard,
                  ),
                ),
                const SizedBox(height: 20),
                ...List.generate(4, (index) =>
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Shimmer.fromColors(
                        baseColor: bgCard,
                        highlightColor: bgSurface,
                        child: Container(
                          height: 14,
                          width: double.infinity,
                          color: bgCard,
                        ),
                      ),
                    ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}