import 'dart:ui';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter/material.dart';
import 'widgets/custom_popup.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'anime.dart';
import 'FreeFireLagServer.dart';
import 'hentai_page.dart' as hentai;

class ToolsPage extends StatelessWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  // ===== COLOR PALETTE - MINECRAFT THEME =====
  static const Color bgMain = Color(0xFF1A1A1A);          // Obsidian
  static const Color bgSurface = Color(0xFF2D2D2D);       // Stone
  static const Color bgCard = Color(0xFF3D3D3D);          // Cobblestone
  static const Color textMain = Color(0xFFE8E8E8);        // White wool
  static const Color textSub = Color(0xFFAAAAAA);         // Gray
  static const Color accentWhite = Color(0xFF4CAF50);     // Grass green
  static const Color borderLight = Color(0xFF5D5D5D);     // Stone border
  static const Color mcGold = Color(0xFFFFD700);          // Gold
  static const Color mcDiamond = Color(0xFF4DD0E1);       // Diamond
  static const Color mcRedstone = Color(0xFFFF5252);      // Redstone
  static const Color mcEmerald = Color(0xFF00E676);       // Emerald

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgMain,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgMain, bgSurface, bgMain],
          ),
        ),
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
            children: [
              // === HEADER - MINECRAFT STYLE ===
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: bgCard,
                      border: Border.all(color: accentWhite, width: 3),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.7),
                          blurRadius: 0,
                          offset: const Offset(4, 4),
                        )
                      ],
                    ),
                    child: const Icon(Icons.build_rounded, color: accentWhite, size: 24),
                  ),
                  const SizedBox(width: 14),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "TOOLS OCHA DASHBOARD",
                          style: TextStyle(
                            color: textMain,
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.2,
                            shadows: [
                              Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                            ],
                          ),
                        ),
                        SizedBox(height: 6),
                        Text(
                          "Advanced Security & OSINT Tools",
                          style: TextStyle(
                            color: textSub,
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 24),

              _buildCategoryTile(
                context: context,
                icon: Icons.flash_on,
                title: "DDoS Tools",
                subtitle: "Attack & Server",
                children: [
                  _buildToolItem(
                    context: context,
                    icon: FontAwesomeIcons.fire,
                    label: "Lag Free Fire",
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const FreeFireLagServerPage()));
                    },
                  ),
                  _buildToolItem(
                    context: context,
                    icon: Icons.flash_on,
                    label: "Attack Panel",
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => AttackPanel(
                            sessionKey: sessionKey,
                            listDoos: listDoos,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildToolItem(
                    context: context,
                    icon: Icons.dns,
                    label: "Manage Server",
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ManageServerPage(keyToken: sessionKey),
                        ),
                      );
                    },
                  ),
                ],
              ),
              const SizedBox(height: 12),

              _buildCategoryTile(
                context: context,
                icon: Icons.wifi,
                title: "Network",
                subtitle: "WiFi & Ddos",
                children: [
                  _buildToolItem(
                    context: context,
                    icon: Icons.newspaper_outlined,
                    label: "Spam NGL",
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const NglPage()));
                    },
                  ),
                  _buildToolItem(
                    context: context,
                    icon: Icons.wifi_off,
                    label: "WiFi Killer (Internal)",
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const WifiKillerPage()));
                    },
                  ),
                  if (userRole == "vip" || userRole == "owner")
                    _buildToolItem(
                      context: context,
                      icon: Icons.router,
                      label: "WiFi Killer (External)",
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => WifiInternalPage(sessionKey: sessionKey)));
                      },
                    ),
                ],
              ),
              const SizedBox(height: 12),

              _buildCategoryTile(
                context: context,
                icon: Icons.search,
                title: "OSINT",
                subtitle: "Investigation",
                children: [
                  _buildToolItem(
                    context: context,
                    icon: Icons.badge,
                    label: "NIK Detail",
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const NikCheckerPage()));
                    },
                  ),
                  _buildToolItem(
                    context: context,
                    icon: Icons.domain,
                    label: "Domain OSINT",
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const DomainOsintPage()));
                    },
                  ),
                  _buildToolItem(
                    context: context,
                    icon: Icons.person_search,
                    label: "Phone Lookup",
                    onTap: () => _showComingSoon(context),
                  ),
                  _buildToolItem(
                    context: context,
                    icon: Icons.email,
                    label: "Email OSINT",
                    onTap: () => _showComingSoon(context),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              _buildCategoryTile(
                context: context,
                icon: Icons.download,
                title: "Downloader",
                subtitle: "Social Media",
                children: [
                  _buildToolItem(
                    context: context,
                    icon: Icons.video_library,
                    label: "TikTok Downloader",
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const TiktokDownloaderPage()));
                    },
                  ),
                  _buildToolItem(
                    context: context,
                    icon: Icons.camera_alt,
                    label: "Instagram Downloader",
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const InstagramDownloaderPage()));
                    },
                  ),
                ],
              ),
              const SizedBox(height: 12),

              _buildCategoryTile(
                context: context,
                icon: Icons.build,
                title: "Utilities",
                subtitle: "Extra Tools",
                children: [
                  _buildToolItem(
                    context: context,
                    icon: Icons.qr_code,
                    label: "QR Generator",
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const QrGeneratorPage()));
                    },
                  ),
                  _buildToolItem(
                    context: context,
                    icon: Icons.security,
                    label: "IP Scanner",
                    onTap: () => _showComingSoon(context),
                  ),
                  _buildToolItem(
                    context: context,
                    icon: Icons.network_check,
                    label: "Port Scanner",
                    onTap: () => _showComingSoon(context),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              _buildCategoryTile(
                context: context,
                icon: Icons.movie_filter,
                title: "Watch",
                subtitle: "Entertainment & Media",
                children: [
                  _buildToolItem(
                    context: context,
                    icon: Icons.live_tv,
                    label: "Anime Streaming",
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const HomeAnimePage()));
                    },
                  ),
                  _buildToolItem(
                    context: context,
                    icon: Icons.local_fire_department,
                    label: "Hentai Media",
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const hentai.HomeScreen()));
                    },
                  ),
                ],
              ),
              const SizedBox(height: 12),

              _buildCategoryTile(
                context: context,
                icon: Icons.rocket_launch,
                title: "Quick Access",
                subtitle: "Favorites",
                children: [
                  _buildToolItem(
                    context: context,
                    icon: Icons.star_border,
                    label: "Add Quick Access",
                    onTap: () => _showComingSoon(context),
                  ),
                ],
              ),

              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }

  // Desain Pop-up (Floating) untuk satu kategori - MINECRAFT STYLE
  Widget _buildCategoryTile({
    required BuildContext context,
    required IconData icon,
    required String title,
    required String subtitle,
    required List<Widget> children,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: bgCard,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: accentWhite, width: 3),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.7),
            blurRadius: 0,
            offset: const Offset(5, 5),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(1),
          onTap: () {
            showDialog(
              context: context,
              barrierColor: Colors.black.withOpacity(0.75),
              builder: (BuildContext ctx) {
                return BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
                  child: Dialog(
                    backgroundColor: Colors.transparent,
                    elevation: 0,
                    child: Container(
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        color: bgCard,
                        borderRadius: BorderRadius.circular(4),
                        border: Border.all(color: accentWhite, width: 3),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.8),
                            blurRadius: 0,
                            offset: const Offset(8, 8),
                          ),
                        ],
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: bgSurface,
                              border: Border.all(color: accentWhite, width: 3),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.6),
                                  blurRadius: 0,
                                  offset: const Offset(4, 4),
                                )
                              ],
                            ),
                            child: Icon(icon, color: accentWhite, size: 36),
                          ),
                          const SizedBox(height: 16),
                          Text(
                            title,
                            style: const TextStyle(
                              color: textMain,
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.2,
                              shadows: [
                                Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                              ],
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            subtitle,
                            style: const TextStyle(color: textSub, fontSize: 11),
                          ),
                          const SizedBox(height: 24),
                          ...children,
                        ],
                      ),
                    ),
                  ),
                );
              },
            );
          },
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: bgSurface,
                    border: Border.all(color: accentWhite, width: 2),
                  ),
                  child: Icon(icon, color: accentWhite, size: 24),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          color: textMain,
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.8,
                          shadows: [
                            Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                          ],
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        subtitle,
                        style: const TextStyle(
                          color: textSub,
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(Icons.arrow_forward_ios, color: accentWhite.withOpacity(0.6), size: 16),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Desain setiap Item Alat di dalam Dialog - MINECRAFT STYLE
  Widget _buildToolItem({
    required BuildContext context,
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: bgSurface,
        border: Border.all(color: borderLight, width: 2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 0,
            offset: const Offset(3, 3),
          )
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(0),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(
              children: [
                Icon(icon, color: accentWhite, size: 20),
                const SizedBox(width: 16),
                Expanded(
                  child: Text(
                    label,
                    style: const TextStyle(
                      color: textMain,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
                Icon(Icons.arrow_forward_ios, color: textSub, size: 14),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showComingSoon(BuildContext context) {
    CustomPopup.display(
      context,
      title: "Coming Soon",
      message: "Fitur ini masih dalam tahap pengembangan.",
      icon: Icons.info_outline,
    );
  }
}