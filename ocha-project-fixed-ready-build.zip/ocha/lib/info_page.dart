import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class InfoPage extends StatefulWidget {
  final String sessionKey;

  const InfoPage({super.key, required this.sessionKey});

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage> with TickerProviderStateMixin {
  bool isLoading = true;

  bool isApiOnline = false;
  int apiPingMs = 0;
  Color apiStatusColor = const Color(0xFFAAAAAA);
  String apiStatusText = "Checking...";
  Timer? _pingTimer;

  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  // ===== COLOR PALETTE - MINECRAFT THEME =====
  static const Color bgMain = Color(0xFF1A1A1A);          // Obsidian
  static const Color bgSurface = Color(0xFF2D2D2D);       // Stone
  static const Color bgCard = Color(0xFF3D3D3D);          // Cobblestone
  static const Color textMain = Color(0xFFE8E8E8);        // White wool
  static const Color textSub = Color(0xFFAAAAAA);         // Gray
  static const Color accentWhite = Color(0xFF4CAF50);     // Grass green
  static const Color borderLight = Color(0xFF5D5D5D);     // Stone border
  static const Color mcGold = Color(0xFFFFD700);          // Gold
  static const Color mcDiamond = Color(0xFF4DD0E1);       // Diamond
  static const Color mcRedstone = Color(0xFFFF5252);      // Redstone
  static const Color mcEmerald = Color(0xFF00E676);       // Emerald

  final List<Map<String, dynamic>> rulesList = [
    {
      "title": "NO ACCOUNT BARTERING",
      "icon": Icons.swap_horizontal_circle_outlined,
      "desc": "Akun eksklusif GlitchX tidak boleh ditukar dengan barang, jasa, atau akun lain dalam bentuk apa pun. Pelanggaran log akan terpantau."
    },
    {
      "title": "STRICTLY PERSONAL USE",
      "icon": Icons.person_off_outlined,
      "desc": "Setiap akun terenkripsi untuk satu pengguna dan hanya boleh diakses oleh pemilik perangkat yang mendaftar (terikat Device ID)."
    },
    {
      "title": "RESELLING PROHIBITED",
      "icon": Icons.money_off_csred_outlined,
      "desc": "Member reguler dilarang memperjualbelikan akun. Akses penjualan eksklusif milik role berwenang (Partner, Owner, atau Reseller)."
    },
    {
      "title": "ILLEGAL DURATION SALES",
      "icon": Icons.timer_off_outlined,
      "desc": "Sangat dilarang membagi atau menjual akses eceran (harian, mingguan, trial) yang mengelabui skema periode resmi."
    },
    {
      "title": "PRICE DUMPING BAN",
      "icon": Icons.trending_down_rounded,
      "desc": "Dilarang keras merusak standar harga pasar (banting harga) di bawah kesepakatan jaminan keamanan platform kami."
    },
  ];

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.2, end: 1.0).animate(CurvedAnimation(parent: _glowController, curve: Curves.easeInOut));

    _fetchServerInfo();
    _startApiPingLoop();
  }

  @override
  void dispose() {
    _pingTimer?.cancel();
    _glowController.dispose();
    super.dispose();
  }

  Future<void> _fetchServerInfo() async {
    try {
      await http.get(Uri.parse('http://dwixclouds.cloudnesia.my.id:3013/getServerInfo?key=${widget.sessionKey}'));
      if (mounted) setState(() => isLoading = false);
    } catch (_) {
      if (mounted) setState(() => isLoading = false);
    }
  }

  void _startApiPingLoop() {
    _checkApiPing();
    _pingTimer = Timer.periodic(const Duration(seconds: 5), (_) => _checkApiPing());
  }

  Future<void> _checkApiPing() async {
    final start = DateTime.now();
    try {
      final res = await http.get(Uri.parse('http://dwixclouds.cloudnesia.my.id:3013/ping?key=${widget.sessionKey}')).timeout(const Duration(seconds: 3));
      final duration = DateTime.now().difference(start).inMilliseconds;

      if (res.statusCode == 200 && mounted) {
        setState(() {
          isApiOnline = true;
          apiPingMs = duration;
          if (duration < 200) {
            apiStatusColor = mcEmerald;
          } else if (duration < 500) {
            apiStatusColor = mcGold;
          } else {
            apiStatusColor = mcDiamond;
          }
          apiStatusText = "Sys.Online :: ${duration}ms";
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          isApiOnline = false;
          apiPingMs = 0;
          apiStatusColor = mcRedstone;
          apiStatusText = "Sys.Offline :: DEST";
        });
      }
    }
  }

  Widget _buildStatusHeader() {
    return Container(
      margin: const EdgeInsets.only(bottom: 24),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      decoration: BoxDecoration(
        color: bgCard,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: borderLight, width: 3),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.7),
            blurRadius: 0,
            offset: const Offset(5, 5),
          )
        ],
      ),
      child: Row(
        children: [
          // PULSE DOT - MINECRAFT STYLE
          AnimatedBuilder(
            animation: _glowAnimation,
            builder: (context, child) {
              return Container(
                width: 14,
                height: 14,
                decoration: BoxDecoration(
                  color: apiStatusColor,
                  border: Border.all(color: Colors.black, width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: apiStatusColor.withOpacity(_glowAnimation.value * 0.6),
                      blurRadius: 8,
                      spreadRadius: 2,
                    )
                  ],
                ),
              );
            },
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Text(
              apiStatusText.toUpperCase(),
              style: TextStyle(
                color: apiStatusColor,
                fontWeight: FontWeight.bold,
                fontSize: 13,
                letterSpacing: 1.5,
                shadows: const [
                  Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                ],
              ),
            ),
          ),
          Icon(Icons.memory, color: textSub.withOpacity(0.6), size: 20),
        ],
      ),
    );
  }

  Widget _buildPenaltyBox() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 10, bottom: 30),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: bgCard,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: mcRedstone, width: 3),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.7),
            blurRadius: 0,
            offset: const Offset(6, 6),
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const [
              Icon(Icons.warning_amber_rounded, color: mcRedstone, size: 28),
              SizedBox(width: 10),
              Text(
                "VIOLATION PENALTY",
                style: TextStyle(
                  color: mcRedstone,
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.5,
                  shadows: [
                    Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Text(
            "Jika pengguna terdeteksi melanggar salah satu protokol kerahasiaan & aturan di atas secara sengaja:",
            style: TextStyle(color: textSub, fontSize: 12),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 12),
          // RED BOX - PENALTY WARNING
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: mcRedstone.withOpacity(0.15),
              border: Border.all(color: mcRedstone, width: 2),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.5),
                  blurRadius: 0,
                  offset: const Offset(3, 3),
                )
              ],
            ),
            child: const Text(
              "AKUN AKAN DIHAPUS PERMANEN",
              style: TextStyle(
                color: textMain,
                fontSize: 13,
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
                shadows: [
                  Shadow(color: Colors.black, offset: Offset(1, 1), blurRadius: 0),
                ],
              ),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            "TIDAK ADA PENGEMBALIAN SALDO ATAU KOMPENSASI.",
            style: TextStyle(
              color: mcRedstone.withOpacity(0.9),
              fontSize: 10,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildRuleCard(int index, Map<String, dynamic> rule) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: bgCard,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: borderLight, width: 3),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.7),
            blurRadius: 0,
            offset: const Offset(5, 5),
          )
        ],
      ),
      child: Theme(
        data: ThemeData(dividerColor: Colors.transparent),
        child: ExpansionTile(
          iconColor: accentWhite,
          collapsedIconColor: accentWhite.withOpacity(0.7),
          backgroundColor: Colors.transparent,
          collapsedBackgroundColor: Colors.transparent,
          tilePadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          leading: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: bgSurface,
              border: Border.all(color: accentWhite, width: 2),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.5),
                  blurRadius: 0,
                  offset: const Offset(2, 2),
                )
              ],
            ),
            child: Icon(rule['icon'], color: accentWhite, size: 22),
          ),
          title: Text(
            rule['title'],
            style: const TextStyle(
              color: textMain,
              fontWeight: FontWeight.bold,
              fontSize: 12,
              letterSpacing: 1.0,
              shadows: [
                Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
              ],
            ),
          ),
          children: [
            Container(
              padding: const EdgeInsets.only(left: 20, right: 20, bottom: 20, top: 4),
              width: double.infinity,
              child: Text(
                rule['desc'],
                style: const TextStyle(
                  color: textSub,
                  fontSize: 12,
                  height: 1.6,
                ),
                textAlign: TextAlign.left,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(
        backgroundColor: bgMain,
        body: Center(
          child: CircularProgressIndicator(color: accentWhite),
        ),
      );
    }

    return Scaffold(
      backgroundColor: bgMain,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgMain, bgSurface, bgMain],
          ),
        ),
        child: SafeArea(
          child: CustomScrollView(
            physics: const BouncingScrollPhysics(),
            slivers: [
              SliverAppBar(
                backgroundColor: bgMain,
                elevation: 0,
                pinned: true,
                automaticallyImplyLeading: false,
                expandedHeight: 80,
                flexibleSpace: FlexibleSpaceBar(
                  titlePadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                  title: const Text(
                    "EULA & SYSTEM INFO",
                    style: TextStyle(
                      color: textMain,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2.0,
                      fontSize: 13,
                      shadows: [
                        Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                      ],
                    ),
                  ),
                  centerTitle: false,
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
                sliver: SliverList(
                  delegate: SliverChildListDelegate([
                    _buildStatusHeader(),

                    const Padding(
                      padding: EdgeInsets.only(bottom: 16, top: 8),
                      child: Text(
                        "USER PROTOCOLS",
                        style: TextStyle(
                          color: accentWhite,
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2.5,
                          shadows: [
                            Shadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0),
                          ],
                        ),
                      ),
                    ),

                    ...rulesList.asMap().entries.map((e) => _buildRuleCard(e.key, e.value)).toList(),

                    _buildPenaltyBox(),

                    Center(
                      child: Column(
                        children: [
                          const Icon(Icons.shield_moon_rounded, color: textSub, size: 30),
                          const SizedBox(height: 12),
                          const Text(
                            "Peraturan ini dibuat semata-mata untuk menjaga keamanan, kenyamanan, dan kestabilan ekosistem server GlitchX. Dengan mengakses aplikasi, Anda secara otomatis menyetujui seluruh protokol di atas.",
                            style: TextStyle(
                              color: textSub,
                              fontSize: 10,
                              fontStyle: FontStyle.italic,
                              height: 1.6,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 16),
                          Container(
                            height: 3,
                            width: 40,
                            color: textSub.withOpacity(0.5),
                          ),
                          const SizedBox(height: 40),
                        ],
                      ),
                    ),
                  ]),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}